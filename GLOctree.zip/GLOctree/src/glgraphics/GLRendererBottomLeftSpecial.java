/*
 * Created on Jan 4, 2005
 *
 */
package glgraphics;

import geometry.objects.FrustumObject;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.media.opengl.GL;

import main.MainFrame;
import main.Performance;
import math.Frustum;
import model.Heap;
import views.CameraBase;
import views.ICamera;



/**
 * @author wdevore
 *
 */
public class GLRendererBottomLeftSpecial extends GLRenderer {
	private boolean frameActive = true;

	private Performance perf = new Performance();
	private ICamera cameraLeft;
	
	public GLRendererBottomLeftSpecial(MainFrame frame) {
		super(frame);
		camera = (CameraBase)db.cameraBottomLeft;
		cameraLeft = db.cameraLeft;
	}

	/* (non-Javadoc)
	 * @see glgraphics.GLRenderer#initializeGL()
	 */
	public void initializeGL() {
	}
	
	/* (non-Javadoc)
	 * @see glgraphics.GLRenderer#resizeGL()
	 */
	public void resizeGL(int x, int y, int width, int height) {
		System.out.println("GLRendererRight::resizeGL");
		
		setPerspectiveProjection(camera.fov, width, height, camera.near, camera.far);
		
		d.height = height;
		d.width = width;
		camera.resize(d);
	}
	

	/* (non-Javadoc)
	 * @see glgraphics.GLRenderer#render()
	 */
	public void render() {
		long t3 = System.currentTimeMillis();

		super.render();
		
		gl.glPopMatrix();
		
		/*
		 * The frustum is defined at the default OpenGL position and orientation and
		 * no transformation is required. And is
		 * looking down the -z-axis placed at the world origin.
		 */
		FrustumObject fo = cameraLeft.getFrustumObject();
		fo.render(gl, true, 0, 0, 0);
		// Draw world coord axes.
		gl.glDisable(GL.GL_LIGHTING);
		gl.glDisable(GL.GL_LIGHT0);
		gl.glBegin(GL.GL_LINES);
		gl.glColor3f(1.0f, 0.0f, 0.0f);
		gl.glVertex3f(-2000.0f, 0.0f, 0.0f);
		gl.glVertex3f(2000.0f, 0.0f, 0.0f);
		gl.glColor3f(0.0f, 1.0f, 0.0f);
		gl.glVertex3f(0.0f, -2000.0f, 0.0f);
		gl.glVertex3f(0.0f, 2000.0f, 0.0f);
		gl.glColor3f(0.0f, 0.0f, 1.0f);
		gl.glVertex3f(0.0f, 0.0f, -2000.0f);
		gl.glVertex3f(0.0f, 0.0f, 2000.0f);
		gl.glEnd();
		gl.glEnable(GL.GL_LIGHT0);
		gl.glEnable(GL.GL_LIGHTING);

		long t1 = System.currentTimeMillis();

		render2D(perf.getFramePerSecond2(t1, t3));
	}
	
	private void render2D(float fps) {
		gl.glDisable(GL.GL_LIGHTING);
		
		gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
		gl.glPushMatrix();		// save the projection matrix.

		setOrthographicProjection(db.viewport.width, db.viewport.height);

		gl.glMatrixMode(GL.GL_MODELVIEW); // select the modelview matrix
		gl.glLoadIdentity(); // Reset the current modelview matrix
		
        gl.glDisable(GL.GL_DEPTH_TEST);

		// Ready to perform 2D drawing
		if (frameActive)
			rf.setColor(activeColor);
		else
			rf.setColor(inActiveColor);
		
		rf.println(15, 1, "FPS: " + Heap.nf.format(fps));
		
		rf.setColor(1);
		rf.println(30, 1, "INFO: " + Heap.iStatus);

		camera.render2D(gl);

        gl.glEnable(GL.GL_DEPTH_TEST);

		gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
		gl.glPopMatrix();	// restore projection.

		gl.glEnable(GL.GL_LIGHTING);
	}

	protected void setPerspectiveProjection(float fov, int width, int height, float near, float far) {
		super.setPerspectiveProjection(fov, width, height, near, far);

		camera.setFrustum(fov, width, height, near, far);
		Frustum frustum = camera.getFrustum();
		
		gl.glFrustum(frustum.left, frustum.right, frustum.bottom, frustum.top,
				near, far);

	}

	public void mouseDragged(MouseEvent event) {
		if (!mouse.isDragInProgress())
			return;

		mouse.setCurrentPoint(event.getX(), event.getY());
		camera.updateMouse(mouse);
		mouse.setPreviousPoint();
		
		if (frame.animator.isAnimating()) {
			glDrawable.display();
		}
		
		super.mouseDragged(event);
	}
	
	public void mouseMoved(MouseEvent arg0) {
		super.mouseMoved(arg0);
	}
	
	public void mousePressed(MouseEvent event) {
//		frame.animator.stop();
		
		if (event.getButton() != 1) return;	// Only process if left mouse button
		
		if (mouse.isDragInProgress()) return; // spurious event
		mouse.dragInProgress();

		mouse.setCurrentPoint(event.getX(), event.getY());
		mouse.setPreviousPoint();
		
		camera.mouseDown(mouse);
		camera.updateMouse(mouse);
		super.mousePressed(event);
	}
	public void mouseReleased(MouseEvent event) {
//		frame.animator.start();
		
		if (event.getButton() != 1) return;
		
		if (!mouse.isDragInProgress()) return; // spurious event
		mouse.dragNotInProgress();
		
		camera.clearMouse();
		
		mouse.setCurrentPoint(0, 0);
		mouse.setPreviousPoint(0, 0);

		camera.mouseUp(mouse);
		super.mouseReleased(event);
	}


	public void mouseEntered(MouseEvent arg0) {
		frameActive = true;
		activeFrame = 3;
		super.mouseEntered(arg0);
	}
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent arg0) {
		frameActive = false;
		activeFrame = 0;
		super.mouseExited(arg0);
	}
	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed(KeyEvent e) {
		if (activeFrame == 3) {
//			System.out.println("GLRendererRight::keyPressed " + e);
			keys.key = e.getKeyCode();
			keys.ckey = e.getKeyChar();
			
			switch (keys.ckey) {
			case 'c':
				camera.dolly(-1.0f);
				break;
			case 'r':
				camera.dolly(1.0f);
				break;
			case 'e':
				camera.slideUpDown(1.0f);
				break;
			case 'x':
				camera.slideUpDown(-1.0f);
				break;
			case 's':
				camera.slideLeftRight(-1.0f);
				break;
			case 'd':
				camera.slideLeftRight(1.0f);
				break;
			case '1':
				Heap.v1.set(100.0f, 200.0f, 100.0f);
				Heap.v2.set(0.0f, 0.0f, 0.0f);
				camera.lookAt(Heap.v1, Heap.v2);
				break;
			case '2':
				Heap.v1.set(0.0f, 500.0f, 0.0f);
				Heap.v2.set(0.0f, 0.0f, 0.0f);
				camera.lookAt(Heap.v1, Heap.v2);
				break;
			case '3':
				Heap.v1.set(500.0f, 0.0f, 0.0f);
				Heap.v2.set(0.0f, 0.0f, 0.0f);
				camera.lookAt(Heap.v1, Heap.v2);
				break;
			case '4':
				Heap.v1.set(0.0f, 0.0f, 500.0f);
				Heap.v2.set(0.0f, 0.0f, 0.0f);
				camera.lookAt(Heap.v1, Heap.v2);
				break;
			case 'u':
				if (Heap.iCullTrigger == 0)
					Heap.iCullTrigger = 1;
				else
					Heap.iCullTrigger = 0;
				break;
			case 'p':
				if (Heap.iClippingEnabled == 0)
					Heap.iClippingEnabled = 1;
				else
					Heap.iClippingEnabled = 0;
				break;
			case 'o':
				projectionChange = 1;
				if (projectionType == 0) {
					projectionType = 1;
				} else {
					projectionType = 0;
				}
				break;
			case 'i':
				Heap.iOffsetZ += 0.1f;
				break;
			case 'm':
				Heap.iOffsetZ -= 0.1f;
				break;
			case 'j':
				Heap.iOffsetX += 0.1f;
				break;
			case 'k':
				Heap.iOffsetX -= 0.1f;
				break;
			}
		}
		super.keyPressed(e);
	}

}
