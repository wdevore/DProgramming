/*
 * Created on Feb 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package glgraphics.lights;

/**
 * @author wdevore
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface ILight {
	public void setAmbient(float r, float g, float b, float alpha);
	public float[] getAmbient();
	public void setDiffuse(float r, float g, float b, float alpha);
	public float[] getDiffuse();
	public void setSpecular(float r, float g, float b, float alpha);
	public float[] getSpecular();

	public float[] getTransformArray();

}
