/*
 * Created on Jan 17, 2005
 *
 */
package glgraphics.lights;

import geometry.objects.MultiColorLinesObject;

import javax.media.opengl.GL;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;

import math.VectorAlgebra;


/**
 * @author wdevore
 *
 */
public class GLDirectionalLight extends GLLightBase {
	MultiColorLinesObject icon = new MultiColorLinesObject();
	private float[] direction = new float[4];

	private Vector3f v1 = new Vector3f();
	//private Vector3f v2 = new Vector3f();
	//private Vector3f v3 = new Vector3f();
	//private Vector3f v4 = new Vector3f();
	private Matrix3f rot = new Matrix3f();
	//private Matrix3f rot2 = new Matrix3f();
	private float[] a1 = new float[16];
	//private float[] a2 = new float[16];
	
	public GLDirectionalLight() {
		/*
		 * indicate this is a directional light source
		 * infinitely away.
		 * The first three floats indicate the normalized
		 * direction.
		 * The last float flags the light type
		 */
		direction[3] = 0.0f;
		
		Vector3f v = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f c1 = new Vector3f();
		c1.set(1.0f, 1.0f, 0.0f);
		
		// xy plane
		v.set(-0.5f, -0.5f, 0.0f);
		v2.set(0.5f, -0.5f, 0.0f);
		icon.addLine(v, v2, c1, c1);
		
		v2.set(0.5f, -0.5f, 0.0f);
		v.set(0.5f, 0.5f, 0.0f);
		icon.addLine(v2, v, c1, c1);

		c1.set(0.0f, 0.0f, 1.0f);
		v.set(0.5f, 0.5f, 0.0f);
		v2.set(-0.5f, 0.5f, 0.0f);
		icon.addLine(v, v2, c1, c1);

		c1.set(1.0f, 1.0f, 0.0f);
		v2.set(-0.5f, 0.5f, 0.0f);
		v.set(-0.5f, -0.5f, 0.0f);
		icon.addLine(v2, v, c1, c1);

		// yz plane
//		v.set(0.0f, -0.5f, -0.5f);
//		v2.set(0.0f, 0.5f, -0.5f);
//		icon.addLine(v, v2, c1, c1);
//		
//		v2.set(0.0f, 0.5f, -0.5f);
//		v.set(0.0f, 0.5f, 0.5f);
//		icon.addLine(v2, v, c1, c1);
//
//		v.set(0.0f, 0.5f, 0.5f);
//		v2.set(0.0f, -0.5f, 0.5f);
//		icon.addLine(v, v2, c1, c1);
//
//		v2.set(0.0f, -0.5f, 0.5f);
//		v.set(0.0f, -0.5f, -0.5f);
//		icon.addLine(v2, v, c1, c1);

		// direction
		c1.set(0.5f, 0.5f, 0.0f);
		v.set(0.0f, 0.0f, 0.0f);
		v2.set(0.0f, 0.0f, -1.0f);
		icon.addLine(v, v2, c1, c1);

		v.set(-0.15f, 0.0f, -0.75f);
		v2.set(0.0f, 0.0f, -1.0f);
		icon.addLine(v, v2, c1, c1);
		v.set(0.15f, 0.0f, -0.75f);
		v2.set(0.0f, 0.0f, -1.0f);
		icon.addLine(v, v2, c1, c1);
		
		v.set(0.0f, -0.15f, -0.75f);
		v2.set(0.0f, 0.0f, -1.0f);
		icon.addLine(v, v2, c1, c1);
		v.set(0.0f, 0.15f, -0.75f);
		v2.set(0.0f, 0.0f, -1.0f);
		icon.addLine(v, v2, c1, c1);
		
		icon.pack();

}

	public void setDirection(float x, float y, float z) {
		direction[0] = x;
		direction[1] = y;
		direction[2] = z;
	}
	public float[] getDirection() {
		return direction;
	}
	
	public void setIconPosition(float x, float y, float z) {
		icon.setPosition(x, y, z);
	}
	
	public Vector3f getPosition() {
		return icon.getPosition();
	}
	
	
	public void render(GL gl) {

		float av[] = getDirection(); // where the light is coming FROM.
		
		/*
		 * This is the real lighting object used by OpenGL. It is
		 * affected by the current model view matrix.
		 */
		gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, av, 0);

		/*
		 * Now render a visual representation of the direction light as
		 * an stand-in Icon.
		 */
		gl.glDisable(GL.GL_LIGHTING);
		gl.glPushMatrix();
		
		/*
		 * Place and orient the object.
		 */
		a1 = getTransformArray();
		gl.glMultMatrixf(a1, 0);

		/*
		 * Uniform scaling to see it better.
		 */
		gl.glScalef(10.0f, 10.0f, 10.0f);
		
		icon.render(gl, true, 0, 0, 0);
		
		gl.glPopMatrix();
		gl.glEnable(GL.GL_LIGHTING);

	}
	
	protected Matrix4f getTransformMatrix() {
		if (!isDirty) {
			return transform;
		}
		
		if (translation == null) {
			translation = new Matrix4f();
		}
		if (rotation == null) {
			rotation = new Matrix3f();
		}
		if (transform == null) {
			transform = new Matrix4f();
		}
		if (transformArray == null) {
			transformArray = new float[16];
		}

		translation.setIdentity();
		rotation.setIdentity();
		transform.setIdentity();

		float av[] = getDirection(); // where the light is coming FROM.
		v1.set(av[0], av[1], av[2]);
		
		/*
		 * We negate because we want where the light is going TO or coming from.
		 */
		v1.negate();

		// rotate
		rot.setIdentity();
		rot.set(VectorAlgebra.getColLinearRotation(v1));

		rotation.set(VectorAlgebra.getVerticalAlignRotation(rot, v1));
		rotation.mul(rot);
		m14f.set(rotation);

		transform.setTranslation(getPosition());
		
		/*
		 * We want the effect of an object rotating in place. This means we do
		 * a rotate and then translate. Which means a post-multiply of the
		 * reverse.
		 */
		transform.mul(m14f);

		isDirty = false;

		return transform;
	}
}
