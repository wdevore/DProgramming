/*
 * Created on Jan 17, 2005
 *
 */
package glgraphics.lights;

import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;

import math.VectorAlgebra;



/**
 * @author wdevore
 *
 */
public abstract class GLLightBase implements ILight {
	
	protected float[] ambient = new float[4];
	protected float[] diffuse = new float[4];
	protected float[] specular = new float[4];

	protected float[] transformArray = null;
	protected Matrix4f transform = null;
	protected Matrix3f rotation = null;
	protected Matrix4f translation = null;

	protected Matrix4f m14f = new Matrix4f();

	public String name;
	
	/*
	 * Optimization flag.
	 * Has the camera been modified since the last calculation.
	 */
	protected boolean isDirty = true;

	public void setAmbient(float r, float g, float b, float alpha) {
		ambient[0] = r;
		ambient[1] = g;
		ambient[2] = b;
		ambient[3] = alpha;
	}
	public float[] getAmbient() {
		return ambient;
	}
	public void setDiffuse(float r, float g, float b, float alpha) {
		diffuse[0] = r;
		diffuse[1] = g;
		diffuse[2] = b;
		diffuse[3] = alpha;
	}
	public float[] getDiffuse() {
		return diffuse;
	}
	public void setSpecular(float r, float g, float b, float alpha) {
		specular[0] = r;
		specular[1] = g;
		specular[2] = b;
		specular[3] = alpha;
	}
	public float[] getSpecular() {
		return specular;
	}
	
	protected abstract Matrix4f getTransformMatrix();

	public float[] getTransformArray() {
		if (!isDirty) {
			return transformArray;
		}

		getTransformMatrix();
		
		/*
		 * A much faster transfer.
		 */
		VectorAlgebra.matrixToArray(transform, transformArray);
		
		return transformArray;
	}

}
