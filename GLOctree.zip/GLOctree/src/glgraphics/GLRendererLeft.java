/*
 * Created on Jan 4, 2005
 *
 */
package glgraphics;


import geometry.objects.FrustumObject;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.media.opengl.GL;

import main.MainFrame;
import main.Performance;
import math.Frustum;
import model.Heap;
import views.CameraBase;

/**
 * @author wdevore
 *
 */
public class GLRendererLeft extends GLRenderer {
	
	private Performance perf = new Performance();
	
	/* ******************************************************
	 * Methods
	 * ******************************************************
	 */
	public GLRendererLeft(MainFrame frame) {
		super(frame);
		Heap.nf.setMaximumFractionDigits(1);
		camera = (CameraBase)db.cameraLeft;

	}
	
	/* (non-Javadoc)
	 * @see glgraphics.GLRenderer#initializeGL()
	 */
	public void initializeGL() {
		/*
		 * Setup any GL specific stuff for this widget
		 */
	}

	/* (non-Javadoc)
	 * @see glgraphics.GLRenderer#resizeGL()
	 */
	public void resizeGL(int x, int y, int width, int height) {
		System.out.println("GLRendererLeft::resizeGL " + name);
		
		setPerspectiveProjection(camera.fov, width, height, camera.near, camera.far);

		FrustumObject fo = camera.getFrustumObject();
		fo.init();

		d.height = height;
		d.width = width;
		camera.resize(d);
	}

	public void render() {
		long t3 = System.currentTimeMillis();

		super.render();
		
		/*
		 * Get frustum for this viewport.
		 */
		FrustumObject fo = camera.getFrustumObject();
		/*
		 * Extract frustum based on current projection-modelview-matrix
		 * for this viewport.
		 */
		fo.extractFrustum(gl);
		
		db.cullOctree(fo, camera);
		
		Heap.iCount = db.renderObjects(gl, fo, camera);

		long t1 = System.currentTimeMillis();
		
		render2D(perf.getFramePerSecond2(t1, t3));
	}
	
	
	private void render2D(float fps) {
		gl.glDisable(GL.GL_LIGHTING);
		
		gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
		gl.glPushMatrix();		// save the projection matrix.

		setOrthographicProjection(db.viewport.width, db.viewport.height);

		gl.glMatrixMode(GL.GL_MODELVIEW); // select the modelview matrix
		gl.glLoadIdentity(); // Reset the current modelview matrix
		
        gl.glDisable(GL.GL_DEPTH_TEST);

		// Ready to perform 2D drawing
		if (frameActive)
			rf.setColor(activeColor);
		else
			rf.setColor(inActiveColor);
		rf.println(15, 1, "FPS: " + Heap.nf.format(fps));
		
		rf.setColor(1);
		rf.println(30, 1, "RENDERED: " + Heap.iCount);
//System.out.println(Heap.iCount);
		camera.render2D(gl);
		
        gl.glEnable(GL.GL_DEPTH_TEST);

		gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
		gl.glPopMatrix();	// restore projection.

		gl.glEnable(GL.GL_LIGHTING);
	}
	
	protected void setPerspectiveProjection(float fov, int width, int height, float near, float far) {
		super.setPerspectiveProjection(fov, width, height, near, far);
		
		camera.setFrustum(fov, width, height, near, far);
		Frustum frustum = camera.getFrustum();
		
		gl.glFrustum(frustum.left, frustum.right, frustum.bottom, frustum.top,
			near, far);
		
	}

	public void mouseDragged(MouseEvent event) {

		if (!mouse.isDragInProgress())
			return;

		mouse.setCurrentPoint(event.getX(), event.getY());
		camera.updateMouse(mouse);
		mouse.setPreviousPoint();

		if (frame.animator.isAnimating()) {
			glDrawable.display();
		}
		
		super.mouseDragged(event);
	}
	
	public void mouseMoved(MouseEvent arg0) {
		super.mouseMoved(arg0);
	}
	
	public void mousePressed(MouseEvent event) {
//		frame.animator.stop();
		
		if (event.getButton() != 1) return;	// Only process if left mouse button
		
		if (mouse.isDragInProgress()) return; // spurious event

		mouse.dragInProgress();

		mouse.setCurrentPoint(event.getX(), event.getY());
		mouse.setPreviousPoint();

		camera.mouseDown(mouse);
		camera.updateMouse(mouse);
		super.mousePressed(event);
	}
	public void mouseReleased(MouseEvent event) {
//		frame.animator.start();
		if (event.getButton() != 1) return;
		
		if (!mouse.isDragInProgress()) return; // spurious event
		mouse.dragNotInProgress();
		
		camera.clearMouse();
		
		mouse.setCurrentPoint(0, 0);
		mouse.setPreviousPoint(0, 0);
		
		camera.mouseUp(mouse);
		super.mouseReleased(event);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered(MouseEvent arg0) {
		frameActive = true;
		activeFrame = 1;
		super.mouseEntered(arg0);
	}
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent arg0) {
		frameActive = false;
		activeFrame = 0;
		super.mouseExited(arg0);
	}
	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed(KeyEvent e) {
		if (activeFrame == 1) {
//			System.out.println("GLRendererLeft::keyPressed " + e);
			keys.key = e.getKeyCode();
			keys.ckey = e.getKeyChar();
			
			switch (keys.ckey) {
			case 'c':
				camera.dolly(-1.0f);
				break;
			case 'r':
				camera.dolly(1.0f);
				break;
			case 'e':
				camera.slideUpDown(1.0f);
				break;
			case 'x':
				camera.slideUpDown(-1.0f);
				break;
			case 's':
				camera.slideLeftRight(-1.0f);
				break;
			case 'd':
				camera.slideLeftRight(1.0f);
				break;
			case '1':
				Heap.v1.set(0.0f, 0.0f, 0.0f);
				Heap.v2.set(0.0f, 0.0f, -1.0f);
				camera.lookAt(Heap.v1, Heap.v2);
				break;
			case '=':
				camera.updateMouse(mouse);
				glDrawable.display();
				break;
			case 'u':
				if (Heap.iCullTrigger == 0)
					Heap.iCullTrigger = 1;
				else
					Heap.iCullTrigger = 0;
				break;
			case 'p':
				if (Heap.iClippingEnabled == 0)
					Heap.iClippingEnabled = 1;
				else
					Heap.iClippingEnabled = 0;
				break;
			case 'o':
				projectionChange = 1;
				if (projectionType == 0) {
					projectionType = 1;
				} else {
					projectionType = 0;
				}
				break;
			}
		}
		/*
		 * We need to generate a mouse update such that the other viewports
		 * update correctly. The left viewport drives the other displays to a
		 * miner extent.
		 */
		camera.updateMouse(mouse);
		glDrawable.display();

		super.keyPressed(e);
	}
}
