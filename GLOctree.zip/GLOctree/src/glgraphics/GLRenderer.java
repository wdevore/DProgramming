/*
 * Created on Nov 11, 2004
 * 
 */
package glgraphics;

import glgraphics.fonts.RasterFonts;
import input.Keys;
import input.Mouse;

import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.vecmath.Point3f;

import main.MainFrame;
import model.Database;
import model.Heap;
import views.CameraBase;

public abstract class GLRenderer extends MouseAdapter implements GLEventListener, KeyListener, MouseMotionListener {
	protected int projectionType = 0;
	protected int projectionChange = 0;
	protected float orthoZoomFactor = 5;
	protected int frustumVisible = 0;
	
	protected Dimension d = new Dimension();
	
	/*
	 * Colors
	 */
	Point3f activeColor = new Point3f(200.0f/255.0f, 64.0f/255.0f, 64.0f/255.0f);
	Point3f inActiveColor = new Point3f(200.0f/255.0f, 190.0f/255.0f, 190.0f/255.0f);

	/*
	 * Active frame
	 */
	protected boolean frameActive = true;

	protected int activeFrame = 0;	// 0=none; left=1; right=2
	public MainFrame frame;

	public String name;
	
	public GL gl;

	protected GLAutoDrawable glDrawable;

	protected Keys keys = new Keys();

	//private int quadId;

	/*
	 * Mouse related Vars.
	 */
	protected Mouse mouse = new Mouse();
	
	/*
	 * Raster fonts
	 */
	RasterFonts rf;
	
	/*
	 * We do the least amount of work possible in this block.
	 * Get the data and get out. We sync on where the database is.
	 */
	protected Database db;

	protected CameraBase camera;

	public GLRenderer(MainFrame frame) {
		this.frame = frame;
		synchronized (frame) {
			db = frame.getDatabase();
		}

	}

	public abstract void initializeGL();
	public abstract void resizeGL(int x, int y, int width, int height);
	
	/**
	 * This method is called by the OpenGL API event system.
	 */
	public void init(GLAutoDrawable drawable) {
		System.out.println("GLRenderer::init " + this);

		gl = drawable.getGL();
		glDrawable = drawable;	// Just in case I need it.
		
		db.setGL(gl);
		
		/*
		 * Set the background clear color
		 */
		db.setClearColor(220.0f/255.0f, 220.0f/255.0f, 240.0f/255.0f);
		
		db.enableArrays();
		
		gl.glPolygonMode(GL.GL_BACK, GL.GL_LINE);
		
        /*
         * Lighting
         */
        db.setupLighting();
        
		/*
		 * Enable the z-buffer
		 */
        db.enableZBuffer();
        
		/*
		 * Point size
		 */
        db.setPointAttributes();
		
		/*
		 * Fullsceen anti-aliasing
		 */
		db.enableBlending();
		db.enableAntiAliasing();
		
		db.enableCulling();
		
		db.setShadeModel();
		
		/*
		 * Initialze the font object
		 */
		rf = new RasterFonts(gl);
		
		/*
		 * Initialize the left and right sub class now that GL
		 * is setup.
		 */
		initializeGL();
		
	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
		System.out.println("GLRenderer::reshape " + height + "," + width);

		db.viewport.width = width;
		db.viewport.height = height;

		gl.glViewport(0, 0, width, height); // Reset The Current Viewport
		
		resizeGL(x, y, width, height);	// call sub classes
		
	}

	protected void setOrthographicProjection(int width, int height) {
		gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
		gl.glLoadIdentity(); // clear the projection matrix
//		gl.glOrtho(0.0f, width, height, 0.0f, 10.0f, -2000.0f);
		gl.glOrtho(0.0f, width, height, 0.0f, 1.0f, -1.0f);
//		gl.glOrtho(-width/2, width/2, -height/2, height/2, 10.0f, -2000.0f);
	}
	
	protected void setPerspectiveProjection(float fov, int width, int height, float near, float far) {
		gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
		gl.glLoadIdentity(); // reset the projection matrix
		
	}

	public void display(GLAutoDrawable drawable) {
//		System.out.println("GLRenderer::display");
		gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
		// Call inherited-class render method 
		render();
	}

	public void displayChanged(GLAutoDrawable drawable, boolean modeChanged,
			boolean deviceChanged) {
	}
	
	public void render() {
		/*
		 * Update projection type if a change was requested.
		 */
		if (projectionChange == 1 && frameActive) {
			projectionChange = 0;
			if (projectionType == 1) {
				gl.glMatrixMode(GL.GL_PROJECTION); // select the projection matrix
				gl.glLoadIdentity(); // clear the projection matrix
				float a = orthoZoomFactor;
				gl.glOrtho(-d.width/a, d.width/a, -d.height/a, d.height/a, -1000.0f, 2000.0f);
			} else {
				setPerspectiveProjection(camera.fov, d.width, d.height, camera.near, camera.far);
			}
		}
		
		/*
		 * Switch to the modelview matrix and reset it.
		 */
		gl.glMatrixMode(GL.GL_MODELVIEW);
		gl.glLoadIdentity();
		
		/*
		 * Place and orient this viewport's camera.
		 */
		gl.glLoadMatrixf(camera.getTransformArray(), 0);	// preferred.

		db.renderLights(gl);
		db.renderMisc(gl);
		db.renderOctree(gl);
		
	}
	
	public void mouseDragged(MouseEvent event) {}
	public void mouseMoved(MouseEvent arg0) {}
	public void mousePressed(MouseEvent event) {
		super.mousePressed(event);
	}
	public void mouseReleased(MouseEvent arg0) {
		super.mouseReleased(arg0);
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed(KeyEvent e) {
		
		if (keys.ckey == KeyEvent.VK_ESCAPE) {
			frame.exit();
		}

		keys.ckey = e.getKeyChar();
		
		switch (keys.ckey) {
		case 'z':
			orthoZoomFactor += 0.1f;
			projectionChange = 1;
			/*
			 * Enable if timer is turned off
			 */
			//glDrawable.display();
			break;
		case 'Z':
			projectionChange = 1;
			orthoZoomFactor -= 0.1f;
			break;
		case 'f':
			frustumVisible = (frustumVisible == 1) ? 0 : 1;
			break;
		case 'q':
			if (Heap.iToggle == 0)
				Heap.iToggle = 1;
			else
				Heap.iToggle = 0;
			break;
		}

		e.consume();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
	 */
	public void keyReleased(KeyEvent e) {
		e.consume();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
	 */
	public void keyTyped(KeyEvent e) {
		e.consume();
	}

	public void dumpGraphicDriverInfo() {

		System.out.println("GLRenderer::reshape GL_VENDOR: " + gl.glGetString(GL.GL_VENDOR));
		System.out.println("GLRenderer::reshape GL_RENDERER: " + gl.glGetString(GL.GL_RENDERER));
		System.out.println("GLRenderer::reshape GL_VERSION: " + gl.glGetString(GL.GL_VERSION));
		System.out.println();
		System.out.println("GLRenderer::reshape glLoadTransposeMatrixfARB() supported: "
				+ gl.isFunctionAvailable("glLoadTransposeMatrixfARB"));
		if (!gl.isFunctionAvailable("glLoadTransposeMatrixfARB")) {
			// --- not using extensions
			gl.glLoadIdentity();
		} else {
			// --- using extensions
			final float[] identityTranspose = new float[] { 1, 0, 0, 0, 0, 1,
					0, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
			gl.glLoadTransposeMatrixf(identityTranspose, 0);
		}
		
	}
}