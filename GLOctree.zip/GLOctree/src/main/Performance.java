/*
 * Created on Jan 6, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package main;


/**
 * @author wdevore
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Performance {
	public int frameCount = 0;
	public float previousFPS = 0.0f;
	
	/*
	 * frame per second vars.
	 */
	private long elapse = 0;
	private float aveElapse = 0.0f;
	private float accElapse = 0;
	private long averageCountElapse = 1;

	/* ******************************************************
	 * Methods
	 * ******************************************************
	 */
	public Performance() {
		accElapse = 0;
		averageCountElapse = 1;
		aveElapse = 0.0f;
	}

	public float getFramePerSecond(long t3, long t1) {
		elapse = t3 - t1;
		
		accElapse = accElapse + elapse;
		aveElapse = (float) accElapse / (float) averageCountElapse;
		averageCountElapse++;

		float average = 1000.0f/aveElapse;
//		System.out.println(average + " " + aveElapse);
		
		if (averageCountElapse > 100) {
			// reset average
			accElapse = 0;
			aveElapse = 0.0f;
			averageCountElapse = 1;
		}

		return average;
	}

	public float getFramePerSecond2(long t3, long t1) {
		if (frameCount > 99) {
			frameCount = 0;
			previousFPS = 100.0f/accElapse*1000.0f;
			accElapse = 0;
		} else {
			frameCount++;
			elapse = t3 - t1;
			if (elapse == 0)
				elapse += 0.5;
			accElapse = accElapse + elapse;
		}
		return previousFPS;
	}
}
