/*
 * Created on Jan 6, 2005
 *
 */
package main;

import glgraphics.GLRenderer;
import glgraphics.GLRendererBottomLeft;
import glgraphics.GLRendererBottomRight;
import glgraphics.GLRendererLeft;
import glgraphics.GLRendererRight;

import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
//import java.util.ArrayList;

import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
//import javax.media.opengl.GLDrawableFactory;

import com.sun.opengl.util.Animator;

import model.Database;

/**
 * @author wdevore
 *
 */
@SuppressWarnings("serial")
public class MainFrame extends Frame {
	// note: put in frame class
	private Database db;
	public Animator animator;
	GLRenderer renderer1;
	GLRenderer renderer2;
	GLRenderer renderer3;
	GLRenderer renderer4;
	GLCanvas canvas1;
	GLCanvas canvas2;
	GLCanvas canvas3;
	GLCanvas canvas4;
	
	public MainFrame(String s) {
		super(s);

		db = new Database();

		setBackground(Color.lightGray);
		/*
		 * Replace default layout with grid
		 */
		setLayout(new GridLayout(2,2,2,2));

	}
	
	public Database getDatabase() {
		return db;
	}
	
	public void initialize(int frameDelay, float frameScale, int lineAliasing) {
		/*
		 * Timer threads
		 */
		animator = new Animator();
		
		db.lineAliasing = lineAliasing;
		
		/*
		 * Left widget
		 */
		renderer1 = new GLRendererLeft(this);
		renderer1.name = "Left";
		
		GLCapabilities caps = new GLCapabilities();
		canvas1 = new GLCanvas(caps);
		canvas1.setName("Left");
		
		canvas1.addMouseMotionListener(renderer1);
		canvas1.addMouseListener(renderer1);
		canvas1.addGLEventListener(renderer1);
		canvas1.addKeyListener(renderer1);
		canvas1.setEnabled(true);

		addKeyListener(renderer1);
		add(canvas1);
		animator.add(canvas1);
		
		/*
		 * Right widget
		 */
		renderer2 = new GLRendererRight(this);
		renderer2.name = "Right";

		canvas2 = new GLCanvas(caps);
		canvas2.setName("Right");
		
		canvas2.addMouseMotionListener(renderer2);
		canvas2.addMouseListener(renderer2);
		canvas2.addGLEventListener(renderer2);
		canvas2.addKeyListener(renderer2);
		canvas2.setEnabled(true);

		addKeyListener(renderer2);
		add(canvas2);
		animator.add(canvas2);

		/*
		 * Bottom left
		 */
		renderer3 = new GLRendererBottomLeft(this);
		renderer3.name = "Right";

		canvas3 = new GLCanvas(caps);
		canvas3.setName("Right");
		
		canvas3.addMouseMotionListener(renderer3);
		canvas3.addMouseListener(renderer3);
		canvas3.addGLEventListener(renderer3);
		canvas3.addKeyListener(renderer3);
		canvas3.setEnabled(true);

		addKeyListener(renderer3);
		add(canvas3);
		animator.add(canvas3);
		
		/*
		 * Bottom right
		 */
		renderer4 = new GLRendererBottomRight(this);
		renderer4.name = "BottomLeft";

		canvas4 = new GLCanvas(caps);
		canvas4.setName("BottomLeft");
		
		canvas4.addMouseMotionListener(renderer4);
		canvas4.addMouseListener(renderer4);
		canvas4.addGLEventListener(renderer4);
		canvas4.addKeyListener(renderer4);
		canvas4.setEnabled(true);

		addKeyListener(renderer4);
		add(canvas4);
		animator.add(canvas4);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				exit();
			}
		});
		
		int width = (int)Math.round(1600/frameScale);
		int height = (int)Math.round(1200/frameScale);
		
		setSize(width, height);

		setVisible(true);
		
		/*
		 * Crank up the timers.
		 */
		animator.start();

	}
	
	public void exit() {
		animator.stop();
		System.exit(0);
	}
	
	
}
