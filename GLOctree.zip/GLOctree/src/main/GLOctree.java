package main;


public class GLOctree {
	public static void main(String[] args) {
		int frameDelay;
		float frameScale = 1.6f;
		int lineAliasing = 0;
		
		if (args.length >= 3) {
			frameDelay = Integer.parseInt(args[0]);
			frameScale = Float.parseFloat(args[1]);
			lineAliasing = Integer.parseInt(args[2]);
		} else {
			usage();
			frameDelay = 16;
			frameScale = 1.6f;
		}
		
		float f = 1000.0f/(float)frameDelay;
		System.out.println("Attempting to maintain approx. " + Math.round(f) + " fps.");
		
		MainFrame frame = new MainFrame("Java OpenGL Octree prototype");
		frame.initialize(frameDelay, frameScale, lineAliasing);
	}
	
	private static void usage() {
//		System.out.println("--- Just a reminder ---");
	}
}

