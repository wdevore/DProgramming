/*
 * Created on Jan 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package model;

import geometry.meshes.BoxMesh;
import geometry.meshes.SphereMesh;

import java.text.NumberFormat;

import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3f;

import math.Box;
import math.Cone;
import math.Cube;
import math.Sphere;

/**
 * @author wdevore
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Heap {
	public static Quat4f orientation = new Quat4f();
	public static AxisAngle4f aa = new AxisAngle4f();
	public static Vector3f v1 = new Vector3f();
	public static Vector3f v2 = new Vector3f();
	public static Vector3f v3 = new Vector3f();
	public static Vector3f v4 = new Vector3f();
	public static float[] av4f = new float[4];
	
	public static NumberFormat nf = NumberFormat.getNumberInstance();
	
	public static Matrix4f transform = new Matrix4f();
	public static Matrix3f rot = new Matrix3f();
	public static Matrix3f rot2 = new Matrix3f();
	public static Matrix3f rot3 = new Matrix3f();
	public static float[] rArray = new float[16];
	public static float[] rArray2 = new float[16];
	
	public static int appState = 1;

	public static SphereMesh sphereObj = new SphereMesh();
	public static BoxMesh boxObj = new BoxMesh();

	public static int iStatus;
	public static boolean bBtatus;

	public static int iCount;

	public static int iCullTrigger = 0;
	public static int iClippingEnabled = 0;

	public static int iToggle = 0;
	
	public static Box bBoxTransformed = new Box();
	public static Sphere bSphereTransformed = new Sphere();
	public static Cone bConeTransformed = new Cone();

	public static Cube bCube = new Cube();

	public static float iOffsetX = 0;
	public static float iOffsetZ = 0;
	
}
