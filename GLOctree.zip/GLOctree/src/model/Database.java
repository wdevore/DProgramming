/*
 * Created on Jan 4, 2005
 *
 */
package model;

import geometry.meshes.TrianglesMesh;
import geometry.objects.FrustumObject;
import geometry.objects.MultiColorLinesObject;
import geometry.objects.Object3D;
import geometry.objects.TrianglesObject;
import glgraphics.Viewport;
import glgraphics.lights.GLDirectionalLight;
import glgraphics.lights.GLLightBase;
import input.FileInput;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.ListIterator;

import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;

import math.BoundingVolume;
import math.Cone;
import math.Frustum;
import math.Sphere;
import math.VectorAlgebra;
import javax.media.opengl.GL;

import com.sun.opengl.util.BufferUtil;

import octree.Octree;
import views.ArcballOrbit;
import views.ArcballPan;
import views.CameraBase;
import views.ICamera;

/**
 * The Database will contain the Octree and mesh data. It will
 * maintain cache coherence between the GPU and the application.
 * 
 */
public class Database {
	/*
	 * OpenGL drawable
	 */
	private GL gl;
	
	/*
	 * Viewport 
	 */
	public Viewport viewport = new Viewport();
	
	/*
	 * cameras
	 */
	public CameraBase cameraLeft;
	public CameraBase cameraRight;
	public CameraBase cameraBottomLeft;
	public CameraBase cameraBottomRight;
	
	/*
	 * Array of Object3Ds
	 */
	private ArrayList<Object3D> objects = new ArrayList<Object3D>();

	/*
	 * Collection of culled objects from Octree.
	 */
	ArrayList<ArrayList<Object3D>> collection;
	
	/*
	 * Array of Lights
	 */
	private ArrayList<GLLightBase> lights = new ArrayList<GLLightBase>();

	/*
	 * Array of Display icons
	 */
	private ArrayList<Object3D> displayObjects = new ArrayList<Object3D>();

	/*
	 * GL Array pointer indicators
	 */
	private boolean colorArrayUsed = false;
	private boolean normalArrayUsed = false;
	//private boolean textureArrayUsed = false;
	
	/*
	 * Line antialiasing
	 */
	public int lineAliasing;
	
	/*
	 * The Octree
	 */
	private Octree octree = null;
	
	/* ************************************************************************
	 * Methods
	 * ************************************************************************
	 */
	public Database() {
		
		addShadeSphere(10*2, 10, 10.0f, 22.0f, -10.0f, 50.0f, false, 255, 128, 32);
		addShadeSphere(10*2, 10, 1.0f, 30.0f, 6.0f, 40.0f, false, 255, 128, 32);
		addShadeSphere(10*2, 10, 1.0f, 30.0f, -6.0f, -60.0f, false, 255, 128, 32);
		addShadeSphere(10*2, 10, 2.0f, 30.0f, 20.0f, -20.0f, false, 255, 128, 32);
		addFlatTriangleMesh(1.0f, -10.0f, -5.0f, 5.0f);
		addFlatTriangleMesh(1.0f, -10.0f, -6.0f, 6.0f);
		addFlatTriangleMesh(1.0f, -5.0f, -7.0f, 7.0f);
		addFlatTriangleMesh(1.0f, -5.0f, -8.0f, 8.0f);
		addFlatTriangleMesh(1.0f, -15.0f, -8.0f, 10.0f);
		addFlatTriangleMesh(1.0f, -15.0f, -8.0f, 11.0f);
		addFlatTriangleMesh(1.0f, -15.0f, -8.0f, 11.0f);

		//addFlatTriangleMesh(0.2f, -13.0f, 25.0f, 20.0f);
//		addSmoothTriangleMesh();

		addShadeCylinder(16, 
				10.0f, 10.0f, 
				1.0f, 1.0f, 
				10.0f/2.0f, -10.0f/2.0f, 
				10.0f, 
				30.0f, 30.0f, 10.0f, 
				false, 
				32, 228, 255);

		addShadeCylinder(20,
				10.0f, 10.0f,
				10.0f, 10.0f,
				10.0f/2.0f, -10.0f/2.0f,
				10.0f,
				20.0f, 0.0f, 20.0f,
				false,
				32, 228, 255);

//		for (float x = -200.0f; x < 200.0f; x += 100.0f) {
//			for (float z = -200.0f; z < 200.0f; z += 100.0f) {
////				addShadeCylinder(16, 5.0f, 5.0f, 5.0f, 5.0f, 10.0f, -10.0f, 10.0f, x, 0.0f, z, false, 32, 228, 255);
//				addFlatTriangleMesh(1.0f, x, 5.0f, z);
//			}
//		}

		//TrianglesObject o;// = loadObject("src/model/torus202.dat");
		//o.renderNormals(false);
		
		//o = loadObject("src/model/sph320.dat");
		//o.renderNormals(false);
		
		addGrid(10, 10, 1, 1, 1, 1, 1);
		addTripod(10.0f);
		
		addDirectionalLight(-40.0f, 40.0f, 40.0f, 0.0f, 0.0f, 0.0f);
		
		octree = new Octree();
		
		octree.init(this);
		
//		cameraLeft = new ArcballOrbit("left");
		cameraLeft = new ArcballPan("left");
//		cameraLeft.lookAt(new Vector3f(30.0f, 30.0f, 30.0f), new Vector3f(0.0f, 0.0f, 0.0f), new Vector3f(0.0f, 1.0f, 0.0f));
		cameraLeft.fov = 45.0f;
		cameraLeft.far = 300.0f;
		Heap.v1.set(octree.getMaxExtent());
		Heap.v1.scale(1.0f/1.5f);
		cameraLeft.lookAt(Heap.v1, octree.getCenter(), new Vector3f(0.0f, 1.0f, 0.0f));
		
		cameraRight = new ArcballOrbit("right");
//		cameraRight = new ArcballPan("right");
		cameraRight.lookAt(new Vector3f(100.0f, 200.0f, 100.0f), new Vector3f(10.0f, 5.0f, 5.0f), new Vector3f(0.0f, 1.0f, 0.0f));

		cameraBottomLeft = new ArcballOrbit("bottomleft");
		cameraBottomLeft.lookAt(new Vector3f(0.0f, 150.0f, 150.0f), new Vector3f(0.0f, 0.0f, 0.0f), new Vector3f(0.0f, 1.0f, 0.0f));
		
		cameraBottomRight = new ArcballPan("bottomright");
		cameraBottomRight.lookAt(new Vector3f(-50.0f, 50.0f, 50.0f), new Vector3f(10.0f, 5.0f, 5.0f), new Vector3f(0.0f, 1.0f, 0.0f));

	}
	
	public ArrayList<Object3D> getObjects() {
		return objects;
	}
	public ArrayList<Object3D> getDisplayObjects() {
		return displayObjects;
	}
	public ArrayList<GLLightBase> getLights() {
		return lights;
	}
	
	/* **********************************************************************
	 * Geometry methods
	 */
	private void addShadeSphere(int long_segments, int lat_segments, float radius, float px, float py, float pz, boolean animate, int r, int g, int b) {
		TrianglesObject o = new TrianglesObject();
		o.setColor(r/256.0f, g/256.0f, b/256.0f, 1.0f);
		o.setPosition(px, py, pz);
		o.setName("sphere");
		
		o.setShadeModel(TrianglesMesh.SMOOTH);
		o.setOutlineMode(false);
		o.renderNormals(false);
		
		float long_step = (float)Math.toRadians(360.0f/(float)long_segments);
		float lat_step = (float)Math.toRadians(360.0f/(float)lat_segments/2);
		
		Vector3f p = new Vector3f();	// -Y axis
		p.set(0.0f, -1.0f, 0.0f);
		Vector3f p2 = new Vector3f();	// -Y axis
		
		AxisAngle4f aaY = new AxisAngle4f();
		AxisAngle4f aaX = new AxisAngle4f();
		
		Matrix4f mlong = new Matrix4f();
		Matrix4f mlat = new Matrix4f();
		Vector3f p1 = new Vector3f();
		//Vector3f c1 = new Vector3f();
		
		// bottom cap
		p1.set(0.0f, -radius, 0.0f);
		o.addVertex(p1);

		float long_angle = 0.0f;
		float lat_angle = lat_step; // skip bottom as there is only one vertex
		
		for (int lat = 0; lat < lat_segments-1; lat++) {
			aaX.set(1.0f, 0.0f, 0.0f, -lat_angle);
			mlat.setIdentity();
			mlat.setRotation(aaX);
			for (int i = 0; i < long_segments; i++) {
				aaY.set(0.0f, 1.0f, 0.0f, long_angle);
				mlong.setIdentity();
				mlong.setRotation(aaY);
				mlong.mul(mlat);
				mlong.transform(p, p2);
				p2.scale(radius);
				p1.set(p2.x, p2.y, p2.z);
				o.addVertex(p1);

				long_angle += long_step;
			}
			long_angle = 0.0f;
			lat_angle += lat_step;
		}
		
		// top Cap
		p1.set(0.0f, radius, 0.0f);
		o.addVertex(p1);

		// Add face definition
		int i1;
		int i2;
		int i3;
		int i4;
		
		int vertexcount = o.getVertexCount();
		// Top cap faces
		i1 = (lat_segments-2)*long_segments + 1;
		i2 = i1 + 1;
		i3 = vertexcount - 1;
		for (int i = 0; i < long_segments - 1; i++) {
			o.addFace(i1, i2, i3);
			i1++;
			i2++;
		}
		o.addFace(i1, (lat_segments-2)*long_segments + 1, i3);

		// Middle faces
		i1 = 1;
		i2 = i1 + 1;
		i4 = long_segments + 1;
		i3 = i4 + 1;
		int i5 = i1;
		int i6 = i4;
		vertexcount = i1;
		for (int j = 0; j < lat_segments - 2; j++) {
			for (int i = 0; i < long_segments - 1; i++) {
				o.addFace(i1, i2, i3);
				o.addFace(i1, i3, i4);
				i1++;
				i2++;
				i3++;
				i4++;
				vertexcount++;
			}
			o.addFace(i1, i5, i6);
			o.addFace(i1, i6, i4);
			i1 = vertexcount + (j+1);
			i2 = i1 + 1;
			i4 = (long_segments * (j+2)) + 1;
			i3 = i4 + 1;
			i5 = i1;
			i6 = i4;
		}

		// Bottom cap faces
		i1 = 1;
		i2 = 2;
		i3 = 0;
		for (int i = 0; i < long_segments - 1; i++) {
			o.addFace(i1, i3, i2);
			i1++;
			i2++;
		}
		o.addFace(i1, i3, 1);
		
		
		// Calc Normals
		o.calcNormals();
		o.calcBBox();

		o.pack();
		
		objects.add(o);
	}

	/**
	 * 
	 * @param segments 2 or greater
	 * @param rTop_w top radius width (X)
	 * @param rTop_d top radius depth (Z)
	 * @param rBot_w bottom radius width
	 * @param rBot_d bottom radius depth
	 * @param cTop_h top center height 
	 * @param cBot_h bottom center height
	 * @param height distance from top cap to bottom cap
	 * @param px position
	 * @param py
	 * @param pz
	 * @param animate TRUE, FALSE
	 * @param r color
	 * @param g
	 * @param b
	 */
	private void addShadeCylinder(int segments, float rTop_w, float rTop_d, float rBot_w, float rBot_d, float cTop_h, float cBot_h, float height, float px, float py, float pz, boolean animate, int r, int g, int b) {
		TrianglesObject o = new TrianglesObject();
		o.setColor(r/256.0f, g/256.0f, b/256.0f, 1.0f);
		
		o.setName("Cylinder");
		o.setPosition(px, py, pz);
		o.renderNormals(false);
		o.setShadeModel(TrianglesMesh.SMOOTH);
		o.setOutlineMode(true);
		
		Vector3f p1 = new Vector3f();
		//Vector3f c1 = new Vector3f();

		// top cap vertex
		p1.set(0.0f, cTop_h, 0.0f);
		o.addVertex(p1);

		// index 1 to segments
		float step = (float)Math.toRadians(360.0f/(float)segments);
		float xa = 0.0f;
		for (int i = 0; i < segments; i++) {
			float rx1 = rTop_w * (float)Math.sin(xa);
			float rz1 = rTop_d * (float)Math.cos(xa);
			p1.set(rx1, -height/2.0f, rz1);
			o.addVertex(p1);
			xa += step;
		}
		
		// segments * 2
		xa = 0.0f;
		for (int i = 0; i < segments; i++) {
			float rx1 = rBot_w * (float)Math.sin(xa);
			float rz1 = rBot_d * (float)Math.cos(xa);
			p1.set(rx1, height/2.0f, rz1);
			o.addVertex(p1);
			xa += step;
		}

		// bottom vertex Cap (index 0)
		p1.set(0.0f, cBot_h, 0.0f);
		o.addVertex(p1);

		int i1 = 1;
		int i2 = 2;
		int i3 = segments + 1;
		int i4 = segments + 2;
		
		// side
		for (int i = 0; i < segments - 1; i++) {
			o.addFace(i1, i2, i3);
			o.addFace(i2, i4, i3);
			i1++;
			i2++;
			i3++;
			i4++;
		}
		o.addFace(i1, 1, i3);
		o.addFace(1, i2, i3);
		
		// top cap.
		i1 = segments + 1;
		i2 = segments + 2;
		i3 = 0;
		for (int i = 0; i < segments - 1; i++) {
			o.addFace(i1, i2, i3);
			i1++;
			i2++;
		}
		o.addFace(i1, segments + 1, i3);
		
		// bottom cap.
		i1 = 1;
		i2 = 2;
		i3 = 2*segments + 1;
		for (int i = 0; i < segments - 1; i++) {
			o.addFace(i1, i3, i2);
			i1++;
			i2++;
		}
		o.addFace(i1, i3, 1);
		
		o.calcNormals();
		o.calcBBox();
		
		o.pack();
		
		objects.add(o);
	}

	private void addGrid(int long_segments, int lat_segments, float width, float height, int r, int g, int b) {
		MultiColorLinesObject lo;
		
		lo = new MultiColorLinesObject();
		lo.setName("Grid");

		int iRange = 1;

		Vector3f c1 = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f v3 = new Vector3f();
		
		float fStartu = -10.0f * (float) Math.pow(10.0, iRange) * 2.0f;
		float fStartv = -10.0f * (float) Math.pow(10.0, iRange) * 2.0f;
		float fLength = 2.0f * Math.abs(fStartv);
		float flongStep = long_segments;
		float flatStep = lat_segments;

		float u = fStartu;
		float v = fStartv;
		for (; v <= -fStartv; v += flongStep) {
			if (v == 0.0 || v == -fStartv || v == fStartv) {
				c1.set(0.5f, 0.0f, 0.0f);
			} else {
				c1.set(0.8f, 0.8f, 0.8f);
			}
			
			v2.set(u, -0.01f, v);// lines parallel to x-axis
			v3.set(u + fLength, -0.01f, v);
			lo.addLine(v2, v3, c1, c1);
		}
		v = fStartv;
		for (; u <= -fStartu; u += flatStep) { // march along the z axis
			if (u == 0.0 || u == -fStartu || u == fStartu)
				c1.set(0.5f, 0.0f, 0.0f);
			else
				c1.set(0.8f, 0.8f, 0.8f);

			v2.set(u, -0.1f, v);// lines parallel to x-axis
			v3.set(u, -0.1f, v + fLength);
			lo.addLine(v2, v3, c1, c1);
		}

		lo.pack();
		
		colorArrayUsed = true;

		displayObjects.add(lo);
	}

	private void addTripod(float scale) {
		MultiColorLinesObject o;
		//Vector3f c1 = new Vector3f();
		Vector3f c2 = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f v3 = new Vector3f();
//		c1.set(1.0f, 1.0f, 1.0f);
		
		o = new MultiColorLinesObject();
		o.setName("+X");	// red
		c2.set(1.0f, 0.0f, 0.0f);
		v2.set(0.0f, 0.01f, 0.0f);
		v3.set(1.0f*scale, 0.01f, 0.0f);
		o.addLine(v2, v3, c2, c2);

		o.setName("+Y");	// blue
		c2.set(0.0f, 0.0f, 1.0f);
		v2.set(0.0f, 0.01f, 0.0f);
		v3.set(0.0f, 1.0f*scale, 0.0f);
		o.addLine(v2, v3, c2, c2);
		
		o.setName("+Z");	// green
		c2.set(0.0f, 1.0f, 0.0f);
		v2.set(0.0f, 0.01f, 0.0f);
		v3.set(0.0f, 0.0f, 1.0f*scale);
		o.addLine(v2, v3, c2, c2);

		o.pack();
		colorArrayUsed = true;

		displayObjects.add(o);
	}

	@SuppressWarnings("unused")
	private void addSmoothTriangleMesh() {
		Vector3f v1 = new Vector3f();
		
		TrianglesObject o = new TrianglesObject();
		o.setName("Tri");
		o.setColor(0.5f, 0.0f, 1.0f, 1.0f);
		o.setPosition(0.0f, 0.0f, 0.0f);
		o.renderNormals(true);
		o.setShadeModel(TrianglesMesh.SMOOTH);
		
		v1.set(-10.0f, 0.0f, 0.0f);
		o.addVertex(v1);
		v1.set(10.0f, 0.0f, 0.0f);
		o.addVertex(v1);
		v1.set(-10.0f, 10.0f, 0.0f);
		o.addVertex(v1);
		v1.set(10.0f, 10.0f, 0.0f);
		o.addVertex(v1);
		v1.set(10.0f, 0.0f, -20.0f);
		o.addVertex(v1);
		v1.set(10.0f, 10.0f, -20.0f);
		o.addVertex(v1);

		o.addFace(0, 1, 2);
		o.addFace(1, 3, 2);
		o.addFace(1, 4, 3);
		o.addFace(4, 5, 3);

		o.calcNormals();
		
		o.calcBBox();
		
		o.pack();

		normalArrayUsed = true;

		objects.add(o);
	}

	@SuppressWarnings("unused")
	private void addFlatTriangleMesh(float s, float x, float y, float z) {
		//Vector3f v1 = new Vector3f();
		
		TrianglesObject o = new TrianglesObject();
		o.setName("Tri");
		o.setColor(0.5f, 0.0f, 1.0f, 1.0f);
		o.setPosition(x, y, z);
		o.renderNormals(false);
		o.setShadeModel(TrianglesMesh.FLAT);
		
		Heap.v1.set(-s, 0.0f, 0.0f);
		Heap.v2.set(s, 0.0f, 0.0f);
		Heap.v3.set(-s, s, 0.0f);
		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);
		Heap.v1.set(s, 0.0f, 0.0f);
		Heap.v2.set(s, s, 0.0f);
		Heap.v3.set(-s, s, 0.0f);
		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);
		
//		Heap.v1.set(10.0f, 0.0f, 0.0f);
//		Heap.v2.set(10.0f, 0.0f, -20.0f);
//		Heap.v3.set(10.0f, 10.0f, 0.0f);
//		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);
//		Heap.v1.set(10.0f, 0.0f, -20.0f);
//		Heap.v2.set(10.0f, 10.0f, -20.0f);
//		Heap.v3.set(10.0f, 10.0f, 0.0f);
//		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);

		o.calcNormals();
		
		o.calcBBox();
		
		o.pack();

		normalArrayUsed = true;

		objects.add(o);
	}

	@SuppressWarnings("unused")
	private void addBoxMesh(float s, float x, float y, float z, float r, float g, float b) {
		//Vector3f v1 = new Vector3f();
		
		TrianglesObject o = new TrianglesObject();
		o.setName("Tri");
		o.setColor(0.5f, 0.0f, 1.0f, 1.0f);
		o.setPosition(x, y, z);
		o.renderNormals(false);
		o.setShadeModel(TrianglesMesh.FLAT);
		
		Heap.v1.set(-s, 0.0f, 0.0f);
		Heap.v2.set(s, 0.0f, 0.0f);
		Heap.v3.set(-s, s, 0.0f);
		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);
		Heap.v1.set(s, 0.0f, 0.0f);
		Heap.v2.set(s, s, 0.0f);
		Heap.v3.set(-s, s, 0.0f);
		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);
		
//		Heap.v1.set(10.0f, 0.0f, 0.0f);
//		Heap.v2.set(10.0f, 0.0f, -20.0f);
//		Heap.v3.set(10.0f, 10.0f, 0.0f);
//		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);
//		Heap.v1.set(10.0f, 0.0f, -20.0f);
//		Heap.v2.set(10.0f, 10.0f, -20.0f);
//		Heap.v3.set(10.0f, 10.0f, 0.0f);
//		o.addTriangle(Heap.v1, Heap.v2, Heap.v3);

		o.calcNormals();
		
		o.calcBBox();
		
		o.pack();

		normalArrayUsed = true;

		objects.add(o);
	}

	private void addDirectionalLight(float px, float py, float pz, float tx, float ty, float tz) {
		GLDirectionalLight l = new GLDirectionalLight();
		l.setAmbient(0.2f, 0.2f, 0.2f, 1.0f);
		l.setDiffuse(0.7f, 0.7f, 0.7f, 1.0f);
		
		Matrix3f rot = new Matrix3f();
		
		Vector3f v = new Vector3f(tx, ty, tz);
		Vector3f v2 = new Vector3f(px, py, pz);
		/*
		 * This is the direction the light is going.
		 * It is traveling in the direction from "p" to "t"
		 */
		v.sub(v2);	// t - p

		/*
		 * Calculate a rotation that will rotate from the -z-axis
		 * to the vector "v".
		 */
		rot.set(VectorAlgebra.getColLinearRotation(v));
		
		Vector3f t = new Vector3f(0.0f, 0.0f, -1.0f);

		rot.transform(t, v2);

		v2.normalize();
		
		/*
		 * We negate because we want to specify
		 * where it is coming from and NOT where it is going to. 
		 */
		v2.negate();

		l.setDirection(v2.x, v2.y, v2.z);
		
		l.setIconPosition(px, py, pz);
		l.name = "Light0";
		
		lights.add(l);
	}
	
	@SuppressWarnings("unused")
	private float RandomR(double start, double end) {
		if (start == end)
			return (float)Math.random();
		else
			return (float)(Math.random()*(end-start) + start);
	}

	@SuppressWarnings("unused")
	private TrianglesObject loadObject(String filename) {
		TrianglesObject o = new TrianglesObject();
		o.setShadeModel(TrianglesMesh.SMOOTH);
		
		Vector3f p1 = new Vector3f();
		
		// a loaded object
		if (filename.length() != 0) {
			System.out.println("Opening object " + filename);
			FileInput file = new FileInput(filename);
			if (file.fails()) {
				System.err.println("Failed to open object " + filename);
				return null;
			}
			int objectType = file.readInt();
			System.out.println("ObjectType = " + objectType);
			int lighting = file.readInt();
			System.out.println("Lighting = " + lighting);
			int drawMode = file.readInt();
			System.out.println("Drawmode = " + drawMode);
			int loadType = file.readInt();
			System.out.println("LoadType = " + loadType);
			int shadeModel = file.readInt();
			System.out.println("Shademode = " + shadeModel);

			o.setName("File object");

			// Object's color
			int r = file.readInt();
			int g = file.readInt();
			int b = file.readInt();
			o.setColor(r/256.0f, g/256.0f, b/256.0f, 1.0f);

			float x = file.readFloat();
			float y = file.readFloat();
			float z = file.readFloat();
			o.setPosition(x, y, z);

			float sx = file.readFloat();
			float sy = file.readFloat();
			float sz = file.readFloat();
			
			///////////////////////////
			// load vertices and the associated color
			///////////////////////////
			int vertices = file.readInt();
			System.out.println("Reading " + vertices + " vertices");
			for (int i = 0; i < vertices; i++) {
				//int l = file.readInt();
				x = file.readFloat();
				y = file.readFloat();
				z = file.readFloat();
				p1.set(x*sx, y*sy, z*sz);
				o.addVertex(p1);
			}

			///////////////////////////
			// load faces
			///////////////////////////
			int faceCount = 0;
			System.out.println("Reading faces");
			do {
				int i1 = file.readInt();
				if (i1 < 0) {
					break;
				}
				faceCount++;
				int i2 = file.readInt();
				int i3 = file.readInt();
				o.addFace(i1-1, i2-1, i3-1);
				if (loadType == 2) { // Torus?
					int i4 = file.readInt();
					o.addFace(i4-1, i1-1, i3-1);
				}
				file.readChar();
			} while (!file.eof());

			System.out.println(faceCount + " faces read.");
			
			o.calcNormals();
			o.calcBBox();

			o.pack();
			
			objects.add(o);
		}
		return o;
	}

	/* *********************************************************************
	 * OpenGL methods
	 */
	public void setGL(GL gl) {
		this.gl = gl;
		int[] count = new int[1];
		
		// How many clipping planes are there?
		gl.glGetIntegerv(GL.GL_MAX_CLIP_PLANES, count, 0);
		System.out.println("Maximum clipping planes: " + count[0]);
	}
	
	public void enableArrays() {
        gl.glEnableClientState(GL.GL_VERTEX_ARRAY);
        if (colorArrayUsed)
        	gl.glEnableClientState(GL.GL_COLOR_ARRAY);
        if (normalArrayUsed)
        	gl.glEnableClientState(GL.GL_NORMAL_ARRAY);
	}
	
	public void setClearColor(float r, float g, float b) {
		gl.glClearColor(r, g, b, 1.0f);
	}
	
	public void setShadeModel() {
		gl.glShadeModel(GL.GL_FLAT);
//		gl.glShadeModel(GL.GL_SMOOTH);
	}

	public void setPointAttributes() {
		gl.glPointSize(4);
	}
	
	public void enableCulling() {
		gl.glEnable(GL.GL_CULL_FACE);
		gl.glFrontFace(GL.GL_CCW);
//		gl.glFrontFace(GL.GL_CW);
	}

	public void enableClippingPlanes(GL gl) {
		gl.glEnable(GL.GL_CLIP_PLANE0);
		gl.glEnable(GL.GL_CLIP_PLANE1);
		gl.glEnable(GL.GL_CLIP_PLANE2);
		gl.glEnable(GL.GL_CLIP_PLANE3);
		gl.glEnable(GL.GL_CLIP_PLANE4);
		gl.glEnable(GL.GL_CLIP_PLANE5);
	}

	public void disableClippingPlanes(GL gl) {
		gl.glDisable(GL.GL_CLIP_PLANE0);
		gl.glDisable(GL.GL_CLIP_PLANE1);
		gl.glDisable(GL.GL_CLIP_PLANE2);
		gl.glDisable(GL.GL_CLIP_PLANE3);
		gl.glDisable(GL.GL_CLIP_PLANE4);
		gl.glDisable(GL.GL_CLIP_PLANE5);
	}

	public void setupLighting() {
		gl.glEnable(GL.GL_LIGHTING);
        
		/*
		 * Enable color tracking
		 */
		gl.glEnable(GL.GL_COLOR_MATERIAL);
		
		/*
		 * Set the material properties to follow glColor values
		 */
		gl.glColorMaterial(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE);
		
    	// global Light properties: Ambient
        FloatBuffer a = BufferUtil.newFloatBuffer(4);
        a.put(0.2f);
        a.put(0.2f);
        a.put(0.2f);
        a.put(1.0f);
        gl.glLightModelfv(GL.GL_LIGHT_MODEL_AMBIENT, a);
        
        // global Material properties: ambient and diffuse
        // These will overridden if glColorMaterial is used.
        a.put(0, 0.4f);
        a.put(1, 0.4f);
        a.put(2, 0.4f);
        a.put(3, 1.0f);
        gl.glMaterialfv(GL.GL_FRONT, GL.GL_AMBIENT_AND_DIFFUSE, a);
        
		ListIterator<GLLightBase> it = lights.listIterator(0);
		
		while (it.hasNext()) {
			GLLightBase o = (GLLightBase)it.next();
			if (o.name.compareTo("Light0") == 0) {
				GLDirectionalLight l = (GLDirectionalLight)o;
				gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, l.getAmbient(), 0);
				gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, l.getDiffuse(), 0);
				gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, l.getDirection(), 0);
				gl.glEnable(GL.GL_LIGHT0);
			}

		}

        
	}
	
	public void enableZBuffer() {
        gl.glEnable(GL.GL_DEPTH_TEST);
		gl.glEnable(GL.GL_DEPTH_BUFFER_BIT);
	}

	public void enableBlending() {
		gl.glEnable(GL.GL_BLEND);
		gl.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA);
	}
	
	public void enableAntiAliasing() {
		
		/*
		 * Enable for anti aliased lines.
		 */
		if (lineAliasing == 1) {
			gl.glEnable(GL.GL_LINE_SMOOTH);
			gl.glHint(GL.GL_LINE_SMOOTH_HINT, GL.GL_NICEST);
		}
		
		/*
		 * Enable if you want smooth points.
		 */
//		gl.glEnable(GL.GL_POINT_SMOOTH);
//		gl.glHint(GL.GL_POINT_SMOOTH_HINT, GL.GL_NICEST);
		
		/*
		 * I would only enable this if you have a workstation class card.
		 */
//		gl.glEnable(GL.GL_POLYGON_SMOOTH);
//		gl.glHint(GL.GL_POLYGON_SMOOTH_HINT, GL.GL_NICEST);
	}
	
	/*
	 * This method is called by the master viewport which for the prototype
	 * is the top left viewport. The other viewports do NOT call this method
	 * otherwise you would redundantly cull wasting cpu cycles.
	 */
	public void cullOctree(FrustumObject fo, ICamera camera) {
		collection = octree.getObjects(fo, camera);
	}
	
	public int renderObjects(GL gl, FrustumObject fo, ICamera camera) {
		int objectCount = 0;
		
		if (Heap.iCullTrigger == 0) {
			// Culling turned off.
			ListIterator<Object3D> o_it = objects.listIterator(0);
			while (o_it.hasNext()) {
				Object3D o = o_it.next();
				o.render(gl, true, 1.0f, 1.0f, 1.0f);
			}
		} else {
//			renderFrustumCulled(gl, fo, camera);
			objectCount = renderOctreeCulled(gl);
		}
		
		return objectCount;
	}

	/*
	 * Potentially Visible Objects (POV)s.
	 * They are POVs because the bounding box is not
	 * spatially exact in most cases. An example would be a box bounding a
	 * sphere. A sphere's volume is 4/3 * PI * Radius^3 and a box is obviously
	 * base*height*width = 8r^3. If we subtract sphere from box we don't get 0 we get
	 * (4/3*PI-8)r^3 Or we can safely say that 8r^3 not equal to 4/3PIr^3.	 * 
	 */
	
	/**
	 * This method uses a Frustum to cull against an octree to get POVS.
	 * 
	 * @param gl
	 * @param fo frustum to cull against.
	 * @param camera
	 */
	public int renderOctreeCulled(GL gl) {
		ArrayList<Object3D> subCollection;	// A collection of objects
		ListIterator<Object3D> sc_it;	// sub-collection iterator
		Object3D obj; // A single object
		
		/*
		 * The collection is null if the frustum doen't intersect the octree at
		 * all. Hence there are no objects to render.
		 *
		 * This condition can either very rare or very common depending on how
		 * the tree is used. Examples:
		 * 
		 * If the tree is used to contain the world then the frustum should
		 * never go completely beyond the bounds of the tree.
		 * 
		 * If the tree is a sub-tree of a greater volume then it is perfectly
		 * reasonable for the frustum to be completely outside of the
		 * sub-tree.
		 */
		if (collection == null) {
			return 0;
		}
		
		/*
		 * The frustum intersected the octree but none of the child BVs
		 * intersected. Again no objects to render.
		 */
		if (collection.isEmpty()) {
			return 0;
		}
		
		/*
		 * A collection of collections of Objects was returned. Ex:
		 * 
		 * Collection of
		 * 				\--> Collection of
		 * 								\--> Objects
		 * 
		 * To render we need to iterate each collection and then iterate within
		 * each collection to access each object.
		 */
		ListIterator<ArrayList<Object3D>> c_it = collection.listIterator(0);
		while (c_it.hasNext()) {
			subCollection = c_it.next();
			sc_it = subCollection.listIterator(0);
			while (sc_it.hasNext()) {
				obj = sc_it.next();
				obj.render(gl, true, 1.0f, 1.0f, 1.0f);
			}
		}
		
		return collection.size();
	}
	
	/**
	 * This method renders objects culled against a frustum. The frustum should
	 * already be extracted from OpenGL prior to calling this method.
	 * @param gl GL context object
	 * @param fo Frustum object
	 * @param camera a camera that matches with the Frustum object
	 */
	public void renderFrustumCulled(GL gl, FrustumObject fo, ICamera camera) {
		ListIterator<Object3D> o_it = objects.listIterator(0);
		
		while (o_it.hasNext()) {
			Object3D o = (Object3D)o_it.next();

			/*
			 * First check if the object's BV sphere has intersected the
			 * Frustums's BV sphere.
			 */
			BoundingVolume bv = o.getBoundingVolumeTransformed();	// Object's BV in world space
			
			bv.bSphere.set(o.getWorldSphere(null)); 
			
			Sphere fs = fo.getWorldSphere(camera.getInverseTransformMatrix());
			
			int iStatus = fs.intersects(bv.bSphere);
			if (iStatus == Sphere.NONINTERSECTING) {
				/*
				 * The object and frustum Bounding spheres are not
				 * intersecting. Just render the BVs
				 */
				o.render(gl, false, 0, 0, 0);
				continue;
			}
			
			/*
			 * The object's Bounding sphere and Frustum's Bounding
			 * sphere intersect. 
			 * Now check if object's Bounding sphere intersects the
			 * frustum's Bounding cone.
			 */
			Cone cone = fo.getWorldCone(camera.getInverseTransformMatrix());
			iStatus = VectorAlgebra.sphereIntersectCone(bv.bSphere, cone);
			if (iStatus == VectorAlgebra.OUTSIDE) {
				/*
				 * The object's Bounding sphere and the frustum's
				 * Bounding cone are not intersecting.
				 */
				o.render(gl, false, 0, 0, 0.8f);
				continue;
			}
			
			/*
			 * The object's sphere and Frustum's cone intersect.
			 * Now we check to see if the object's Bounding sphere
			 * intersects's the frustum itself.
			 */
			iStatus = fo.sphereIntersectFrustum(bv.bSphere);
			if (iStatus == Frustum.OUTSIDE) {
				/*
				 * The object's Bounding sphere and the frustum's
				 * frustum are not intersecting.
				 */
				o.render(gl, false, 1.0f, 1.0f, 0);
				continue;
			}
			
			/*
			 * The object's Bounding sphere is intersecting the
			 * Frustum's Bounding sphere. Now we check further to
			 * see if the object's Bounding box intersects the
			 * frustum.
			 */
			bv.bBox.set(o.getWorldBox(null)); 
			iStatus = fo.boxIntersectFrustum(bv.bBox);
			if (iStatus == Frustum.OUTSIDE) {
				/*
				 * The object's Bounding box and the frustum's
				 * frustum are not intersecting.
				 */
				o.render(gl, false, 1.0f, 0.0f, 0.8f);
				continue;
			}
			
			/*
			 * The object's Bounding box is intersecting
			 * the frustum. It is considered visible.
			 */
			o.render(gl, true, 1.0f, 1.0f, 1.0f);
		}
	}
	
	public void renderLights(GL gl) {
		// Render light icons
		ListIterator<GLLightBase> it = lights.listIterator(0);
		while (it.hasNext()) {
			GLLightBase o = it.next();
			if (o instanceof GLDirectionalLight) {
				GLDirectionalLight dl = (GLDirectionalLight)o;
				dl.render(gl);
			}
		}
	}
	
	public void renderMisc(GL gl) {
		/*
		 * Render Icons and helper objects last in case they have tranparencies.
		 */
		ListIterator<Object3D> o_it = displayObjects.listIterator(0);

		while (o_it.hasNext()) {
			Object3D o = o_it.next();
			o.render(gl, true, 0, 0, 0);
//			if (o.name.compareTo("Grid") == 0) {
//				gl.glPushMatrix();
//				gl.glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
//				o.render(gl, true);
//				gl.glPopMatrix();
//				gl.glPushMatrix();
//				gl.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
//				o.render(gl, true);
//				gl.glPopMatrix();
//			}
		}
	}
	
	public void renderOctree(GL gl) {
		octree.render(gl);
	}
}
