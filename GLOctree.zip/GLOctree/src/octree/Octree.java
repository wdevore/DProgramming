package octree;

import geometry.meshes.BoxMesh;
import geometry.meshes.SphereMesh;
import geometry.objects.FrustumObject;
import geometry.objects.Object3D;

import java.util.ArrayList;
import java.util.ListIterator;

import javax.vecmath.Vector3f;

import math.BoundingVolume;
import math.Cone;
import math.Cube;
import math.Frustum;
import math.VectorAlgebra;
import model.Database;
import model.Heap;
import javax.media.opengl.GL;
import views.ICamera;

/*
 * Created on Apr 5, 2005
 *
 */

/**
 * @author wdevore
 *
 */
public class Octree {

	private OctreeNode root = null;
	
	private Database db;
	
	public BoxMesh cubeOutline = null;

	private BoundingVolume bv = new BoundingVolume();
	private SphereMesh boundingSphere = new SphereMesh();

	/*
	 * This array contains objects as a result of culling against
	 * a frustum. 
	 */
	private ArrayList<ArrayList<Object3D>> objects = new ArrayList<ArrayList<Object3D>>();
	
	public void init(Database db) {
		this.db = db;
		
		createUnitCubeIcon();
		
		/*
		 * The root node needs to be given the bounding box that encapsulates
		 * everything the octree will be responsible for.
		 */
		System.out.println("Octree::init Creating octree");
		root = new OctreeNode(this);
		
		/*
		 * Calc the root bounding box by inspecting all the object's bonding
		 * boxes. This inflates the Octree.
		 */
		Cube wb = inflate(100.0f);
		
		System.out.println("Octree::init Initializing octree");
		root.init(wb, 1, "root");

		wb = null;
		
		// Build tree
		System.out.println("Octree::init Building octree");
		buildTree(root);
		
	}
	
	public void render(GL gl) {
//		boundingSphere.render(bv.getSphere(), gl);
		root.render(gl);
	}

	public Vector3f getCenter() {
		Heap.v2.set(root.bBox.center);
		return Heap.v2;
	}
	
	public Vector3f getMaxExtent() {
		float s = root.bBox.getLongestSide();
		Heap.v1.set(s, s, s);
		return Heap.v1;
	}
	
	/*
	 * Inflate the volume of the octree based on the database of objects.
	 * This volume will be tight fitting and centered in the geometric center
	 * of the objects
	 */
	@SuppressWarnings("unused")
	private Cube inflate() {
		/*
		 * Calc the root bounding box by inspecting all the object's bonding
		 * boxes.
		 */
		Cube b = new Cube();	// object's bbox
		Cube wb = new Cube(); // root's bbox
		
		System.out.println("Octree::init Calculating max extents");
		ListIterator<Object3D> o_it = db.getObjects().listIterator(0);
		while (o_it.hasNext()) {
			Object3D o = (Object3D)o_it.next();
			/*
			 * We transform the bounding box's vertices from local-space to
			 * world-space to calculate the root's bounding box.
			 */
			b.set(o.getWorldBox(null));
			calcBoundingBox(wb, b);
		}
		b = null;
		
		/*
		 * The root's Bounding box has an additional contraint in that it must
		 * be a cube centered around the distribution of objects.
		 * This means we must find the longest side and use it as the length
		 * of all sides.
		 */
		
		// First find the length of each side.
		wb.calcHalfSize();
		wb.calcSize();
		
		/*
		 * Then determine which side is longer and make the other two sides that
		 * same length.
		 */
		if (wb.halfSize.x > wb.halfSize.y && wb.halfSize.x > wb.halfSize.z) {
			wb.halfSize.y = wb.halfSize.z = wb.halfSize.x;
			wb.size.y = wb.size.z = wb.size.x;
		} else if (wb.halfSize.y > wb.halfSize.x && wb.halfSize.y > wb.halfSize.z) {
			wb.halfSize.x = wb.halfSize.z = wb.halfSize.y;
			wb.size.x = wb.size.z = wb.size.y;
		} else if (wb.halfSize.z > wb.halfSize.y && wb.halfSize.z > wb.halfSize.x) {
			wb.halfSize.y = wb.halfSize.x = wb.halfSize.z;
			wb.size.y = wb.size.x = wb.size.z;
		}
		
		// Now center the box based on the maximum extents.
		wb.setCenter(wb.min, wb.max);
		
		bv.bBox.set(wb);
		bv.calcSize();

		// Bounding sphere
		bv.calcCenter();
		bv.setRadius(bv.bBox.getLongestSide());
		boundingSphere.createIcon(10, 0.5f, 0.5f, 0.5f);
		
		return wb;
	}

	/*
	 * Artifically inflate Octree centered on the world origin.
	 */
	private Cube inflate(float radius) {
		Cube wb = new Cube(); // root's bbox
		
		wb.min.set(-radius, -radius, -radius);
		wb.max.set(radius, radius, radius);
		
		inflate(wb);
		
		return wb;
	}

	/*
	 * Inflate Octree using a cube.
	 */
	private void inflate(Cube c) {
		/*
		 * The root's Bounding box has an additional contraint in that it must
		 * be a cube centered around the distribution of objects.
		 * This means we must find the longest side and use it as the length
		 * of all sides.
		 */
		
		// First find the length of each side.
		c.calcHalfSize();
		c.calcSize();
		
		// Now center the box based on the maximum extents.
		c.setCenter(c.min, c.max);
		
		bv.bBox.set(c);
		bv.calcSize();

		// Bounding sphere
		bv.calcCenter();
		bv.setRadius(bv.bBox.getLongestSide());
		boundingSphere.createIcon(10, 0.5f, 0.5f, 0.5f);
	}
	
	/**
	 * This method returns a collection of collections where each sub
	 * collection is from a node in the tree.
	 * @param fo A frustum to cull against.
	 * @return
	 * a collection of collections. Each collection is a branch in the tree.
	 */
	public ArrayList<ArrayList<Object3D>> getObjects(FrustumObject fo, ICamera camera) {
		objects.clear();	// reset the collection
		
		/*
		 * check frustum against root BV. I check frustum BV cone against
		 * octree first to reduce false-positive retults. Note: this would not
		 * happen as long as the frustum stayed inside the octree or intersected
		 * it.
		 */
		int iStatus;
		Cone cone = fo.getWorldCone(camera.getInverseTransformMatrix());
		iStatus = VectorAlgebra.sphereIntersectCone(bv.bSphere, cone);
		if (iStatus != VectorAlgebra.OUTSIDE) {
			iStatus = fo.boxIntersectFrustum(root.bBox);
			if (iStatus != Frustum.OUTSIDE) {
				/*
				 * This may be a false-positive when the frustum is completely
				 * outside of the octree.
				 */
				root.getObjects(fo, objects);
				return objects;
			}
		}
		return null;
	}

	private void buildTree(OctreeNode n) {
		/*
		 * Each object is evaluated to see which child it belongs to.
		 * The first test is a spatial test to see if it can fit spatially into a
		 * child cube. If it can't then there is no reason to check any of the
		 * other children. If it does fit then we determine which child it
		 * belongs too by asking each child if it fits. If it does the child takes
		 * care of it otherwise it stays at the parent.
		 * 
		 * We already know that it fits in the root node because the root,
		 * by definition, encompasses all the objects.
		 */
		ListIterator<Object3D> o_it = db.getObjects().listIterator(0);
		while (o_it.hasNext()) {
			Object3D o = o_it.next();
			/*
			 * We don't care about the buildNode status because the object
			 * will always fit in the root node.
			 */
			System.out.println("Octree::buildTree Adding " + o.name);
			root.buildNode(o);
		}
	}
	
	/**
	 * Update the octree's bounding box based on this object's bounding box
	 * @param b is the destination volume
	 * @param ob is the source volume
	 */
	private void calcBoundingBox(Cube b, Cube ob) {
		for (int i = 0; i < 8; i++) {
			Vector3f v = ob.getCornerVertex(i);
			// X
			if (v.x < b.min.x) {
				b.min.x = v.x;
			} else if (v.x > b.max.x) {
				b.max.x = v.x;
			}
			
			// Y
			if (v.y < b.min.y) {
				b.min.y = v.y;
			} else if (v.y > b.max.y) {
				b.max.y = v.y;
			}
			
			// Z
			if (v.z < b.min.z) {
				b.min.z = v.z;
			} else if (v.z > b.max.z) {
				b.max.z = v.z;
			}
		}
	}

	private void createUnitCubeIcon() {
		Cube cube = new Cube();
		cube.min.set(-0.5f, -0.5f, -0.5f);
		cube.max.set(0.5f, 0.5f, 0.5f);
		
		cube.calcSize();
		cube.calcHalfSize();
		
		cubeOutline = new BoxMesh();
		cubeOutline.createIcon(cube, 0.0f, 0.0f, 0.0f);
	}

}
