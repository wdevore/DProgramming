/*
 * Created on Apr 5, 2005
 *
 */
package octree;

//import geometry.meshes.BoxMesh;
import geometry.objects.FrustumObject;
import geometry.objects.Object3D;

import java.util.ArrayList;
import java.util.ListIterator;

import math.Box;
import math.Cube;
import math.Frustum;
import javax.media.opengl.GL;

/**
 * @author wdevore
 * 
 * Each node has 8 children. Only the root node has no parent.
 */
public class OctreeNode {
	public static final int FIT = 0;
	public static final int NOTFIT = 1;
	public static final int DEGENERATE = 2;

	/*
	 * The parent Octree containing this node.
	 */
	Octree octree;
	
	// TODO debug
	//private Object3D wobj;
	private String name = "";
	
	/*
	 * Level in tree. used as the degenerative case.
	 */
	private int level;
	
	/*
	 * Bounding cube/box for this node.
	 */
	public Cube bBox = null;
	
	/*
	 * Object collection. The objects this node encloses.
	 */
	private ArrayList<Object3D> objects = new ArrayList<Object3D>();

	/*
	 * The children of this node.
	 */
	private ArrayList<OctreeNode> children = null;
	
	public OctreeNode(Octree ot) {
		octree = ot;
	}
	
	/**
	 * @param b The parent BV.
	 * @param l level of this node.
	 */
	public void init(Cube b, int l, String name) {
		level = l;
		this.name = name;

		/*
		 * Capture parent BV.
		 */
		bBox = new Cube();
		bBox.set(b);
		
	}
	
	public void render(GL gl) {
		if (children != null) {
			ListIterator<OctreeNode> n_it = children.listIterator(0);
			while (n_it.hasNext()) {
				OctreeNode n = n_it.next();
				
				/*
				 * Render octree cube
				 */
				gl.glPushMatrix();
				//BoxMesh bm = octree.cubeOutline;
				float c = getColorScale(level);
				octree.cubeOutline.setColor(c, c/2.0f, 0.0f);
				gl.glTranslatef(n.bBox.center.x, n.bBox.center.y, n.bBox.center.z);
				float s = n.bBox.getLongestSide();
				gl.glScalef(s, s, s);
				octree.cubeOutline.render(gl);
				gl.glPopMatrix();

				/*
				 * Recurse to next level
				 */
				n.render(gl);
			}
		}
	}

	
	/**
	 * This method is first called from the Octree class to get the recursion
	 * started. It takes an object that is to be inserted into this node.
	 * If it doesn't fit then the parent is notified.
	 * 
	 * The first check is to see if the object can fit in a child. If it can
	 * then the object is immediately sent to that child's buildNode() otherwise
	 * the next child is checked.
	 * 
	 * @param obj object to be inserted.
	 * @return 0 = object fit, 1 = object NOT fit, 2 = Degenerate case reached.
	 */
	public int buildNode(Object3D obj) {
		//wobj = obj;
		int fitStatus = Box.OUTSIDE;
		
		if (level > 7) {
			/*
			 * we have reached the degenerative case (the max depth).
			 * This object will remain with this level.
			 */
			return DEGENERATE;
		}

		OctreeNode n = null;
		Cube cube = null;
		
		/*
		 * First determine if obj fits spatially in a child node. All
		 * the children have the same spatial dimension so if it doesn't
		 * fit in one then it doesn't fit any of the others.
		 * 
		 * The spatial BV for the children is 1/8 the volume of the parent or
		 * 1/2 the width,length and height.
		 */
		int fitSpacially = NOTFIT;
		if (fitsSpatially(obj)) {
			cube = new Cube();
			if (children == null) {
				children = new ArrayList<OctreeNode>();
				System.out.println("OctreeNode::buildNode level " + level);
				for (int i = 0; i < 8; i++) {
						n = new OctreeNode(octree);
						calcChildBox(i, bBox, cube);
						n.init(cube, level + 1, name + "->Child" + i);
						children.add(n);
				}
			}
			
			/*
			 * The object fits spatially; which child box though.
			 * To determine which child it belongs to we perform a box/box
			 * intersection test.
			 */
			cube.set(obj.getWorldBox(null));
			cube.min.add(cube.center, cube.min);
			cube.max.add(cube.center, cube.max);
			
			for (int i = 0; i < 8; i++) {
				ListIterator<OctreeNode> n_it = children.listIterator(i);
				n = n_it.next();
				/*
				 * Determine if Object fits in this child's BV.
				 */
				int intersects = n.bBox.intersects(cube);
				if (intersects == Box.INSIDE) {
					fitStatus = Box.INSIDE;
					/*
					 * The object fits inside the child node. We are done at this
					 * level. Recurse to the next level.
					 */
					fitSpacially = n.buildNode(obj);
					break;
				} else if (intersects == Box.OUTSIDE || intersects == Box.BORDERS) {
					/*
					 * The Object didn't fit child node. Continue to check
					 * other child node BVs. If this condition is true for all
					 * eight sub-spaces then the object is bordering
					 * at least one of the cubes which means the object
					 * will remain with the parent.
					 * 
					 * When all objects have been inserted and this
					 * level has no objects, then the children are
					 * removed.
					 */
				}
			}
			
			cube = null;
		}

		/*
		 * Now determine if we add this obj to this level.
		 * We add it if we have reached the degenerative case or the object
		 * wouldn't fit any child.
		 */
		if (fitSpacially == DEGENERATE || fitStatus != Box.INSIDE) {
			/*
			 * The object didn't fit in a child. Store it at this level.
			 */
			objects.add(obj);
			/*
			 * And indicate to the parent that it was inserted at this level.
			 */
			return FIT;
		}
		
		return fitSpacially;
	}
	
	private boolean fitsSpatially(Object3D obj) {
		Box objBox = obj.getBoundingVolume().getBox();
		/*
		 * This level's longest side. Hence, the child's is 1/2 that.
		 */
		float maxBoxLength = bBox.getLongestSide()/2.0f;

		float childLength = objBox.halfSize.x;
		if (childLength < maxBoxLength) {
			// The object fits in the child's width
			childLength = objBox.halfSize.y;
			if (childLength < maxBoxLength) {
				// The object fits in the child's height
				childLength = objBox.halfSize.z;
				if (childLength < maxBoxLength) {
					/*
					 * The object fits in the child's BV.
					 */
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * The child box is 1/8th the volume of the parent or a side is 1/2 the
	 * length of the parent.
	 * The parent provides a center, length, max and min. The parent's center is
	 * one corner of 4 out of the 8 child boxes.
	 * The outer child corners are defined relative to the parent as:
	 * center - length/2.
	 * 
	 * @param octant which of the 8 octants
	 * @param p parent BV
	 * @param c [OUTPUT] child BV
	 */
	private void calcChildBox(int octant, Cube p, Cube c) {
		switch (octant) {
		case 0:
			c.min.set(p.center.x - p.halfSize.x, p.center.y - p.halfSize.y, p.center.z - p.halfSize.z);
			c.max.set(p.center.x, p.center.y, p.center.z);
			break;
		case 1:
			c.min.set(p.center.x, p.center.y - p.halfSize.y, p.center.z - p.halfSize.z);
			c.max.set(p.center.x + p.halfSize.x, p.center.y, p.center.z);
			break;
		case 2:
			c.min.set(p.center.x, p.center.y, p.center.z - p.halfSize.z);
			c.max.set(p.center.x + p.halfSize.x, p.center.y + p.halfSize.y, p.center.z);
			break;
		case 3:
			c.min.set(p.center.x - p.halfSize.x, p.center.y, p.center.z - p.halfSize.z);
			c.max.set(p.center.x, p.center.y + p.halfSize.y, p.center.z);
			break;
		case 4:
			c.min.set(p.center.x - p.halfSize.x, p.center.y - p.halfSize.y, p.center.z);
			c.max.set(p.center.x, p.center.y, p.center.z + p.halfSize.z);
			break;
		case 5:
			c.min.set(p.center.x, p.center.y - p.halfSize.y, p.center.z);
			c.max.set(p.center.x + p.halfSize.x, p.center.y, p.center.z + p.halfSize.z);
			break;
		case 6:
			c.min.set(p.center.x, p.center.y, p.center.z);
			c.max.set(p.center.x + p.halfSize.x, p.center.y + p.halfSize.y, p.center.z + p.halfSize.z);
			break;
		case 7:
			c.min.set(p.center.x - p.halfSize.x, p.center.y, p.center.z);
			c.max.set(p.center.x, p.center.y + p.halfSize.y, p.center.z + p.halfSize.z);
			break;
		}
		c.calcHalfSize();
		c.calcSize();
		c.setCenter();
	}

	/**
	 * Apply the Frustum against this node's bbox. If they intersect then we
	 * have a potential visibility and we need to recurse to find out exactly
	 * which child nodes intersect. 
	 * 
	 * If they don't intersect then we stop because the box isn't visible and
	 * hence none of the children are either. This, in essence, is the main
	 * concept of the Octree.
	 * 
	 * @param fo A frustum to cull the node against.
	 * @return
	 * a collection of objects.
	 */
	public void getObjects(FrustumObject fo, ArrayList<ArrayList<Object3D>> collection) {
		/*
		 * This node has been determined by the parent node to be visible.
		 * We collect any objects it has.
		 */
		if (!objects.isEmpty()) {
			collection.add(objects);
		}
		
		/*
		 * The degenerative case is indicated by a node having no children
		 * (the max depth for this branch). 
		 */
		if (children == null) {
			/*
			 * This node has no children to recurse down into. We just leave.
			 */
			return;
		} else if (children.isEmpty()) {
			return;
		}
		
		/*
		 * Apply Frustum against each child.
		 */
		OctreeNode n = null;
		ListIterator<OctreeNode> n_it;
		int iStatus;
		
		for (int i = 0; i < 8; i++) {
			n_it = children.listIterator(i);
			n = n_it.next();
			iStatus = fo.boxIntersectFrustum(n.bBox);
			if (iStatus == Frustum.OUTSIDE) {
				/*
				 * The frustum and cube are not intersecting. We move on to the
				 * next child.
				 */
			} else {
				/*
				 * The frustum intersected this child's cube. We need to
				 * recurse down into the child
				 * to see if any of the children intersect with the frustum
				 * as well.
				 * 
				 * Just because the parent BV intersected doesn't mean all the
				 * children BVs intersect. Some BVs could be on the other side
				 * of the parent BV and not intersect with the frustum.
				 */
				n.getObjects(fo, collection);
			}
		}
		
	}

	private float getColorScale(int level) {
		float c = 1.0f;
		switch (level) {
		case 1:	c = 1.0f; break;
		case 2:	c = 0.8f; break;
		case 3:	c = 0.6f; break;
		case 4:	c = 0.4f; break;
		case 5:	c = 0.2f; break;
		case 6:	c = 0.1f; break;
		case 7:	c = 1.0f; break;
		}
		return c;
	}

}
