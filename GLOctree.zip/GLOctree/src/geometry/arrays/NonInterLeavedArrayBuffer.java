/*
 * Created on Jan 11, 2005
 *
 */
package geometry.arrays;

import java.nio.FloatBuffer;
import java.util.ArrayList;

/**
 * @author wdevore
 *
 */
public abstract class NonInterLeavedArrayBuffer extends ArrayBuffer {

	/*
	 * color buffer NIO
	 */
	protected FloatBuffer colorBuffer;
	protected ArrayList<float[]> colorArray = null;

	/*
	 * normal buffer NIO
	 */
	protected FloatBuffer normalBuffer;
	protected ArrayList<float[]> normalArray = null;

	public void addColor(float r, float g, float b) {
		if (colorArray == null) {
			colorArray = new ArrayList<float[]>();
		}
		float a[] = new float[3];
		a[0] = r;
		a[1] = g;
		a[2] = b;
		colorArray.add(a);
	}

	public void addNormal(float x, float y, float z) {
		if (normalArray == null) {
			normalArray = new ArrayList<float[]>();
		}
		float a[] = new float[3];
		a[0] = x;
		a[1] = y;
		a[2] = z;
		normalArray.add(a);
	}

	public FloatBuffer getColorBuffer() {
		return colorBuffer;
	}
	public FloatBuffer getNormalBuffer() {
		return normalBuffer;
	}

	public ArrayList<float[]> getNormalArray() {
		return normalArray;
	}
	
	public int getNormalCount() {
		return normalArray.size();
	}

	public float[] getNormal(int i) {
		return (float[])normalArray.get(i);
	}

	public boolean hasColorArray() {
		return (getColorBuffer() != null);
	}
	
}
