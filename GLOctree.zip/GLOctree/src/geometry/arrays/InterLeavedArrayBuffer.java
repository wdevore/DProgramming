/*
 * Created on Jan 11, 2005
 *
 */
package geometry.arrays;

import java.nio.FloatBuffer;

/**
 * @author wdevore
 *
 */
public abstract class InterLeavedArrayBuffer extends NonInterLeavedArrayBuffer {
	
	/*
	 * Interleaved buffer NIO
	 */
	protected FloatBuffer interLeavedBuffer;
	
	/*
	 * These methods are abstract because different objects will have
	 * different formats and strides.
	 */
	public abstract int getFormat();
	public abstract int getStride();
	
	public FloatBuffer getInterLeaveBuffer() {
		return interLeavedBuffer;
	}
}
