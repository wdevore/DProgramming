/*
 * Created on Jan 26, 2005
 *
 */
package geometry.arrays;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

import com.sun.opengl.util.BufferUtil;


/**
 * @author wdevore
 *
 */
public class LineArray extends InterLeavedArrayBuffer {

	public void render(GL gl) {
		gl.glDisable(GL.GL_LIGHTING);
		gl.glInterleavedArrays(getFormat(), getStride(), interLeavedBuffer);
		gl.glDrawElements(GL.GL_LINES, elementCount, GL.GL_UNSIGNED_INT, indexBuffer);
		gl.glEnable(GL.GL_LIGHTING);
	}

	public void addLine(Vector3f p, Vector3f q) {
		addVertex(p.x, p.y, p.z);
		addIndex();
		addVertex(q.x, q.y, q.z);
		addIndex();
	}
	
	public int getFormat() {
		/*
		 * Each float is 4 bytes in Java(32 bit JVM).
		 * 
		 * The packing format is:
		 * v.x  --- 4 bytes  ----
		 * v.y    | 4           | 12 byte stride to next vertex
		 * v.z  --- 4        ----
		 * 
		 * etc... 3 times for each triangle.
		 */
		return GL.GL_V3F;
	}
	
	public int getStride() {
		/*
		 * The stride is computed based on the data type and the combination
		 * being interleaved.
		 * For example, if the format is GL_C3F_V3F and a float is 4 bytes, in
		 * java then the stride is:
		 * 4 floats * (3 color components + 3 vertex components)
		 * = 4 * (3+3) = 4*6 = 24
		 * 
		 * For this array the stride is 4 floats * 3 vertex components = 12
		 * which is the stride for GL_V3F
		 */
		return 12;
	}

	/* (non-Javadoc)
	 * @see geometry.arrays.ArrayBuffer#addIndex()
	 */
	public void addIndex() {
		int[] index = new int[1];
		index[0] = elementCount;
		indexArray.add(index);
		elementCount++;
	}

	public void reset() {
		interLeavedBuffer.clear();
		vertexArray.clear();
	}
	
	public void pack() {
		/*
		 * A line is an element.
		 * 	2 vertex components * (3 floats per vertex) = 6
		 */
		final int componentsPerElement = 6; 

		/*
		 * For interleaveing we need to expand by the number of items
		 * being interleaved. For example, if colors and vertices are
		 * being interleaved then we have 2 items being interleaved.
		 */
		int numberOfInterleaves = 1;	// we always have vertices
		
		/*
		 * newFloatBuffer takes a count of the number of elements
		 * to buffer; LINES in this case.
		 * 
		 * For example, a single LINE is made up of 2 vertices and
		 * each vertex is made up of 3 float components = 6 floats
		 * per LINE.
		 * 
		 * Thus one LINE requires: (2 vertices) * (3 floats) = 6 floats.
		 * 
		 * And for n-number of LINES it would be n * (6).
		 * The total buffer size is then:
		 * 6*n
		 * 
		 * The specifications indicate that there needs to an equal amount
		 * of colors as there are vertices. Hence, I use vertex array size
		 * as the degenerate case.
		 */
		interLeavedBuffer = BufferUtil.newFloatBuffer(numberOfInterleaves * componentsPerElement * vertexArray.size());
		float f[];
		// Begin interleaving the elements.
		for (int i = 0; i < vertexArray.size(); i++) {
			f = (float[])vertexArray.get(i);
			interLeavedBuffer.put(f);
		}
		interLeavedBuffer.rewind();
		/*
		 * Release the contents of the array. We don't need it anymore
		 * because the data is in the NIO Buffer now.
		 */
//		vertexArray.clear();
//		vertexArray = null;

		super.pack();
		
	}


}
