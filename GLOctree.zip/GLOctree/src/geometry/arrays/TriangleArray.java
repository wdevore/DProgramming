/*
 * Created on Jan 26, 2005
 *
 */
package geometry.arrays;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

import com.sun.opengl.util.BufferUtil;


/**
 * @author wdevore
 *
 */
public class TriangleArray extends InterLeavedArrayBuffer {

	public void render(GL gl) {
		gl.glInterleavedArrays(getFormat(), getStride(), interLeavedBuffer);
		gl.glDrawElements(GL.GL_TRIANGLES, elementCount, GL.GL_UNSIGNED_INT, indexBuffer);
	}

	public void addTriangle(Vector3f n0, Vector3f n1, Vector3f n2, Vector3f v0, Vector3f v1, Vector3f v2) {
		addNormal(n0.x, n0.y, n0.z);
		addVertex(v0.x, v0.y, v0.z);
		addIndex();
		addNormal(n1.x, n1.y, n1.z);
		addVertex(v1.x, v1.y, v1.z);
		addIndex();
		addNormal(n2.x, n2.y, n2.z);
		addVertex(v2.x, v2.y, v2.z);
		addIndex();
	}

	public void addTriangle(Vector3f n, Vector3f v0, Vector3f v1, Vector3f v2) {
		addNormal(n.x, n.y, n.z);
		addVertex(v0.x, v0.y, v0.z);
		addIndex();
		addNormal(n.x, n.y, n.z);
		addVertex(v1.x, v1.y, v1.z);
		addIndex();
		addNormal(n.x, n.y, n.z);
		addVertex(v2.x, v2.y, v2.z);
		addIndex();
	}

	public int getFormat() {
		/*
		 * Each float is 4 bytes in Java(32 bit JVM).
		 * 
		 * The packing format is:
		 * n.x  --- 4 bytes  ----
		 * n.y    | 4           |
		 * n.z  --| 4           |
		 * v.x  --| 4           | Vertex 1
		 * v.y    | 4           | 24 byte stride to next vertex
		 * v.z  --- 4        ----
		 * 
		 * etc... 3 times for each triangle.
		 */
		return GL.GL_N3F_V3F;
	}
	
	public int getStride() {
		/*
		 * The stride is computed based on the data type and the combination
		 * being interleaved.
		 * For example, if the format is GL_N3F_V3F and a float is 4 bytes, in
		 * java then the stride is:
		 * 4 floats * (3 normal components + 3 vertex components)
		 * = 4 * (3+3) = 4*6 = 24
		 */
		return 24;
	}

	/* (non-Javadoc)
	 * @see geometry.arrays.ArrayBuffer#addIndex()
	 */
	public void addIndex() {
		int[] index = new int[1];
		index[0] = elementCount;
		indexArray.add(index);
		elementCount++;
	}

	public void addIndex(int i) {
		int[] index = new int[1];
		index[0] = i;
		indexArray.add(index);
		elementCount++;
	}
	
	public void reset() {
		interLeavedBuffer.clear();
		vertexArray.clear();
		colorArray.clear();
	}

	public void pack() {
		/*
		 * An element is a triangle.
		 * 3 vertex components + 3 normal components
		 */
		final int componentsPerElement = 6; 

		/*
		 * newFloatBuffer takes a count of the number of elements
		 * to buffer; TRIANGLES in this case.
		 * 
		 * For example, a single TRIANGLE is made up of 3 vertices and
		 * each vertex is made up of 3 float components = (3+3+3)=9 floats
		 * per TRIANGLE.
		 * 
		 * In addition, 1 normal element is required for each vertex
		 * which means (3+3+3)=9 additional floats.
		 * 
		 * Thus one TRIANGLE requires:
		 * (3 vertices per triangle + 3 normals per triangle) * 3 floats per vertex
		 * 6 * 3 = 18 floats.
		 * 
		 * And for n-number of TRIANGLES it would be n * (18).
		 * The total buffer size is then:
		 * n*18
		 * 
		 * The specifications indicate that there needs to an equal amount
		 * of normals as there are vertices. Hence, I use vertex array size
		 * as the degenerate case.
		 */
		interLeavedBuffer = BufferUtil.newFloatBuffer(componentsPerElement * vertexArray.size());
		float f[];
		// Begin interleaving the elements.
		for (int i = 0; i < vertexArray.size(); i++) {
			f = (float[])normalArray.get(i);
			interLeavedBuffer.put(f);
			f = (float[])vertexArray.get(i);
			interLeavedBuffer.put(f);
		}
		interLeavedBuffer.rewind();
		/*
		 * Release the contents of the array. We don't need it anymore
		 * because the data is in the NIO Buffer now.
		 */
		// TODO debug
//		vertexArray.clear();
//		vertexArray = null;
//		normalArray.clear();
//		normalArray = null;

		super.pack();
		
	}
}
