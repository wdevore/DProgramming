/*
 * Created on Jan 26, 2005
 *
 */
package geometry.arrays;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

import com.sun.opengl.util.BufferUtil;


/**
 * @author wdevore
 *
 */
public class PointArray extends InterLeavedArrayBuffer {

	public void render(GL gl) {
		gl.glDisable(GL.GL_LIGHTING);
		
		gl.glInterleavedArrays(getFormat(), getStride(), interLeavedBuffer);

		gl.glDrawElements(GL.GL_POINTS, elementCount, GL.GL_UNSIGNED_INT, indexBuffer);
		
		gl.glEnable(GL.GL_LIGHTING);

	}

	public void addPoint(Vector3f p, Vector3f c) {
		addColor(c.x, c.y, c.z);
		addVertex(p.x, p.y, p.z);
		addIndex();
	}
	
	public int getFormat() {
		/*
		 * Each float is 4 bytes in Java(32 bit JVM).
		 * 
		 * The packing format is:
		 * n.x  --- 4 bytes  ----
		 * n.y    | 4           |
		 * n.z  --| 4           |
		 * v.x  --| 4           | Vertex 1
		 * v.y    | 4           | 24 byte stride to next vertex
		 * v.z  --- 4        ----
		 * 
		 * etc... 3 times for each triangle.
		 */
		return GL.GL_C3F_V3F;
	}
	
	public int getStride() {
		/*
		 * The stride is computed based on the data type and the combination
		 * being interleaved.
		 * For example, if the format is GL_N3F_V3F and a float is 4 bytes, in
		 * java then the stride is:
		 * 4 floats * (3 normal components + 3 vertex components)
		 * = 4 * (3+3) = 4*6 = 24
		 */
		return 24;
	}

	/* (non-Javadoc)
	 * @see geometry.arrays.ArrayBuffer#addIndex()
	 */
	public void addIndex() {
		int[] index = new int[1];
		index[0] = elementCount;
		indexArray.add(index);
		elementCount++;
	}

	public void reset() {
		interLeavedBuffer.clear();
		vertexArray.clear();
		colorArray.clear();
	}

	public void pack() {
		/*
		 * A line is an element.
		 * 	3 vertex components + 3 color components
		 */
		final int componentsPerElement = 6; 

		/*
		 * For interleaveing we need to expand by the number of items
		 * being interleaved. For example, if colors and vertices are
		 * being interleaved then we have 2 items being interleaved.
		 */
		int numberOfInterleaves = 1;	// we always have vertices
		if (colorArray != null)
			numberOfInterleaves++;
		if (normalArray != null)
			numberOfInterleaves++;
		
		/*
		 * newFloatBuffer takes a count of the number of elements
		 * to buffer; LINES in this case.
		 * 
		 * For example, a single LINE is made up of 2 vertices and
		 * each vertex is made up of 3 float components = 6 floats
		 * per LINE.
		 * 
		 * In addition, 1 color element is required for each vertex
		 * which means (3+3)=6 floats.
		 * 
		 * Thus one LINE requires: (1 vertex + 1 color) * (3 + 3) = 12 floats.
		 * 
		 * And for n-number of LINES it would be n * (12).
		 * The total buffer size is then:
		 * 12*n
		 * 
		 * The specifications indicate that there needs to an equal amount
		 * of colors as there are vertices. Hence, I use vertex array size
		 * as the degenerate case.
		 */
		interLeavedBuffer = BufferUtil.newFloatBuffer(numberOfInterleaves * componentsPerElement * vertexArray.size());
		float f[];
		// Begin interleaving the elements.
		for (int i = 0; i < vertexArray.size(); i++) {
			f = (float[])colorArray.get(i);
			interLeavedBuffer.put(f);
			f = (float[])vertexArray.get(i);
			interLeavedBuffer.put(f);
		}
		interLeavedBuffer.rewind();
		/*
		 * Release the contents of the array. We don't need it anymore
		 * because the data is in the NIO Buffer now.
		 */
		vertexArray.clear();
		vertexArray = null;
		colorArray.clear();
		colorArray = null;

		super.pack();
		
	}
}
