/*
 * Created on Dec 9, 2004
 *
 */
package geometry.arrays;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;

import com.sun.opengl.util.BufferUtil;

/**
 * @author wdevore
 *
 */
public abstract class ArrayBuffer {
	/*
	 * Vertex buffer NIO
	 */
	protected FloatBuffer vertexBuffer;
	protected ArrayList<float[]> vertexArray = new ArrayList<float[]>();
	
	/*
	 * Index buffer NIO
	 */
	protected IntBuffer indexBuffer;
	protected ArrayList<int[]> indexArray = new ArrayList<int[]>();
	
	/*
	 * Counts the number of elements in a buffer.
	 * For example, for every Quad there is 4 vertices/elements so
	 * everytime a face is added 4 elements are added.
	 * Or
	 * For every triangle 3 vertices are needed hence 3 elements are
	 * added.
	 * Or
	 * A point has 1 vertex or one element added.
	 */
	protected int elementCount;
	
	public abstract void addIndex();

	public void reset() {
		vertexArray.clear();
	}

	public void pack() {
		/*
		 * Transfer the indices into the buffer.
		 */
		indexBuffer = BufferUtil.newIntBuffer(indexArray.size());
		int ii[];
		for (int i = 0; i < indexArray.size(); i++) {
			ii = indexArray.get(i);
			indexBuffer.put(ii);
		}
		indexBuffer.rewind();
		// TODO debug
//		indexArray.clear();
//		indexArray = null;
		
		System.gc();
	}
	
	public void addVertex(float x, float y, float z) {
		float a[] = new float[3];
		a[0] = x;
		a[1] = y;
		a[2] = z;
		vertexArray.add(a);
	}
	
	public FloatBuffer getVertexBuffer() {
		return vertexBuffer;
	}
	public IntBuffer getIndexBuffer() {
		return indexBuffer;
	}
	
	public int getElementCount() {
		return elementCount;
	}

	public int getVertexCount() {
		return vertexArray.size();
	}

	public int getIndexCount() {
		return indexArray.size();
	}

	public float[] getVertex(int i) {
		return (float[])vertexArray.get(i);
	}
	
	public int[] getIndex(int i) {
		return (int[])indexArray.get(i);
	}

}
