/*
 * Created on Mar 7, 2005
 *
 */
package geometry.objects;

import geometry.meshes.BoxMesh;
import geometry.meshes.SphereMesh;
import geometry.meshes.TrianglesMesh;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

/**
 * @author wdevore
 * 
 */
public class TrianglesObject extends Object3D {
	/*
	 * The actual mesh
	 */
	private TrianglesMesh triMesh = new TrianglesMesh();

	/*
	 * Bounding volume visual icons.
	 */
	private BoxMesh boundingBox = new BoxMesh();
	private SphereMesh boundingSphere = new SphereMesh();

	private Vector3f v1 = new Vector3f();
	//private Vector3f v2 = new Vector3f();

	public TrianglesObject() {
		super();
	}

	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		gl.glColor3f(color[0], color[1], color[2]);

		gl.glPushMatrix();
		v1.set(getPosition());
		// Translate to world position.
		gl.glTranslatef(v1.x, v1.y, v1.z);

		if (renderMesh)
			triMesh.render(gl);

		boundingBox.setColor(r, g, b);
		boundingBox.render(gl);

		// boundingSphere.render(bv.getSphere(), gl);

		gl.glPopMatrix();
	}

	public void addVertex(Vector3f v) {
		triMesh.addVertex(v);
	}

	public int getVertexCount() {
		return triMesh.getVertexCount();
	}

	public BoxMesh getBVBoxMesh() {
		return boundingBox;
	}

	public int getIndexCount() {
		return triMesh.getIndexCount();
	}

	public void setShadeModel(int sm) {
		triMesh.setShadeModel(sm);
	}

	public void setOutlineMode(boolean m) {
		triMesh.setOutlineMode(m);
	}

	public void addFace(int i1, int i2, int i3) {
		triMesh.addFace(i1, i2, i3);
	}

	public void addTriangle(Vector3f n0, Vector3f n1, Vector3f n2, Vector3f v0,
			Vector3f v1, Vector3f v2) {
		triMesh.addTriangle(n0, n1, n2, v0, v1, v2);
	}

	public void addTriangle(Vector3f v1, Vector3f v2, Vector3f v3) {
		triMesh.addTriangle(v1, v2, v3);
	}

	public void calcNormals() {
		triMesh.calcNormals();
	}

	public void renderNormals(boolean flag) {
		triMesh.renderNormals(flag);
	}

	public void reset() {
		triMesh.reset();
	}

	public void pack() {
		triMesh.pack();
	}

	public void calcBBox() {
		int i[];
		float f[];
		bv.clearMinMax();

		// visit each vertex
		for (int in = 0; in < triMesh.getIndexCount(); in++) {
			i = triMesh.getIndex(in);
			f = triMesh.getVertex(i[0]);
			v1.set(f[0], f[1], f[2]);

			if (v1.x < bv.bBox.min.x) {
				bv.bBox.min.x = v1.x;
			} else if (v1.x > bv.bBox.max.x) {
				bv.bBox.max.x = v1.x;
			}
			if (v1.y < bv.bBox.min.y) {
				bv.bBox.min.y = v1.y;
			} else if (v1.y > bv.bBox.max.y) {
				bv.bBox.max.y = v1.y;
			}
			if (v1.z < bv.bBox.min.z) {
				bv.bBox.min.z = v1.z;
			} else if (v1.z > bv.bBox.max.z) {
				bv.bBox.max.z = v1.z;
			}
		}

		bv.calcSize();

		// Bounding box is always at the center of object
		bv.calcCenter();

		boundingBox.createIcon(bv.getBox(), 0.2f, 0.5f, 1.0f);

		bv.calcRadius();

		boundingSphere.createIcon(10, 0.5f, 0.5f, 0.5f);

	}

}
