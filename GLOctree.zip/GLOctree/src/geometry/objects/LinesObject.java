/*
 * Created on Jan 10, 2005
 *
 */
package geometry.objects;


import geometry.arrays.LineArray;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;


/**
 * @author wdevore
 *
 */
public class LinesObject extends Object3D {

	private LineArray array = new LineArray();
	
	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		array.render(gl);
	}

	public void addLine(Vector3f p, Vector3f q) {
		array.addLine(p, q);
	}

	public void reset() {
		array.reset();
	}

	public void pack() {
		array.pack();
	}
}
