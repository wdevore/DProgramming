/*
 * Created on Jan 10, 2005
 *
 */
package geometry.objects;


import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

import geometry.arrays.MultiColorLineArray;

/**
 * @author wdevore
 *
 */
public class MultiColorLinesObject extends Object3D {

	private MultiColorLineArray array = new MultiColorLineArray();
	
	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		array.render(gl);
	}

	public void addLine(Vector3f p, Vector3f q, Vector3f cp, Vector3f cq) {
		array.addLine(p, q, cp, cq);
	}

	public void reset() {
		array.reset();
	}

	public void pack() {
		array.pack();
	}
}
