/*
 * Created on Mar 16, 2005
 *
 */
package geometry.objects;

import geometry.meshes.ConeMesh;
import geometry.meshes.FrustumMesh;
import geometry.meshes.SphereMesh;

import javax.vecmath.Matrix4f;
//import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import math.Box;
import math.Cone;
import math.Frustum;
import math.Sphere;
import math.VectorAlgebra;
import model.Heap;
import javax.media.opengl.GL;
import views.ICamera;

/**
 * @author wdevore
 *
 */
public class FrustumObject extends Object3D {
	public static final int INSIDE = 0;
	public static final int BORDERING = 1;
	public static final int OUTSIDE = 2;

	/*
	 * Extracted OpenGL matrices.
	 */
	private float projection[] = new float[16];
	private float modelview[] = new float[16];
	//private float combined[] = new float[16];
	
	private Matrix4f projectionMatrix = new Matrix4f();
	private Matrix4f modelviewMatrix = new Matrix4f();
	private Matrix4f combinedMatrix = new Matrix4f();

	/*
	 * Local temp variables
	 */
	private Vector3f v1 = new Vector3f();
	private Vector3f v2 = new Vector3f();
	private Vector3f v3 = new Vector3f();
	//private Point3f p1 = new Point3f();

	private FrustumMesh frustumMesh = new FrustumMesh();

	/*
	 * This frustum is what the application computed and is used for drawing.
	 */
	private Frustum frustum = new Frustum();
	
	/*
	 * This is the frustum extracted from OpenGL and is the results
	 * of all the viewing transformations applied in the pipeline.
	 */
	private Frustum openGLFrustum = new Frustum();

	/*
	 * Distance computed from frustum check.
	 */
	//private double distance = 0.0;

	/*
	 * BV icons of frustum.
	 */
	private SphereMesh boundingSphereIcon = new SphereMesh();
	private ConeMesh boundingConeIcon = new ConeMesh();
	
	/*
	 * Bounding cone of object.
	 */
	public Cone bCone = new Cone();

	/*
	 * Camera/View associated with this frustum.
	 */
	ICamera camera;
	
	public FrustumObject(ICamera c, String s) {
		super();
		name = s;
		camera = c;
	}
	
	public void init() {
		calcBoundingVolumes();
		frustumMesh.buildMesh(frustum);
	}
	
	/*
	 * The clipping planes should be disabled prior to calling this method.
	 * Why? Because the icon is defined on the surface of the frustum and will
	 * be culled out and at best will flicker from floating point error.
	 */
	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		placeClippingPlanes(gl);
		
		/*
		 * This is what we will actually see.
		 */
		// I just want the color of the plane not any shading.
		gl.glDisable(GL.GL_LIGHTING);
		
		// Render frustum
		gl.glColor4f(0.8f, 0.8f, 0.8f, 0.5f);
		frustumMesh.render(gl);
		
//		boundingSphereIcon.render(bv.bSphere, gl);
//		boundingConeIcon.render(bCone, gl);
		
		gl.glEnable(GL.GL_LIGHTING);
		
	}
	
	public void placeClippingPlanes(GL gl) {
		/*
		 * The clipping planes are objects as well. Hence, they must be placed
		 * on each frame just as any other objects.
		 * These clipping planes are not visible. To visually see them we
		 * must render a real mesh. Otherwise all we would
		 * see would be the end-result of things being clipped.
		 */
		gl.glClipPlane(GL.GL_CLIP_PLANE0, frustum.getPlaneEquation(Frustum.NEARPLANE), 0);
		gl.glClipPlane(GL.GL_CLIP_PLANE1, frustum.getPlaneEquation(Frustum.FARPLANE), 0);
		gl.glClipPlane(GL.GL_CLIP_PLANE2, frustum.getPlaneEquation(Frustum.LEFTPLANE), 0);
		gl.glClipPlane(GL.GL_CLIP_PLANE3, frustum.getPlaneEquation(Frustum.RIGHTPLANE), 0);
		gl.glClipPlane(GL.GL_CLIP_PLANE4, frustum.getPlaneEquation(Frustum.BOTTOMPLANE), 0);
		gl.glClipPlane(GL.GL_CLIP_PLANE5, frustum.getPlaneEquation(Frustum.TOPPLANE), 0);
	}
	
	/*
	 * This version is redesigned to integrate with my classes better.
	 */
	public void extractFrustum(GL gl) {
	   //float t;

	   // Get the current PROJECTION matrix from OpenGL
	   gl.glGetFloatv(GL.GL_PROJECTION_MATRIX, projection, 0);
	   VectorAlgebra.arrayToMatrix(projection, projectionMatrix);
	   
	   // Get the current MODELVIEW matrix from OpenGL
	   gl.glGetFloatv(GL.GL_MODELVIEW_MATRIX, modelview, 0);
	   VectorAlgebra.arrayToMatrix(modelview, modelviewMatrix);
//	   System.out.println("FrustumObject::extractFrustum ");
//	   System.out.println(modelviewMatrix);
	   combinedMatrix.mul(projectionMatrix, modelviewMatrix);

	   openGLFrustum.setPlaneEquations(combinedMatrix);
	   
	}

	public int pointInFrustum(Vector3f p) {
		return openGLFrustum.pointInFrustum(p);
	}

	public int sphereIntersectFrustum(Sphere s) {
		return openGLFrustum.sphereInFrustum(s);
	}
	
	public int boxIntersectFrustum(Box c) {
		return openGLFrustum.boxIntersectFrustum(c);
	}
	public Frustum getFrustum() {
		return frustum;
	}
	
	
	/*
	 * We pass in a Matrix transforms the volume from object-space to world-space.
	 */
	public Sphere getWorldSphere(Matrix4f m) {
		Heap.bSphereTransformed.set(bv.bSphere);
		if (m == null) {
			return Heap.bSphereTransformed;
		} else {
			/*
			 * Transform the sphere's center based on matrix.
			 * Note: A point3f is used because we want to perform an Affine point
			 * transformation and not a normal/vector transformation. Using a Vector3f
			 * would cause the translation portion of the matrix to be lost.
			 */
			m.transform(Heap.bSphereTransformed.center);
			return Heap.bSphereTransformed;
		}
	}
	
	/*
	 * We pass in a Matrix transforms the volume from object-space to world-space.
	 */
	public Cone getWorldCone(Matrix4f m) {
		Heap.bConeTransformed.set(bCone);
		if (m == null) {
			return Heap.bConeTransformed;
		} else {
			/*
			 * Transform the sphere's center based on matrix.
			 * Note: A point3f is used because we want to perform an Affine point
			 * transformation and not a normal/vector transformation. Using a Vector3f
			 * would cause the translation portion of the matrix to be lost.
			 */
			m.transform(Heap.bConeTransformed.vertex);
			m.transform(Heap.bConeTransformed.axis);
			return Heap.bConeTransformed;
		}
	}

	public void calcBoundingVolumes() {
		/*
		 * Create bounding sphere icon.
		 */
		calcBoundingSphere();
		calcBoundingCone();
		
		boundingSphereIcon.createIcon(10, 0.0f, 1.0f, 0.0f);
		boundingConeIcon.createIcon(bCone, 10, 0.0f, 0.4f, 0.5f);
		
	}

	public void calcBoundingSphere() {
		/*
		 * We begin by calculating the radius.
		 */
		float depth = frustum.far - frustum.near;
		
		// Find the height using the far plane.
		//float width = Math.abs(frustum.right_far - frustum.left_far)*0.5f;
		//float height = Math.abs(frustum.top_far - frustum.bottom_far)*0.5f;
		
		// Mid point of near->far axis
		v1.set(0.0f, 0.0f, frustum.near + depth/2.0f);
		
		// The far corner of frustum
		v2.set(frustum.right_far, frustum.top_far, Math.abs(depth)/2.0f);
		
		// Calc radius from vector of mid-point and corner
		v3.sub(v2, v1);
		
		Sphere s  = bv.getSphere();
		/*
		 * We may want to make the radius an Epsilon bigger to compensate for
		 * floating point error creep.
		 */
		s.setRadius(v3.length());
		
		v1.negate();
		s.center.set(v1);
		
	}
	
	public void calcBoundingCone() {
		
		/*
		 * Be default the cone is placed in the OpenGL default direction:
		 * 0,0,-1.
		 */
		bCone.setAxis(0.0f, 0.0f, -1.0f);
		/*
		 * And place at the world origin.
		 */
		bCone.setVertex(0.0f, 0.0f, 0.0f);
		
		/*
		 * Form a vector that eminates from the origin and points to a corner
		 * of the far end of the frustum.
		 */
		v1.set(frustum.right_far, frustum.top_far, -frustum.far);
		v1.normalize();
		bCone.setAngle(v1);
		
		/*
		 * The base of the cone (the wide end) is place at the wider part of
		 * the frustum.
		 */
		v1.set(0.0f, 0.0f, -frustum.far);
		bCone.setBase(v1);
		
		/*
		 * The radius is formed by creating a vector from the base of the
		 * frustum to a corner of the frustum defined above. 
		 */
		v2.set(frustum.right_far, frustum.top_far, -frustum.far);
		v2.sub(v1);
		float r = v2.length();
		bCone.setBaseRadius(r);
	}
	

}
