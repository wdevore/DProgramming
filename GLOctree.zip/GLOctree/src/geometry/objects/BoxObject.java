/*
 * Created on Mar 7, 2005
 *
 */
package geometry.objects;

import geometry.meshes.BoxMesh;
import geometry.meshes.SphereMesh;

import javax.vecmath.Vector3f;

import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class BoxObject extends Object3D {
	private Vector3f v1 = new Vector3f();

	private BoxMesh boundingBox = new BoxMesh();
	private SphereMesh boundingSphere = new SphereMesh();

	public BoxObject(String s) {
		super();
		setName(s);
	}

	public void setSize(float w, float h, float d) {
		bv.setSize(w, h, d);
		v1.set(bv.bBox.halfSize);
		bv.setMax(v1);
		v1.negate();
		bv.setMin(v1);
		
	}
	
	public void setCenter(Vector3f v) {
		bv.bBox.center.set(v);
	}
	public void setCenter(float x, float y, float z) {
		v1.set(x, y, z);
		bv.bBox.center.set(v1);
	}
	
	public void setPosition(float x, float y, float z) {
		super.setPosition(x, y, z);
		setCenter(x, y, z);
	}
	
	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		gl.glColor3f(color[0], color[1], color[2]);
		gl.glPushMatrix();
		v1.set(getPosition());
		gl.glTranslatef(v1.x, v1.y, v1.z);
		if (renderMesh)
			boundingBox.render(gl);
		boundingSphere.render(bv.getSphere(), gl);
		gl.glPopMatrix();
	}

	public void calcBBox() {

		/*
		 * calcSize() isn't called because it was explicity set using setsize().
		 */
		
		// Bounding box is always at the center of object
		bv.calcCenter();

		bv.calcRadius();

		boundingBox.createIcon(bv.getBox(), 0.2f, 0.5f, 1.0f);

		boundingSphere.createIcon(10, 0.5f, 0.5f, 0.5f);

	}

}
