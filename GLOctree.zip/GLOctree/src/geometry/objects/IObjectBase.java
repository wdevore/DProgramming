package geometry.objects;

import javax.media.opengl.GL;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;

import math.Box;
import math.Sphere;

interface IObjectBase {
	/* ********************************************
	 * Methods
	 * ********************************************
	 */

	void setName(String n);

	void setColor(float r, float g, float b, float alpha);

	float[] getColor();

	void setPosition(float x, float y, float z);
	void setPosition(Point3f p);

	/**
	 * @param angle in degrees
	 * @param x component of axis of rotation
	 * @param y component of axis of rotation
	 * @param z component of axis of rotation
	 */
	void setOrientation(float angle, float x, float y, float z);

	public Sphere getWorldSphere(Matrix4f m);
	public Box getWorldBox(Matrix4f m);
	
	void render(GL gl, boolean renderMesh, float r, float g, float b);
	
}