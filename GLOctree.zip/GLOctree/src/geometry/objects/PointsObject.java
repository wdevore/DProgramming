/*
 * Created on Jan 10, 2005
 *
 */
package geometry.objects;

import geometry.arrays.PointArray;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;


/**
 * @author wdevore
 *
 * Interleaved points object.
 */
public class PointsObject extends Object3D {
	private PointArray array = new PointArray();
	
	public void render(GL gl, float r, float g, float b) {
		array.render(gl);
	}

	public void addPoint(Vector3f p, Vector3f c) {
		array.addPoint(p, c);
	}

	public void pack() {
		array.pack();
	}


}
