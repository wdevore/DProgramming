/*
 * Created on Jan 11, 2005
 *
 */
package geometry.objects;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import math.BoundingVolume;
import math.Box;
import math.Sphere;
import model.Heap;
import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class Object3D implements IObjectBase {
	private Vector3f position3f = new Vector3f();
	
	public String name = "";

	// The color of the entire object
	protected float color[] = new float[4];
	
	/*
	 * Bounding volume of object.
	 */
	protected BoundingVolume bv = new BoundingVolume();
	protected BoundingVolume bvTransformed = new BoundingVolume();
	
	/*
	 * World-space of bbox
	 */
	Box worldBBox = new Box();
	
	/* ********************************************************
	 * Methods
	 * ********************************************************
	 */
	public BoundingVolume getBoundingVolume() {
		return bv;
	}
	public BoundingVolume getBoundingVolumeTransformed() {
		return bvTransformed;
	}
	
	/*
	 * We pass in a Matrix transforms the volume from object-space to world-space.
	 */ 
	public Sphere getWorldSphere(Matrix4f m) {
		Heap.bSphereTransformed.set(bv.bSphere);
		if (m == null) {
			Heap.bSphereTransformed.center.add(getPosition());
			return Heap.bSphereTransformed;
		} else {
			// Transform the sphere's center based on matrix
			Heap.bSphereTransformed.center.add(getPosition());
			return Heap.bSphereTransformed;
		}
	}

	public Box getWorldBox(Matrix4f m) {
		worldBBox.set(bv.bBox);
		if (m == null) {
			worldBBox.center.add(getPosition());
			return worldBBox;
		} else {
			// Transform the sphere's center based on matrix
			worldBBox.center.add(getPosition());
			return worldBBox;
		}
	}

	public float[] getColor() {
		return color;
	}

	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		System.err.println("Object3D::render() should be implemented!");
	}
	
	public void setColor(float r, float g, float b, float alpha) {
		color[0] = r;
		color[1] = g;
		color[2] = b;
		color[3] = alpha;
	}
	public void setName(String n) {
		name = n;

	}
	public void setOrientation(float angle, float x, float y, float z) {
		// TODO Auto-generated method stub

	}
	public void setPosition(float x, float y, float z) {
		position3f.set(x, y, z);
	}
	public void setPosition(Point3f p) {
		position3f.set(p.x, p.y, p.z);
	}
	public void setPosition(Vector3f v) {
		position3f.set(v);
	}

	public Vector3f getPosition() {
		return position3f;
	}
	

}
