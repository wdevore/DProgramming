/*
 * Created on Mar 15, 2005
 *
 */
package geometry.objects;

import geometry.meshes.ConeMesh;

import javax.vecmath.Vector3f;

import math.BoundingVolume;
import math.Cone;
import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class ConeObject extends Object3D {
	private Vector3f v1 = new Vector3f();

	private ConeMesh boundingCone = new ConeMesh();

	/*
	 * Bounding cone of object.
	 */
	public Cone bCone = new Cone();

	public ConeObject(String s) {
		super();
		name = s;
	}
	public void setSize(float w, float h, float d) {
		
	}
	
	public BoundingVolume getBoundingVolume() {
		return bv;
	}
	
	public Cone getCone() {
		return bCone;
	}
	
	public void setVertex(Vector3f v) {
		bCone.vertex.set(v);
	}

	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		gl.glColor3f(color[0], color[1], color[2]);
		gl.glPushMatrix();
		v1.set(getPosition());
		gl.glTranslatef(v1.x, v1.y, v1.z);
		boundingCone.render(bCone, gl);
		gl.glPopMatrix();
	}
	
	public void createIcon(float divisions, float r, float g, float b) {
		boundingCone.createIcon(getCone(), divisions, r, g, b);
	}

}
