/*
 * Created on Mar 10, 2005
 *
 */
package geometry.objects;

import geometry.meshes.SphereMesh;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

import math.BoundingVolume;
import math.Sphere;

/**
 * @author wdevore
 * 
 */
public class SphereObject extends Object3D {
	private Vector3f v1 = new Vector3f();

	private SphereMesh boundingSphere = new SphereMesh();

	public SphereObject(String s) {
		super();
		name = s;
	}

	public void setSize(float w, float h, float d) {

	}

	public BoundingVolume getBoundingVolume() {
		return bv;
	}

	public Sphere getSphere() {
		return bv.bSphere;
	}

	public void setCenter(Vector3f v) {
		bv.bBox.center.set(v);
	}

	public void render(GL gl, boolean renderMesh, float r, float g, float b) {
		gl.glColor3f(color[0], color[1], color[2]);
		gl.glPushMatrix();
		v1.set(getPosition());
		gl.glTranslatef(v1.x, v1.y, v1.z);
		boundingSphere.render(bv.getSphere(), gl);
		gl.glPopMatrix();
	}

	public void createIcon(float divisions, float r, float g, float b) {
		boundingSphere.createIcon(divisions, r, g, b);
	}

}
