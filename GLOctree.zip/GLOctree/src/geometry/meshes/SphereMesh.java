/*
 * Created on Feb 27, 2005
 *
 */
package geometry.meshes;

import geometry.arrays.MultiColorLineArray;

import javax.vecmath.Vector3f;

import math.Sphere;
import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class SphereMesh {
	private MultiColorLineArray array = new MultiColorLineArray();
	
	public SphereMesh() {
	}
	
	public void render(Sphere s, GL gl) {
		gl.glPushMatrix();
		gl.glTranslatef(s.center.x, s.center.y, s.center.z);
//		gl.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
		gl.glScalef(s.getRadius(), s.getRadius(), s.getRadius());
		array.render(gl);
		gl.glPopMatrix();
	}

	public void reset() {
		array.reset();
	}

	public void createIcon(float divisions, float r, float g, float b) {
		Vector3f v = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f c1 = new Vector3f();
		c1.set(r, g, b);
		
		float xa = 0.0f;
		xa += Math.toRadians(divisions);
		float rx1 = (float)Math.sin(xa);
		float rz1 = (float)Math.cos(xa);
		for (; xa < 2.0*Math.PI; ) {
			xa += Math.toRadians(divisions);
			float rx2 = (float)Math.sin(xa);
			float rz2 = (float)Math.cos(xa);
			v.set(rx1, 0.0f, rz1);
			v2.set(rx2, 0.0f, rz2);
			array.addLine(v, v2, c1, c1);
			rx1 = rx2;
			rz1 = rz2;
		}
		
		xa = 0.0f;
		rx1 = (float)Math.sin(xa);
		rz1 = (float)Math.cos(xa);
		for (; xa < 2.0*Math.PI; ) {
			xa += Math.toRadians(divisions);
			float rx2 = (float)Math.sin(xa);
			float rz2 = (float)Math.cos(xa);
			v.set(rx1, rz1, 0.0f);
			v2.set(rx2, rz2, 0.0f);
			array.addLine(v, v2, c1, c1);
			rx1 = rx2;
			rz1 = rz2;
		}

		xa = 0.0f;
		rx1 = (float)Math.sin(xa);
		rz1 = (float)Math.cos(xa);
		for (; xa < 2.0*Math.PI; ) {
			xa += Math.toRadians(divisions);
			float rx2 = (float)Math.sin(xa);
			float rz2 = (float)Math.cos(xa);
			v.set(0.0f, rx1, rz1);
			v2.set(0.0f, rx2, rz2);
			array.addLine(v, v2, c1, c1);
			rx1 = rx2;
			rz1 = rz2;
		}
		
		array.pack();
	}

}
