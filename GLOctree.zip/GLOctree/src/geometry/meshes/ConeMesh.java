/*
 * Created on Mar 14, 2005
 *
 */
package geometry.meshes;

import geometry.arrays.MultiColorLineArray;

import javax.vecmath.Vector3f;

import math.Cone;
import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class ConeMesh {
	private MultiColorLineArray array = new MultiColorLineArray();
	
	public ConeMesh() {
	}
	
	public void render(Cone cone, GL gl) {
		gl.glPushMatrix();
		gl.glTranslatef(cone.vertex.x, cone.vertex.y, cone.vertex.z);
		array.render(gl);
		gl.glPopMatrix();
	}

	public void reset() {
		array.reset();
	}

	public void createIcon(Cone cone, float divisions, float r, float g, float b) {
		Vector3f v = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f c1 = new Vector3f();
		c1.set(r, g, b);
		
		// Form circle first
		float xa = 0.0f;
		xa += Math.toRadians(divisions);
		float rx1 = cone.baseRadius*(float)Math.sin(xa);
		float rz1 = cone.baseRadius*(float)Math.cos(xa);
		int flip = 0;
		
		for (; xa < 2.0*Math.PI; ) {
			xa += Math.toRadians(divisions);
			float rx2 = cone.baseRadius*(float)Math.sin(xa);
			float rz2 = cone.baseRadius*(float)Math.cos(xa);
			v.set(rx1, rz1, cone.base.z);
			v2.set(rx2, rz2, cone.base.z);
			array.addLine(v, v2, c1, c1);
			
			if (flip > 2) {
				v.set(rx1, rz1, cone.base.z);
				v2.set(0.0f, 0.0f, 0.0f);
				array.addLine(v, v2, c1, c1);
				flip = 0;
			} else
				flip++;
			
			rx1 = rx2;
			rz1 = rz2;
		}
		
		array.pack();
	}


}
