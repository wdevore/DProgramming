/*
 * Created on Mar 2, 2005
 *
 */
package geometry.meshes;

import javax.vecmath.Vector3f;

import javax.media.opengl.GL;
import geometry.arrays.MultiColorLineArray;
import math.Box;

/**
 * @author wdevore
 *
 */
public class MultiColorBoxMesh {
	private MultiColorLineArray array = new MultiColorLineArray();
	
	public void render(GL gl) {
		array.render(gl);
	}

	public void reset() {
		array.reset();
	}

	public void createIcon(Box bbox, float r, float g, float b) {
		Vector3f v = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f c1 = new Vector3f();
		c1.set(r, g, b);

		// intersecting lines
//		c1.set(0.0f, g, 0.0f);
//		v.set(bbox.center.x, bbox.center.y, bbox.center.z - bbox.halfSize.z);
//		v2.set(bbox.center.x, bbox.center.y, bbox.center.z + bbox.halfSize.z);
//		array.addLine(v, v2, c1, c1);
//
//		c1.set(0.0f, g, 0.0f);
//		v.set(bbox.center.x, bbox.center.y + bbox.halfSize.y, bbox.center.z);
//		v2.set(bbox.center.x, bbox.center.y - bbox.halfSize.y, bbox.center.z);
//		array.addLine(v, v2, c1, c1);
//		
//		c1.set(0.0f, g, 0.0f);
//		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y, bbox.center.z);
//		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y, bbox.center.z);
//		array.addLine(v, v2, c1, c1);
		
		// front side
//		c1.set(1.0f, 1.0f, 1.0f);
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		// depth sides
//		c1.set(r, g, b);
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);
		
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		// backside
//		c1.set(1.0f, 1.0f, 1.0f);
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2, c1, c1);

		array.pack();
	}

	public int getIndexCount() {
		return array.getIndexCount();
	}

	public int[] getIndex(int v) {
		return array.getIndex(v);
	}
	
	public float[] getVertex(int i) {
		return array.getVertex(i);
	}

}
