/*
 * Created on Mar 2, 2005
 *
 */
package geometry.meshes;

import geometry.arrays.LineArray;

import javax.media.opengl.GL;
import javax.vecmath.Vector3f;

import math.Box;

/**
 * @author wdevore
 *
 */
public class BoxMesh {
	private LineArray array = new LineArray();
	private float r, g, b;
	
	public void render(GL gl) {
		gl.glPushAttrib(GL.GL_COLOR_MATERIAL);
		gl.glColor3f(r, g, b);
		array.render(gl);
		gl.glPopAttrib();
	}

	public void reset() {
		array.reset();
	}

	public void setColor(float r, float g, float b) {
		this.r = r;
		this.g = g;
		this.b = b;
	}
	
	public void createIcon(Box bbox, float r, float g, float b) {
		Vector3f v = new Vector3f();
		Vector3f v2 = new Vector3f();
		//Vector3f c1 = new Vector3f();
		setColor(r, g, b);

		// front side
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		array.addLine(v, v2);

		// depth sides
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);
		
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z + bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		// backside
		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x - bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		v.set(bbox.center.x + bbox.halfSize.x, bbox.center.y - bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		v2.set(bbox.center.x + bbox.halfSize.x, bbox.center.y + bbox.halfSize.y, bbox.center.z - bbox.halfSize.z);
		array.addLine(v, v2);

		array.pack();
	}

	public int getIndexCount() {
		return array.getIndexCount();
	}

	public int[] getIndex(int v) {
		return array.getIndex(v);
	}
	
	public float[] getVertex(int i) {
		return array.getVertex(i);
	}

}
