/*
 * Created on Jan 14, 2005
 *
 */
package geometry.meshes;

import geometry.arrays.TriangleArray;

import javax.vecmath.Vector3f;

import model.Heap;
import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class TrianglesMesh {
	/*
	 * Flat shading requires a normal for each vertex of a triangle.
	 * Smooth shading requires a normal for each vertex of a mesh.
	 */
	public static final int FLAT = 0;
	public static final int SMOOTH = 1;

	public static final boolean OUTLINE = true;
	public static final boolean NOOUTLINE = false;

	private TriangleArray array = new TriangleArray();
	private Vector3f v1 = new Vector3f();
	private Vector3f v2 = new Vector3f();
	private Vector3f v3 = new Vector3f();

	private boolean renderNormals = false;
	private int shadeModel = FLAT;
	private boolean outlineMode = NOOUTLINE;
	
	private float polyFactor = 1.0f;
	private float polyUnits = 1.0f;
	
	public void render(GL gl) {
		gl.glPushAttrib(GL.GL_COLOR_MATERIAL);
		if (shadeModel == FLAT)
			gl.glShadeModel(GL.GL_FLAT);
		else
			gl.glShadeModel(GL.GL_SMOOTH);

		if (outlineMode == OUTLINE) {
			/*
			 * Render mesh first with offset applied.
			 */
			gl.glEnable(GL.GL_POLYGON_OFFSET_FILL);
			gl.glPolygonOffset(polyFactor, polyUnits);
			array.render(gl);
			gl.glDisable(GL.GL_POLYGON_OFFSET_FILL);
			
			/*
			 * Now render mesh as a wireframe object.
			 */
			gl.glDisable(GL.GL_LIGHTING);
			gl.glColor3f(1.0f, 1.0f, 1.0f);
			gl.glPolygonMode(GL.GL_FRONT, GL.GL_LINE);
			array.render(gl);
			gl.glPolygonMode(GL.GL_FRONT, GL.GL_FILL);
			gl.glEnable(GL.GL_LIGHTING);
		} else {
			array.render(gl);
		}
		
		if (!renderNormals) {
			gl.glPopAttrib();
			return;
		}
		
		float[] na;
		float[] va;
		gl.glDisable(GL.GL_LIGHTING);
		int nc = array.getNormalCount();
		for (int i = 0; i < nc; i++) {
			na = array.getNormal(i);
			va = array.getVertex(i);
			gl.glPushMatrix();
			gl.glColor3f(255.0f/255.0f, 128.0f/255.0f, 64.0f/255.0f);
			gl.glTranslatef(va[0], va[1], va[2]);
			gl.glBegin(GL.GL_LINES);
			gl.glVertex3f(0.0f, 0.0f, 0.0f);
			gl.glVertex3f(na[0]*5.0f, na[1]*5.0f, na[2]*5.0f);
			gl.glEnd();
			gl.glColor3f(255.0f/255.0f, 255.0f/255.0f, (128.0f+64.0f)/255.0f);
			gl.glBegin(GL.GL_POINTS);
			gl.glVertex3f(na[0]*5.0f, na[1]*5.0f, na[2]*5.0f);
			gl.glEnd();
			gl.glPopMatrix();
		}
		gl.glEnable(GL.GL_LIGHTING);
		gl.glPopAttrib();
	}

	public void addTriangle(Vector3f n0, Vector3f n1, Vector3f n2, Vector3f v0, Vector3f v1, Vector3f v2) {
		array.addTriangle(n0, n1, n2, v0, v1, v2);
	}

	public void addTriangle(Vector3f v1, Vector3f v2, Vector3f v3) {
		this.v1.sub(v2, v1);	// v2 - v1
		this.v2.sub(v3, v1);	// v3 - v1
		this.v3.cross(this.v1, this.v2);
		this.v3.normalize();
		array.addTriangle(this.v3, v1, v2, v3);
	}

	public void reset() {
		array.reset();
	}

	public void pack() {
		array.pack();
	}

	public void addVertex(Vector3f v) {
		array.addVertex(v.x, v.y, v.z);
	}
	
	public void addFace(int i1, int i2, int i3) {
		array.addIndex(i1);
		array.addIndex(i2);
		array.addIndex(i3);
	}
	
	public int getVertexCount() {
		return array.getVertexCount();
	}
	
	public int getIndexCount() {
		return array.getIndexCount();
	}

	public int[] getIndex(int v) {
		return array.getIndex(v);
	}
	
	public float[] getVertex(int i) {
		return array.getVertex(i);
	}
	
	public void renderNormals(boolean flag) {
		renderNormals = flag;
	}
	
	public void setShadeModel(int sm) {
		shadeModel = sm;
	}
	
	public void setOutlineMode(boolean m) {
		outlineMode = m;
	}
	
	public Vector3f calcNormal(int i1, int i2, int i3) {
		float f[];
		f = array.getVertex(i1);
		v1.set(f[0], f[1], f[2]);
		f = array.getVertex(i2);
		v2.set(f[0], f[1], f[2]);
		f = array.getVertex(i3);
		v3.set(f[0], f[1], f[2]);
		Heap.v1.sub(v2, v1);	// v2 - v1
		Heap.v2.sub(v3, v1);	// v3 - v1
		Heap.v3.cross(Heap.v1, Heap.v2);
		Heap.v3.normalize();
		return Heap.v3;
	}
	
	/*
	 * This algorithm should be replace with a structure similar to winged
	 * edges. This should dramatically improve initial performance.
	 */
	public void calcNormals() {
		if (shadeModel == FLAT) {
			return; // normal average not needed
		}
		
		int shared = 0;
		Vector3f vSum = new Vector3f();
		int i1[], i2[], i3[];
		float f[];
		Vector3f v11 = new Vector3f();
		Vector3f v22 = new Vector3f();
		Vector3f v33 = new Vector3f();
		

		// visit each vertex
		for (int v = 0; v < array.getVertexCount(); v++) {
			for (int i = 0; i < array.getIndexCount(); i += 3) {
				i1 = array.getIndex(i);
				i2 = array.getIndex(i+1);
				i3 = array.getIndex(i+2);
				if (i1[0] == v || i2[0] == v || i3[0] == v) {
					f = array.getVertex(i1[0]);
					v1.set(f[0], f[1], f[2]);
					f = array.getVertex(i2[0]);
					v2.set(f[0], f[1], f[2]);
					f = array.getVertex(i3[0]);
					v3.set(f[0], f[1], f[2]);
					/*
					 * By summing a non normalized vector I am weighting the
					 * average normal towards the faces with the larger area
					 * giving a slightly better appearence.
					 */
					v11.sub(v2, v1);	// v2 - v1
					v22.sub(v3, v1);	// v3 - v1
					v33.cross(v11, v22);
//					v33.normalize();
					vSum.add(v33);
					
					// Add the un-normalized normal of the shared face
					shared++; // Increase the number of shared triangles
				}
			}
			// Get the average normal by dividing the sum by the shared.
			if (shared > 0) {
				vSum.scale(1.0f / (float) (shared));
			}
			vSum.normalize();
			array.addNormal(vSum.x, vSum.y, vSum.z);
			vSum.set(0.0f, 0.0f, 0.0f);
			shared = 0;
		}
		vSum = null;
		v11 = null;
		v22 = null;
		v33 = null;
	}
	
}
