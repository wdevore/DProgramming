/*
 * Created on Feb 27, 2005
 *
 */
package geometry.meshes;


import geometry.arrays.MultiColorLineArray;

import javax.vecmath.Vector3f;

import math.Frustum;
import javax.media.opengl.GL;

/**
 * @author wdevore
 *
 */
public class FrustumMesh {
	// wireframe of frustum
	private MultiColorLineArray array = new MultiColorLineArray();

	// Frustum walls
	private TrianglesMesh triMesh = new TrianglesMesh();

	public void render(GL gl) {
		// I just want the color of the plane not any shading.
		gl.glPushAttrib(GL.GL_COLOR_MATERIAL);
		array.render(gl);
		gl.glPopAttrib();
		triMesh.render(gl);
	}

	public void reset() {
		array.reset();
		triMesh.reset();
	}

	/*
	 * This is the visual icon rendered on the screen.
	 */
	public void buildMesh(Frustum f) {
		/*
		 * Local temp variables
		 */
		Vector3f v1 = new Vector3f();
		Vector3f v2 = new Vector3f();
		Vector3f v3 = new Vector3f();

		/*
		 * Visual frustum planes
		 */
		
		// Or simply turn off combinedMatrixping while drawing the frustum.
		
		// Left side
		v1.set(f.left, f.bottom, -f.near);
		v2.set(f.left_far, f.bottom_far, -f.far);
		v3.set(f.left_far, f.top_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);
		
		v1.set(f.left, f.bottom, -f.near);
		v2.set(f.left_far, f.top_far, -f.far);
		v3.set(f.left, f.top, -f.near);
		triMesh.addTriangle(v3, v2, v1);

		// right side
		v1.set(f.right, f.bottom, -f.near);
		v2.set(f.right_far, f.top_far, -f.far);
		v3.set(f.right_far, f.bottom_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);
		v1.set(f.right, f.bottom, -f.near);
		v2.set(f.right, f.top, -f.near);
		v3.set(f.right_far, f.top_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);

		// bottom side
		v1.set(f.left, f.bottom, -f.near);
		v2.set(f.right_far, f.bottom_far, -f.far);
		v3.set(f.left_far, f.bottom_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);
		v1.set(f.left, f.bottom, -f.near);
		v2.set(f.right, f.bottom, -f.near);
		v3.set(f.right_far, f.bottom_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);

		// top side
		v1.set(f.left, f.top, -f.near);
		v2.set(f.right_far, f.top_far, -f.far);
		v3.set(f.right, f.top, -f.near);
		triMesh.addTriangle(v3, v2, v1);
		v1.set(f.left, f.top, -f.near);
		v2.set(f.left_far, f.top_far, -f.far);
		v3.set(f.right_far, f.top_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);

		// near plane side
		v1.set(f.left, f.bottom, -f.near);
		v2.set(f.left, f.top, -f.near);
		v3.set(f.right, f.top, -f.near);
		triMesh.addTriangle(v3, v2, v1);
		v1.set(f.left, f.bottom, -f.near);
		v2.set(f.right, f.top, -f.near);
		v3.set(f.right, f.bottom, -f.near);
		triMesh.addTriangle(v3, v2, v1);

		// far plane side
		v1.set(f.left_far, f.bottom_far, -f.far);
		v2.set(f.right_far, f.top_far, -f.far);
		v3.set(f.left_far, f.top_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);
		v1.set(f.left_far, f.bottom_far, -f.far);
		v2.set(f.right_far, f.bottom_far, -f.far);
		v3.set(f.right_far, f.top_far, -f.far);
		triMesh.addTriangle(v3, v2, v1);

		triMesh.pack();

		Vector3f c1 = new Vector3f();
		Vector3f c2 = new Vector3f();

		// Eye to near plane
		c1.set(1.0f, 1.0f, 1.0f);
		v1.set(0.0f, 0.0f, 0.0f);
		/*
		 * The last color defined is the color used when render
		 * in GL_FLAT model.
		 */
		c2.set(1.0f, 0.1f, 0.1f);
		v2.set(f.left, f.bottom, -f.near);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(1.0f, 1.0f, 1.0f);
		v1.set(0.0f, 0.0f, 0.0f);
		c2.set(1.0f, 0.1f, 0.1f);
		v2.set(f.right, f.bottom, -f.near);
		array.addLine(v1, v2, c1, c2);

		c1.set(1.0f, 1.0f, 1.0f);
		v1.set(0.0f, 0.0f, 0.0f);
		c2.set(1.0f, 0.1f, 0.1f);
		v2.set(f.left, f.top, -f.near);
		array.addLine(v1, v2, c1, c2);

		c1.set(1.0f, 1.0f, 1.0f);
		v1.set(0.0f, 0.0f, 0.0f);
		c2.set(1.0f, 0.1f, 0.1f);
		v2.set(f.right, f.top, -f.near);
		array.addLine(v1, v2, c1, c2);

		/*
		 * When we visually draw the frustum we need to adjust its volume by
		 * just an Epsilon amount so that it is not combinedMatrixped out. Afterall we
		 * to visually SEE the frustum.
		 */
		// left side
		c1.set(0.0f, 0.5f, 0.0f);
		v1.set(f.left, f.bottom, -f.near);
		c2.set(0.0f, 0.5f, 0.0f);
		v2.set(f.left_far, f.bottom_far, -f.far);
		v2.scale(1.0f);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(0.0f, 0.5f, 0.0f);
		v1.set(f.left, f.top, -f.near);
		c2.set(0.0f, 0.5f, 0.0f);
		v2.set(f.left_far, f.top_far, -f.far);
		v2.scale(1.0f);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(0.0f, 0.5f, 0.0f);
		v1.set(f.right, f.bottom, -f.near);
		c2.set(0.0f, 0.5f, 0.0f);
		v2.set(f.right_far, f.bottom_far, -f.far);
		v2.scale(1.0f);
		array.addLine(v1, v2, c1, c2);

		c1.set(0.0f, 0.5f, 0.0f);
		v1.set(f.right, f.top, -f.near);
		c2.set(0.0f, 0.5f, 0.0f);
		v2.set(f.right_far, f.top_far, -f.far);
		v2.scale(1.0f);
		array.addLine(v1, v2, c1, c2);

		/*
		 * border out-lines
		 */
		// far plane lines
		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.left_far, f.bottom_far, -f.far);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.left_far, f.top_far, -f.far);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.left_far, f.top_far, -f.far);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.right_far, f.top_far, -f.far);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.right_far, f.top_far, -f.far);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.right_far, f.bottom_far, -f.far);
		array.addLine(v1, v2, c1, c2);

		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.right_far, f.bottom_far, -f.far);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.left_far, f.bottom_far, -f.far);
		array.addLine(v1, v2, c1, c2);

		// near plane
		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.left, f.bottom, -f.near);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.left, f.top, -f.near);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(0.0f, 0.5f, 1.0f);
		v1.scale(1.0f);
		v1.set(f.left, f.top, -f.near);
		c2.set(0.0f, 0.5f, 1.0f);
		v2.scale(1.0f);
		v2.set(f.right, f.top, -f.near);
		array.addLine(v1, v2, c1, c2);
		
		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.right, f.top, -f.near);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.right, f.bottom, -f.near);
		array.addLine(v1, v2, c1, c2);

		c1.set(1.0f, 0.5f, 0.0f);
		v1.scale(1.0f);
		v1.set(f.right, f.bottom, -f.near);
		c2.set(1.0f, 0.5f, 0.0f);
		v2.scale(1.0f);
		v2.set(f.left, f.bottom, -f.near);
		array.addLine(v1, v2, c1, c2);

		// LOS
		c1.set(1.0f, 1.0f, 1.0f);
		v1.set(0.0f, 0.0f, 0.0f);
		c2.set(0.0f, 0.0f, 0.0f);
		v2.set(0.0f, 0.0f, -f.far);
		array.addLine(v1, v2, c1, c2);
		
		array.pack();
		
		v1 = null;
		v2 = null;
		v3 = null;

		c1 = null;
		c2 = null;
	}
	
}
