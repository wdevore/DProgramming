/*
 * Created on Jan 21, 2005
 *
 */
package math;

import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;

import model.Heap;

/**
 * @author wdevore
 *
 */
public class VectorAlgebra {
	public static final int INSIDE = 1;
	public static final int OUTSIDE = 0;
	
	private static Vector3f v1 = new Vector3f();
	private static Vector3f v2 = new Vector3f();
	private static Vector3f v3 = new Vector3f();
	private static float EPSILON = 0.0001f;
	private static Vector3f rotAxis = new Vector3f();
	private static AxisAngle4f aa = new AxisAngle4f();
	private static float dot = 0.0f;
	private static float angle = 0.0f;
	
	private static Matrix3f rot = new Matrix3f();
	private static Matrix3f yawRotation = new Matrix3f();
	private static Matrix3f pitchRotation = new Matrix3f();

	/**
	 * a is crossed into b.
	 * @param a	vector direction we want to align to.
	 * @param b vector direction we want to align from. 
	 * @return
	 * <ul>
	 * <li>0 means they are not colinear.</li>
	 * <li>1 means they are colinear and in opposite directions.</li>
	 * <li>2 means they are colinear and in the same direction.</li>
	 * </ul>
	 */
	public static int isColLinear(Vector3f a, Vector3f b) {
		/*
		 * check to see if a and b are collinear
		 */
		v2.set(a);
		v3.set(b);
		
		v2.normalize();
		v3.normalize();
		
		/*
		 * Remember, the dot product returns cos(theta) which means that in
		 * order to get theta you must use acos(cos(theta)) where
		 * theta is the angle between the two vectors.
		 */
		dot = v2.dot(v3);
		rotAxis.cross(v2, v3);	// a cross into b. right hand rule.
		
		v2.set(rotAxis);
		v2.absolute();
		
		if (v2.x < EPSILON && v2.y < EPSILON && v2.z < EPSILON) {
			// They are collinear. Are they pointing in opposite directions?
			if (dot < 0.0f) {
				// Opposite.
				return 1;
			} else {
				return 2;
			}
		}
		return 0;
	}
	
	/**
	 * Form a rotation about an axis that will rotate from one
	 * Vector into another. Note that a twist may or may not be introduced
	 * along the axis of rotation.
	 * @return
	 */
	public static Matrix3f getColLinearRotation(Vector3f a) {
		calcColLinearRotation(a);
		
		rotAxis.normalize();
		aa.set(rotAxis, (float)Math.acos(dot));
		rot.set(aa);
		return rot;
	}
	
	/**
	 * Calculate twist correction axis.
	 * return a rotation that aligns around the dir vector to a vertical
	 * <b>Note:</b> <i>I would use the YawPitch version instead of this one when
	 * animating the camera along a curved path.</i>
	 * 
	 * @param rot any prerotations
	 * @param dir the direction (axis) to rotate around
	 * @return
	 */
	public static Matrix3f getVerticalAlignRotation(Matrix3f rot, Vector3f dir) {
		
		/*
		 * The world +y axis (wy) is our vertical alignment axis. This is what
		 * we want to align vertically to.
		 */
		Heap.v1.set(0.0f, 1.0f, 0.0f);	// wy

		/*
		 * Find the vector perpendicular to the dir vector and wy. The dir
		 * vector can thought of as the line-of-sight (los). This is done by
		 * crossing dir into wy. This cross product always
		 * yields a vector in the local +xy plane called (px). It is px that is 
		 * dotted with the local +x axis (lx) to get the angle to rotate
		 * about dir.
		 */
		int r = isColLinear(dir, Heap.v1);
		if (r != 0) {
			/*
			 * [dir] is collinear with the y axis. No rotation required.
			 */
			if (r == 1) {
				/*
				 * Opposite directions. Rotate about y-axis PI radians.
				 */
				rotAxis.set(0.0f, 1.0f, 0.0f);
				dot = (float)Math.cos(Math.PI);
			}

			if (r == 2) {
				/*
				 * same direction. Rotate about y-axis 0 radians.
				 */
				rotAxis.set(0.0f, 1.0f, 0.0f);
				dot = 1.0f;
			}
			Heap.aa.set(rotAxis, dot);
			Heap.rot2.set(Heap.aa);
			return Heap.rot2;
		}
		
		Heap.v3.cross(dir, Heap.v1);
		Heap.v3.normalize();

		/*
		 * v3 is now px.
		 * and v2 is lx.
		 */
		Heap.v1.set(1.0f, 0.0f, 0.0f);	// world x axis
		rot.transform(Heap.v1, Heap.v2);	// now it is local x axis (lx).
		Heap.v2.normalize();
		
		/*
		 * Now we get the angle between them. First by taking the
		 * dot product and then taking the ArcCosine of the results.
		 */
		dot = Heap.v3.dot(Heap.v2);	// generates cos(theta)
		
		angle = (float)Math.acos(dot);	// get theta

		/*
		 * This is a small Hack. We are pushing the resultant cross product
		 * slightly off axis such that a solution is available.
		 * Note: This hack is only needed if you are converting from matrices
		 * to quaternions. It is the mapping from 3-space to 4-space that
		 * raise the problem.
		 */
		if (Math.abs(Math.PI - angle) < EPSILON)
			angle -= Math.PI/10000.0f;
		
		/* ****************************************
		 * This version checks the octant that the direction is coming
		 * from.
		 * Space is divided into 8 cubes (octants). Depending on which octant
		 * the direction is coming from either a CW or CCW rotation is needed
		 * about the LOS.
		 * Because the -z axis was chosen as the reference basis vector the
		 * require rotation for each octant are fixed as follows:
		 * CCW:			CW:
		 * -,-,-		+,-,-
		 * +,+,+		+,-,+
		 * +,+,-		-,+,+
		 * -,-,+		-,+,-
		 * 
		 */
		Heap.rot2.setIdentity();
		if ((dir.x >= 0.0f && dir.y <= 0.0f && dir.z <= 0.0f)
				|| (dir.x >= 0.0f && dir.y <= 0.0f && dir.z >= 0.0f)
				|| (dir.x <= 0.0f && dir.y >= 0.0f && dir.z >= 0.0f)
				|| (dir.x <= 0.0f && dir.y >= 0.0f && dir.z <= 0.0f)) {
			/*
			 * This direction/octant requires a CW rotation instead of CCW.
			 * This is the default. Nothing to be done.
			 */
		} else {
			/*
			 * This direction/octant requires a CCW rotation instead of CW.
			 */
			angle = -angle;
		}
		Heap.aa.set(dir, angle);
		Heap.rot2.set(Heap.aa);
		
		return Heap.rot2;
	}

	public static float[] getVerticalAlignRotationArray(Matrix3f rot, Vector3f dir) {
		Heap.rot2 = getVerticalAlignRotation(rot, dir);
		VectorAlgebra.matrixToArray(Heap.rot2, Heap.rArray2);
		return Heap.rArray2;
		
	}
	
	/**
	 * Calculates the axis and angle necessary to rotate the vector from the
	 * reference -z axis to the provided input vector.
	 * @param a the vector to align to.
	 */
	private static void calcColLinearRotation(Vector3f a) {
		/*
		 * Attempt to get a rotational axis using the
		 * z-axis as reference
		 */
		v1.set(0.0f, 0.0f, -1.0f);

		int r = isColLinear(v1, a);
		if (r == 0)
			return;

		if (r == 1) {
			/*
			 * Opposite directions. Rotate about y-axis PI radians.
			 */
			rotAxis.set(0.0f, 1.0f, 0.0f);
			dot = (float)Math.cos(Math.PI);
			return;
		}

		if (r == 2) {
			/*
			 * same direction. Rotate about y-axis 0 radians.
			 */
			rotAxis.set(0.0f, 1.0f, 0.0f);
			dot = 1.0f;
		}
	}

	public static void matrixToArray(Matrix3f rotation, float[] rArray) {
		
		rArray[0] = rotation.m00;
		rArray[1] = rotation.m10;
		rArray[2] = rotation.m20;
		rArray[3] = 0.0f;
		rArray[4] = rotation.m01;
		rArray[5] = rotation.m11;
		rArray[6] = rotation.m21;
		rArray[7] = 0.0f;
		rArray[8] = rotation.m02;
		rArray[9] = rotation.m12;
		rArray[10] = rotation.m22;
		rArray[11] = 0.0f;
		rArray[12] = 0.0f;
		rArray[13] = 0.0f;
		rArray[14] = 0.0f;
		rArray[15] = 1.0f;
		
	}

	public static void matrixToArray(Matrix4f rotation, float[] rArray) {
		/*
		 * If you use this transpose then you need to change the
		 * getElement() from "c,r" to "r,c". Why?
		 * Because Java3D's set methods are Row-major.
		 */
//		transform.transpose();
		
		
		// slow transfer
//		int i = 0;
//		for (int r = 0; r < 4; r++) {
//			for (int c = 0; c < 4; c++) {
//				// OpenGL is Column-major hence "c,r" and not "r,c"
//				mArray[i] = transform.getElement(c, r);
//				i++;
//			}
//		}
		
		rArray[0] = rotation.m00;
		rArray[1] = rotation.m10;
		rArray[2] = rotation.m20;
		rArray[3] = rotation.m30;
		rArray[4] = rotation.m01;
		rArray[5] = rotation.m11;
		rArray[6] = rotation.m21;
		rArray[7] = rotation.m31;
		rArray[8] = rotation.m02;
		rArray[9] = rotation.m12;
		rArray[10] = rotation.m22;
		rArray[11] = rotation.m32;
		rArray[12] = rotation.m03;
		rArray[13] = rotation.m13;
		rArray[14] = rotation.m23;
		rArray[15] = rotation.m33;
		
	}

	public static void arrayToMatrix(float[] rArray, Matrix4f rotation) {
		rotation.m00 = rArray[0];
		rotation.m10 = rArray[1];
		rotation.m20 = rArray[2];
		rotation.m30 = rArray[3];
		rotation.m01 = rArray[4];
		rotation.m11 = rArray[5];
		rotation.m21 = rArray[6];
		rotation.m31 = rArray[7];
		rotation.m02 = rArray[8];
		rotation.m12 = rArray[9];
		rotation.m22 = rArray[10];
		rotation.m32 = rArray[11];
		rotation.m03 = rArray[12];
		rotation.m13 = rArray[13];
		rotation.m23 = rArray[14];
		rotation.m33 = rArray[15];
	}
	
	public static Matrix3f yawPitchLookAt(Vector3f vDir) {

		v1.set(vDir); 
		v1.normalize();	// [dir]

		v2.set(v1);
		// Check for a vertical direction.
		if (Math.abs(v2.x) < EPSILON && Math.abs(v2.z) < EPSILON ) {
			rot.setIdentity();
			if (v2.y > 0.0f)
				rot.rotX((float)Math.toRadians(-90.0));
			else
				rot.rotX((float)Math.toRadians(90.0));
			return rot;
		}
		v2.y = 0.0f;	// [dir] projected onto xz plane
		v2.normalize();	// P

		v3.set(0.0f, 0.0f, -1.0f); // -z axis
		float dot = v2.dot(v3);

		/*
		 * This is the angle between P and -z axis
		 */
		double dYaw = Math.acos(dot);

		/*
		 * Determine CW or CCW rotation on +y axis.
		 * does P point to the negative half space of the yz plane
		 * or positive half. If P.x < 0 then it is pointing towards
		 * the negative half space. Hence a positive rotation is required to
		 * rotate the -z axis vector into alignment with P vector. That means
		 * a positive rotation will make the -z axis co-align with the
		 * P vector. 
		 */
		if (v2.x > 0)
			dYaw = -dYaw; // CW rotation needed

		/*
		 * Now determine Pitch about the +x axis. This is determined by getting
		 * the angle between the +y axis and [dir] and subtracting 90 degrees.
		 * This is the same as finding the angle between the [dir] vector and
		 * the xz plane. We could have use code that finds the angle between
		 * a vector and a plane.
		 */
		v3.set(0.0f, 1.0f, 0.0f); // +y axis
		dot = v1.dot(v3);
		double dPitch = Math.acos(dot);
		dPitch = (Math.toRadians(90.0) - dPitch);

		rot.setIdentity();
		
		yawRotation.rotY((float)-dYaw);
		pitchRotation.rotX((float)-dPitch);
		rot.mul(pitchRotation, yawRotation);

		return rot;
	}

	public static int sphereIntersectCone(Sphere s, Cone k) {
		/*
		 * Compute U
		 */
		v2.set(k.axis);
		v2.scale(s.radius/k.sinAngle);
		v1.sub(k.vertex, v2);
		
		/*
		 * Compute D
		 */
		v2.sub(s.center, v1);
		
		float dsqr = v2.dot(v2);
		float e = k.axis.dot(v2);
		
		if ( e > 0 && e*e >= dsqr*k.cosAngleSqr ) {
			// center is inside K''
			v2.sub(s.center, k.vertex);	// D
			dsqr = v2.dot(v2);
			e = -k.axis.dot(v2);
			if ( e > 0 && e*e >= dsqr*k.sinAngleSqr ) {
				if (dsqr <= s.radiusSqr) {
					// center is inside K'' and inside K'
					return INSIDE;
				} else
					return OUTSIDE;
			} else {
				// center is inside K'' and inside K'
				return INSIDE;
			}
		} else {
			// center is outside K'' and outside K'
			return OUTSIDE;
		}
	}

}
