/*
 * Created on Nov 21, 2004
 *
 */
package math;

import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;
import javax.vecmath.Vector4f;


/**
 * @author wdevore
 *
 */
public class Frustum {
	public static final int TOPPLANE = 0;
	public static final int BOTTOMPLANE = 1;
	public static final int LEFTPLANE = 2;
	public static final int RIGHTPLANE = 3;
	public static final int FARPLANE = 4;
	public static final int NEARPLANE = 5;

	public static final int INSIDE = 0;
	public static final int BORDERING = 1;
	public static final int OUTSIDE = 2;

	/*
	 * Frustum dimensions
	 */
	public float near;
	public float left;
	public float right;
	public float bottom;
	public float top;

	public float far;
	public float left_far;
	public float right_far;
	public float bottom_far;
	public float top_far;
	
	public float fov;
	public int width, height;
	
	/*
	 * Clipping planes
	 */
	private Plane[] clippingPlanes = new Plane[6];
	
	/*
	 * Local temp variables
	 */
	private Vector3f v1 = new Vector3f();
	private Vector3f v2 = new Vector3f();
	private Vector3f v3 = new Vector3f();
	private Vector4f v4 = new Vector4f();

	/*
	 * Distance computed from frustum check.
	 */
	private double distance = 0.0;

	/* *****************************************************
	 * Methods
	 * *****************************************************
	 */
	public Frustum() {
		for (int i = 0; i < 6; i++) {
			clippingPlanes[i] = new Plane();
		}
	}
	
	public void setPlaneEquation(int plane, float x, float y, float z, float d) {
		clippingPlanes[plane].setEquation(x, y, z, d);
	}

	public void setPlaneEquation(int plane, float nx, float ny, float nz, float dx, float dy, float dz) {
		clippingPlanes[plane].setNormal(nx, ny, nz);
		clippingPlanes[plane].setPoint(dx, dy, dz);
		clippingPlanes[plane].calcGeneralizedPlaneEquation();
	}

	/*
	 * The incoming matrix should be a matrix that represents the concatinated
	 * modelview and projection matrix from OpenGL.
	 */
	public void setPlaneEquations(Matrix4f combinedMatrix) {
		float t;
	   // Extract the numbers for the RIGHT plane
	   v4.set(
	   		combinedMatrix.m30 - combinedMatrix.m00,
	   		combinedMatrix.m31 - combinedMatrix.m01,
	   		combinedMatrix.m32 - combinedMatrix.m02,
			combinedMatrix.m33 - combinedMatrix.m03
	   		);
	   /*
	    * If you are wondering why I simply didn't normalize the vector it
	    * is because we are normalizing equations not vectors.
	    */
	   t = (float)Math.sqrt( v4.x * v4.x + v4.y * v4.y + v4.z * v4.z );
	   v4.scale(1/t);
	   setPlaneEquation(RIGHTPLANE, v4.x, v4.y, v4.z, v4.w);
	   
	   v4.set(
	   		combinedMatrix.m30 + combinedMatrix.m00,
			combinedMatrix.m31 + combinedMatrix.m01,
			combinedMatrix.m32 + combinedMatrix.m02,
			combinedMatrix.m33 + combinedMatrix.m03
	   		);
	   t = (float)Math.sqrt( v4.x * v4.x + v4.y * v4.y + v4.z * v4.z );
	   v4.scale(1/t);
	   setPlaneEquation(LEFTPLANE, v4.x, v4.y, v4.z, v4.w);

	   v4.set(
	   		combinedMatrix.m30 + combinedMatrix.m10,
			combinedMatrix.m31 + combinedMatrix.m11,
			combinedMatrix.m32 + combinedMatrix.m12,
			combinedMatrix.m33 + combinedMatrix.m13
	   		);
	   t = (float)Math.sqrt( v4.x * v4.x + v4.y * v4.y + v4.z * v4.z );
	   v4.scale(1/t);
	   setPlaneEquation(BOTTOMPLANE, v4.x, v4.y, v4.z, v4.w);

	   v4.set(
	   		combinedMatrix.m30 - combinedMatrix.m10,
			combinedMatrix.m31 - combinedMatrix.m11,
			combinedMatrix.m32 - combinedMatrix.m12,
			combinedMatrix.m33 - combinedMatrix.m13
	   		);
	   t = (float)Math.sqrt( v4.x * v4.x + v4.y * v4.y + v4.z * v4.z );
	   v4.scale(1/t);
	   setPlaneEquation(TOPPLANE, v4.x, v4.y, v4.z, v4.w);

	   v4.set(
	   		combinedMatrix.m30 - combinedMatrix.m20,
			combinedMatrix.m31 - combinedMatrix.m21,
			combinedMatrix.m32 - combinedMatrix.m22,
			combinedMatrix.m33 - combinedMatrix.m23
	   		);
	   t = (float)Math.sqrt( v4.x * v4.x + v4.y * v4.y + v4.z * v4.z );
	   v4.scale(1/t);
	   setPlaneEquation(FARPLANE, v4.x, v4.y, v4.z, v4.w);

	   v4.set(
	   		combinedMatrix.m30 + combinedMatrix.m20,
			combinedMatrix.m31 + combinedMatrix.m21,
			combinedMatrix.m32 + combinedMatrix.m22,
			combinedMatrix.m33 + combinedMatrix.m23
	   		);
	   t = (float)Math.sqrt( v4.x * v4.x + v4.y * v4.y + v4.z * v4.z );
	   v4.scale(1/t);
	   setPlaneEquation(NEARPLANE, v4.x, v4.y, v4.z, v4.w);

	}

	/*
	 * This version uses the math definition of the frustum to set the equations.
	 */
	public void setPlaneEquations() {
		// Set near and far clipping planes
		setPlaneEquation(NEARPLANE, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, -near);
		
		setPlaneEquation(FARPLANE, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, -far);
		
		/*
		 * Set left clipping plane.
		 * Form two vectors and take the cross product to get the plane
		 * normal.
		 */
		v1.set(left_far, top_far, -far);
		v2.set(left, top, -near);
		v1.sub(v2);
		v3.set(left, bottom, -near);
		v2.sub(v3);
		v3.cross(v1, v2);
		v3.normalize();
		setPlaneEquation(LEFTPLANE, v3.x, v3.y, v3.z, 0.0f, 0.0f, 0.0f);
		
		/*
		 * Set right clipping plane.
		 */
		v1.set(right_far, top_far, -far);
		v2.set(right, top, -near);
		v1.sub(v2);
		v3.set(right, bottom, -near);
		v2.sub(v3);
		v3.cross(v2, v1);
		v3.normalize();
		setPlaneEquation(RIGHTPLANE, v3.x, v3.y, v3.z, 0.0f, 0.0f, 0.0f);

		/*
		 * Set bottom clipping plane.
		 */
		v1.set(right, bottom, -near);
		v2.set(left, bottom, -near);
		v1.sub(v2);
		v3.set(left_far, bottom_far, -far);
		v2.sub(v3);
		v3.cross(v2, v1);
		v3.normalize();
		setPlaneEquation(BOTTOMPLANE, v3.x, v3.y, v3.z, 0.0f, 0.0f, 0.0f);

		/*
		 * Set top clipping plane.
		 */
		v1.set(right, top, -near);
		v2.set(left, top, -near);
		v1.sub(v2);
		v3.set(left_far, top_far, -far);
		v2.sub(v3);
		v3.cross(v1, v2);
		v3.normalize();
		setPlaneEquation(TOPPLANE, v3.x, v3.y, v3.z, 0.0f, 0.0f, 0.0f);

	}
	
	public double[] getPlaneEquation(int plane) {
		return clippingPlanes[plane].getGeneralizedPlane();
	}
	
	public Plane getPlane(int plane) {
		return clippingPlanes[plane];
	}
	public void setFrustum(float fov, int width, int height, float near, float far) {
		float aspectRatio;

		this.width = width;
		this.height = height;
		this.fov = fov;
		this.near = near;
		this.far = far;
		
		if (width > height) {
			aspectRatio = (float)width / (float)height;
		} else {
			aspectRatio = (float)height / (float)width;
		}
		
		this.top = (float)Math.tan( fov / 180 * Math.PI ) * near / 2;
		this.bottom = -this.top;
		this.right = this.top * aspectRatio;
		this.left = -this.right;

		top_far = (float)Math.tan( fov / 180 * Math.PI ) * far / 2;
		bottom_far = -top_far;
		right_far = top_far * aspectRatio;
		left_far = -right_far;

		setPlaneEquations();
		
	}

	public int pointInFrustum(Vector3f p) {
		for (int plane = 0; plane < 6; plane++) {
			Plane pl = getPlane(plane);
			if ( pl.whichHalfSpace(p) < 2 )
				return OUTSIDE;
		}
		return INSIDE;
	}

	/**
	 * @param s
	 * @return
	 * Sphere is:
	 * 0 = completely outside, 1 = bordering, 2 = completely inside
	 */
	public int sphereInFrustum(Sphere s) {
		double planeEq[];
		int c = 0;
		for (int plane = 0; plane < 6; plane++) {
			planeEq = getPlaneEquation(plane);
			// Get distance to current Plane.
			distance = planeEq[0] * s.center.x + planeEq[1] * s.center.y + planeEq[2] * s.center.z + planeEq[3];
			if ( distance <= -s.getRadius() )
				return OUTSIDE;
			if ( distance > s.getRadius())
				c++;
		}
		return (c == 6) ? INSIDE : BORDERING;
	}

	/*
	 * Is should be noted that a false positive can be generated by
	 * this method. If the box is spatially larger than the frustum
	 * then this method could return a result of "BORDERING" which may not
	 * be true. All it takes is for one plane to be completely on one
	 * side of the box which will then return a false positive.
	 * 
	 * To strengthen this test you would need to combine this method
	 * with another test. For example, sphere/frustum or cone/frustum etc.
	 * If this method returns "BORDERING" then use a secondary test as a
	 * double check.
	 * 
	 * The false positive will most likely occur when the frustum moves
	 * outside the octree and the box is spatially larger than the frustum.
	 * These conditions will increase the likely hood of false positives.
	 * Generally, though, the octree is spatially larger than
	 * the frustum.
	 */
	/**
	 * This tests if a Axis Aligned Box/ParallelPiped is in the frustum.
	 * This method can return a False-Positive.
	 * This is an intense test where the worst case is
	 * 8(corners)*6(planes) = 48 tests. And the best case is 8.
	 * You may want to preceed this method with a cursory check with spheres
	 * or cones.
	 * 
	 * @param c	Box object
	 * @return
	 * Plane is:
	 * 0 = completely outside, 1 = bordering, 2 = completely inside
	 */
	public int boxIntersectFrustum(Box c) {
		double planeEq[];

		/*
		 * distant is either positive or negative or zero.
		 * If it is positive then a point/corner is on the positive side of
		 * a plane that divides space in half.
		 */
		double distance = 0.0;

		/*
		 * c1 counts how many times a corner was on the positive side of a
		 * plane.
		 */
		int c1;
		
		/*
		 * c2 counts how many corners were found to be on the positive side
		 * of a plane. If all 8 corners were found to be on the positive side
		 * then the box is completely inside the frustum. If < 8 corners
		 * where found then it is partially inside or considered bordering
		 * the frustum.
		 */
		int c2 = 0;
		
//		System.out.println("--------------------------------------------------------------------------------");
		/*
		 * Each box corner is compare against all 6 planes.
		 * 
		 * A corner is found to be inside if it is on the positive side of all
		 * 6 planes. Only one corners needs to be on the positive side of one
		 * plane for the box to be considered bordering the frustum.
		 * 
		 * Each time a corner is found to be inside c1 is incremented.
		 */
		for (int plane = 0; plane < 6; plane++) {
			c1 = 0;
			planeEq = getPlaneEquation(plane);

			/*
			 * Check each corner against the current plane.
			 */
			distance = planeEq[0] * (c.center.x - c.halfSize.x) + planeEq[1] * (c.center.y - c.halfSize.y) + planeEq[2] * (c.center.z - c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;

			distance = planeEq[0] * (c.center.x + c.halfSize.x) + planeEq[1] * (c.center.y - c.halfSize.y) + planeEq[2] * (c.center.z - c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			distance = planeEq[0] * (c.center.x - c.halfSize.x) + planeEq[1] * (c.center.y + c.halfSize.y) + planeEq[2] * (c.center.z - c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			distance = planeEq[0] * (c.center.x + c.halfSize.x) + planeEq[1] * (c.center.y + c.halfSize.y) + planeEq[2] * (c.center.z - c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			distance = planeEq[0] * (c.center.x - c.halfSize.x) + planeEq[1] * (c.center.y - c.halfSize.y) + planeEq[2] * (c.center.z + c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			distance = planeEq[0] * (c.center.x + c.halfSize.x) + planeEq[1] * (c.center.y - c.halfSize.y) + planeEq[2] * (c.center.z + c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			distance = planeEq[0] * (c.center.x - c.halfSize.x) + planeEq[1] * (c.center.y + c.halfSize.y) + planeEq[2] * (c.center.z + c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			distance = planeEq[0] * (c.center.x + c.halfSize.x) + planeEq[1] * (c.center.y + c.halfSize.y) + planeEq[2] * (c.center.z + c.halfSize.z) + planeEq[3];
			if (distance > 0)
				c1++;
			
			/*
			 * If c1 is 0 then no corners where on the positive side of the
			 * current plane. Which means the box is outside of the frustum. No
			 * more tests need to be made. This is the best case scenario
			 * because only 8 tests were performed.
			 */
			if (c1 == 0)
				return OUTSIDE;
			
			/*
			 * if c1 is 8 then all 8 corners are on the positive side of the
			 * current plane. At this point we know that the box is bordering
			 * at a minimum.
			 */
			if (c1 == 8)
				c2++;
			
//			System.out.println("plane: [" +plane+"] "+"("+c1+","+c2+") "+planeEq[0]+","+planeEq[1]+","+planeEq[2]+","+planeEq[3]);
		}
		/*
		 * if c2 is 6 then all corners where inside the frustum otherwise some
		 * where inside and some where outside. 
		 */
		return (c2 == 6) ? INSIDE : BORDERING;
	}

}
