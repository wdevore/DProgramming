/*
 * Created on Mar 1, 2005
 *
 */
package math;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 * @author wdevore
 *
 */
public class Sphere {
	public static final int INTERSECTING = 1;
	public static final int NONINTERSECTING = 0;
	
	public float radius;
	public float radiusSqr;
	public Point3f center = new Point3f();

	/*
	 * Local temp variables
	 */
	private Vector3f v1 = new Vector3f();

	public void set(Sphere s) {
		center.set(s.center);
		setRadius(s.radius);
	}

	public void setRadius(float r) {
		radius = r;
		radiusSqr = radius*radius;
	}
	
	public float getRadius() {
		return radius;
	}
	
	public float getRadiusSquared() {
		return radiusSqr;
	}
	
	public int intersects(Sphere s) {
		/*
		 * Get seperating axis.
		 */
		v1.sub(center, s.center);
		
		/*
		 * Sum of the radii.
		 */
		float radiiSum = radius + s.radius;
		
		/*
		 * If the distance between the centers is less than the sum of 
		 * the radii, then we have an intersection.
		 * Use the squarelength for efficiency.
		 */
		if (v1.lengthSquared() < radiiSum*radiiSum) {
			return INTERSECTING;
		} else {
			return NONINTERSECTING;
		}
	}
}
