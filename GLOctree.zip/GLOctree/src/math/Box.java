/*
 * Created on Mar 2, 2005
 *
 */
package math;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import model.Heap;

/**
 * @author wdevore
 *
 */
public class Box {
	public static final int INSIDE = 0;
	public static final int OUTSIDE = 1;
	public static final int BORDERS = 2;

	public Point3f center = new Point3f();

	public Vector3f max = new Vector3f();
	public Vector3f min = new Vector3f();
	
	/*
	 * x = width
	 * y = height
	 * z = depth
	 */
	public Vector3f halfSize = new Vector3f();
	public Vector3f size = new Vector3f();
	
	public void set(Box b) {
		center.set(b.center);
		max.set(b.max);
		min.set(b.min);
		halfSize.set(b.halfSize);
		size.set(b.size);
	}
	
	public void setHalfSize(float w, float h, float d) {
		halfSize.set(w/2.0f, h/2.0f, d/2.0f);
	}
	
	public void setSize(float w, float h, float d) {
		size.set(w, h, d);
	}
	
	public void calcSize() {
		setSize(Math.abs(max.x - min.x), Math.abs(max.y - min.y), Math.abs(max.z - min.z));
	}

	public void calcSize(Vector3f min, Vector3f max) {
		this.max.set(max);
		this.min.set(min);
		setSize(Math.abs(max.x - min.x), Math.abs(max.y - min.y), Math.abs(max.z - min.z));
	}
	
	public void calcHalfSize() {
		setHalfSize(Math.abs(max.x - min.x), Math.abs(max.y - min.y), Math.abs(max.z - min.z));
	}
	
	public void calcHalfSize(Vector3f min, Vector3f max) {
		this.max.set(max);
		this.min.set(min);
		setHalfSize(Math.abs(max.x - min.x), Math.abs(max.y - min.y), Math.abs(max.z - min.z));
	}
	
	public void setCenter() {
		Heap.v1.add(max, min);
		Heap.v1.scale(0.5f);
		center.set(Heap.v1);
	}
	
	public void setCenter(Point3f p) {
		center.set(p);
	}
	
	public void setCenter(Vector3f v) {
		center.set(v);
	}

	public void setCenter(Vector3f min, Vector3f max) {
		Heap.v1.add(max, min);
		Heap.v1.scale(0.5f);
		center.set(Heap.v1);
	}

	public float getLongestSide() {
		float length = 0.0f;
		
		if (size.x >= size.y && size.x >= size.z)
			length = size.x;
		else if (size.y >= size.x && size.y >= size.z)
			length = size.y;
		else if (size.z >= size.x && size.z >= size.y)
			length = size.z;
		
		return length;
	}
	
	/*
	 * This returns either local or world coords. local if center has not been set
	 * by getWorldBox() and World coords otherwise.
	 */
	public Vector3f getCornerVertex(int i) {
		switch (i) {
		case 0:
			Heap.v1.set(center.x - halfSize.x, center.y + halfSize.y, center.z + halfSize.z);
			break;
		case 1:
			Heap.v1.set(center.x - halfSize.x, center.y + halfSize.y, center.z - halfSize.z);
			break;
		case 2:
			Heap.v1.set(center.x - halfSize.x, center.y - halfSize.y, center.z + halfSize.z);
			break;
		case 3:
			Heap.v1.set(center.x - halfSize.x, center.y - halfSize.y, center.z - halfSize.z);
			break;
		case 4:
			Heap.v1.set(center.x + halfSize.x, center.y + halfSize.y, center.z + halfSize.z);
			break;
		case 5:
			Heap.v1.set(center.x + halfSize.x, center.y + halfSize.y, center.z - halfSize.z);
			break;
		case 6:
			Heap.v1.set(center.x + halfSize.x, center.y - halfSize.y, center.z + halfSize.z);
			break;
		case 7:
			Heap.v1.set(center.x + halfSize.x, center.y - halfSize.y, center.z - halfSize.z);
			break;
		}
		return Heap.v1;
	}
	
	/**
	 * Is the given box inside this box?
	 * @param b box to test against.
	 * @return
	 */
	public int intersects(Box b) {
		/*
		 * This intersect test is for Axis-Aligned boxes (AABB)s only.
		 * The "this" object is labeled "A" and the incoming box is labeled "B".
		 * 
		 * NO intersect:
		 * To determine if boxes do not intersect we compare the max and mins of
		 * each box. If any test results in true then they do NOT intersect and
		 * the method exits immediately. An example as follows:
		 * if B.min.z > A.max.z then return OUTSIDE. There is 2 for each axis
		 * which gives a total of 6 tests.
		 * 
		 * Completely INSIDE intersect:
		 * Again the max and min corners of each box are compared and each
		 * comparison must be true. Example:
		 * B.min.x >= A.min.x AND B.min.y >= A.min.y AND etc...
		 * If they are all true then B is completely inside of A.  
		 */
		
		/*
		 * First test for a quick out of Non-intesection.
		 */
		if (min.x > b.max.x)
			return OUTSIDE;
		if (min.y > b.max.y)
			return OUTSIDE;
		if (min.z > b.max.z)
			return OUTSIDE;
		if (b.min.x > max.x)
			return OUTSIDE;
		if (b.min.y > max.y)
			return OUTSIDE;
		if (b.min.z > max.z)
			return OUTSIDE;
		
		/*
		 * Now check to see if one is inside the other. This requires all 6
		 * tests to be performed. Is the incoming box inside this box.
		 */
		if (
				b.min.x >= min.x &&
				b.min.y >= min.y &&
				b.min.z >= min.z &&
				b.max.x <= max.x &&
				b.max.y <= max.y &&
				b.max.z <= max.z
			)
			return INSIDE;
		
		/*
		 * The incoming box borders this box.
		 */
		return BORDERS;
	}
}
