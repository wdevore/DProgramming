/*
 * Created on Mar 10, 2005
 *
 */
package math;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 * @author wdevore
 *
 */
public class BoundingVolume {
	private Vector3f v1 = new Vector3f();
	private Point3f p1 = new Point3f();
	
	/*
	 * Bounding Box of object. 
	 */
	public Box bBox = new Box();

	/*
	 * Bounding sphere of object.
	 */
	public Sphere bSphere = new Sphere();

	public Box getBox() {
		return bBox;
	}
	
	public Sphere getSphere() {
		return bSphere;
	}

	public void clearMinMax() {
		bBox.min.set(0.0f, 0.0f, 0.0f);
		bBox.max.set(0.0f, 0.0f, 0.0f);
	}
	
	public void setMin(Vector3f v) {
		bBox.min.set(v);
	}

	public void setMax(Vector3f v) {
		bBox.max.set(v);
	}

	public void setSize(float w, float h, float d) {
		bBox.halfSize.set(w/2.0f, h/2.0f, d/2.0f);
	}

	public void calcSize() {
		setSize(Math.abs(bBox.max.x - bBox.min.x), Math.abs(bBox.max.y - bBox.min.y), Math.abs(bBox.max.z - bBox.min.z));
	}
	
	public void calcCenter() {
		p1.add(bBox.max, bBox.min);
		p1.scale(0.5f);
		bBox.setCenter(p1);
		// Set sphere as well.
		bSphere.center.set(p1);
	}
	
	public Point3f getCenter() {
		/*
		 * The box and sphere will have the same center for purposes of this
		 * prototype.
		 */
		return bBox.center;
	}
	
	public void calcRadius() {
		/*
		 * Bounding sphere.
		 * There are three ways to get a bounding sphere for the box:
		 * #1) create an inner sphere.
		 *    Find shortest side. This is Radius.
		 * #2) create a tight fitting sphere
		 *    Edge diagonal. Find longest side and find distance from center to
		 *    corner.
		 * #3) create a volume fitting sphere. Correct for bound testing.
		 *    Radius is 1/2 the volume diagonal. This will encompass the corners
		 *    as well.
		 */
		float r = 0.0f;
		v1.sub(bBox.max, bBox.min);

		/*
		 * Method #3
		 */
		r = v1.length()/2.0f;
		bSphere.setRadius(r);
	}
	
	public void setRadius(float l) {
		l /= 2.0f;
		l = (float)Math.sqrt(3.0f * l*l);
		bSphere.setRadius(l);
	}
}
