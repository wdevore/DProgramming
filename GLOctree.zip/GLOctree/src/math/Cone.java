/*
 * Created on Mar 11, 2005
 *
 */
package math;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 * @author wdevore
 *
 */
public class Cone {

	public Point3f vertex = new Point3f();
	public Vector3f axis = new Vector3f();
	public double angle = 0.0f;
	
	/*
	 * The distance from the vertex to the other end.
	 * Base of cone. The wide part or opening end.
	 */
	public Vector3f base = new Vector3f();
	
	/*
	 * Pre computed values.
	 */
	public float cosAngle;
	public float sinAngle;
	public float reciprocalSinAngle;
	public float cosAngleSqr;
	public float sinAngleSqr;
	
	public float baseRadius;
	
	public void set(Cone c) {
		vertex.set(c.vertex);
		axis.set(c.axis);
		angle = c.angle;
		cosAngle = c.cosAngle;
		sinAngle = c.sinAngle;
		cosAngleSqr = c.cosAngleSqr;
		sinAngleSqr = c.sinAngleSqr;
		reciprocalSinAngle = c.reciprocalSinAngle;
	}

	public void setVertex(float x, float y, float z) {
		vertex.set(x, y, z);
	}

	public void setAxis(float x, float y, float z) {
		axis.set(x, y, z);
	}
	
	public void setAngle(Vector3f v) {
		cosAngle = v.dot(axis);			// Dot(scalar product) returns Cos(theta)
		angle = Math.acos(cosAngle);	// theta In radians
		sinAngle = (float)Math.sin(angle);
		cosAngleSqr = cosAngle*cosAngle;
		sinAngleSqr = sinAngle*sinAngle;
		reciprocalSinAngle = 1.0f/sinAngle;
	}
	
	public void setBase(Vector3f v) {
		base.set(v);
	}
	
	public void setBaseRadius(float r) {
		baseRadius = r;
	}
}
