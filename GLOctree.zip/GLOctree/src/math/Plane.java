/*
 * Created on Dec 3, 2004
 *
 */
package math;

import geometry.objects.Object3D;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

/**
 * @author wdevore
 *
 */
public class Plane extends Object3D {
	private static float EPSILON = 0.0001f;

	private Vector3f normal = new Vector3f();

	private Vector3f point = new Vector3f();
	private Vector3f transformedPoint = new Vector3f();
	
	/*
	 * General plane equation variables
	 */
	private double[] equation = new double[4];
	/*
	 * Tracks the validity of the equation.
	 */
	private boolean isDirty = true;

	/* ****************************************************
	 * Rendering methods
	 */
	public Plane() {
	}
	
	
	/* ****************************************************
	 * Setter/Getters
	 */
	public void setNormal(float x, float y, float z) {
		isDirty = true;
		normal.set(x, y, z);
		normal.normalize();
	}
	
	public void setPoint(float x, float y, float z) {
		isDirty = true;
		point.set(x, y, z);
	}

	public void setEquation(float x, float y, float z, float d) {
		isDirty = false;
		equation[0] = x;
		equation[1] = y;
		equation[2] = z;
		equation[3] = d;
	}
	public void setPoint(Vector3f v) {
		isDirty = true;
		point.set(v.x, v.y, v.z);
	}

	public void setPoint(Point3f p) {
		isDirty = true;
		point.set(p);
	}

	/* ****************************************************
	 * Math methods
	 */
	
	/**
	 * Determine if point is in front of plane or on the back side.
	 * @param v
	 * @return
	 * <ul>
	 * <li>0 = coplanar, neither front or back</li>
	 * <li>1 = back side</li>
	 * <li>2 = front side</li>
	 * </ul>
	 */
	public int whichHalfSpace(Vector3f p) {
		double distance = equation[0] * p.x + equation[1] * p.y + equation[2] * p.z + equation[3];
		if (Math.abs(distance) < EPSILON) {
			// it is coplanar
			return 0;
		}
		if (distance < 0.0f)
			return 1; // backside
		return 2; // frontside
	}
	
	/**
	 * Computes the generalized plane equation using the plane Normal and
	 * position.
	 * @return
	 */
	public double[] getGeneralizedPlane() {
		if (isDirty) {
			calcGeneralizedPlaneEquation();
			isDirty = false;
		}
		
		return equation;
	}
	
	public void calcGeneralizedPlaneEquation() {
		equation[0] = normal.x;
		equation[1] = normal.y;
		equation[2] = normal.z;

		// Calc D = -p dot Normal
		transformedPoint.set(point);
		transformedPoint.negate();
		double dot = transformedPoint.dot(normal);
		equation[3] = dot;
	}
}
