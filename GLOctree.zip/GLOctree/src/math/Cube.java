/*
 * Created on Mar 2, 2005
 *
 */
package math;

import javax.vecmath.Vector3f;

/**
 * @author wdevore
 *
 */
public class Cube extends Box {

	/*
	 * 1/2 the distance from side to side
	 */
	public void setHalfSize(float r) {
		halfSize.set(r, r, r);
		halfSize.scale(0.5f);
	}
	
	public void setSize(float l) {
		halfSize.set(l/2.0f,l/2.0f,l/2.0f);
		size.set(l, l, l);
	}
	public float getHalfSize() {
		return halfSize.x;	// it doesn't matter with component.
	}
	
	public void setCenter(Vector3f v) {
		center.set(v);
	}
	
}
