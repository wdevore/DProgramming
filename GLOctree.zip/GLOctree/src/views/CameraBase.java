/*
 * Created on Feb 3, 2005
 *
 */
package views;

import geometry.objects.FrustumObject;
import input.Mouse;

import java.awt.Dimension;

import javax.media.opengl.GL;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;

import math.Frustum;

/**
 * @author wdevore
 *
 */
public abstract class CameraBase implements ICamera {
	protected Matrix3f rotation = null;
	protected Matrix4f translation = null;

	protected Matrix4f transform = null;
	protected Matrix4f inverseTransform = null;

	protected float[] transformArray = null;
	protected float[] inverseTransformArray = null;

	protected Vector3f v1 = new Vector3f();
	protected Vector3f v2 = new Vector3f();
	protected Vector3f v3 = new Vector3f();

	/*
	 * For the Orbit style this var is the distance along the LOS which
	 * is the -z-axis. The default is something chosen for average result..
	 */
	protected float distance = 0.0f;

	/*
	 * This is what the camera is looking at in world-space coords.
	 */
	protected Vector3f center = new Vector3f();
	
	/*
	 * Optimization flag.
	 * Has the camera been modified since the last calculation.
	 */
	protected boolean isDirty = true;
	
	/*
	 * The base of the camera. This is where the camera is located in
	 * world-space.
	 */
	private Vector3f position3f = new Vector3f();
	
	/*
	 * World frustum.
	 */
	public FrustumObject frustum;

	String name;
	
	/*
	 * Field of view
	 */
	public float fov = 45.0f;
	
	/*
	 * Near and far
	 */
	public float near = 10.0f;
	public float far = 1000.0f;
	
	public CameraBase(String name) {
		this.name = name;
		frustum = new FrustumObject(this, "Frustum");
	}
	
	public void lookAt(Vector3f Eye, Vector3f Center, Vector3f Up) {
		System.err.println("implement CameraAdapter::lookAt");
	}

	public void lookAt(Vector3f Eye, Vector3f Center) {
		System.err.println("implement CameraAdapter::lookAt");
	}

	public void lookAt(Vector3f Center) {
		System.err.println("implement CameraAdapter::lookAt");
	}

	public void slideUpDown(float increment) {
		System.err.println("implement CameraAdapter::slideUpDown");
	}

	public void slideLeftRight(float increment) {
		System.err.println("implement CameraAdapter::slideLeftRight");
	}

	public void dolly(float increment) {
		System.err.println("implement CameraAdapter::dolly");
	}

	public Vector3f getTarget() {
		System.err.println("implement CameraAdapter::getTarget");
		return null;
	}

	public Vector3f getPosition() {
		return position3f;
	}
	public void setPosition(Vector3f v) {
		position3f.set(v);
	}
	
	public Frustum getFrustum() {
		return frustum.getFrustum();
	}
	
	public void setFrustum(float fov, int width, int height, float near, float far) {
		getFrustum().setFrustum(fov, width, height, near, far);
	}
	
	public FrustumObject getFrustumObject() {
		return frustum;
	}

	public float[] getRotationArray() {
		System.err.println("implement CameraAdapter::getRotationArray");
		return null;
	}

	public float[] getInverseRotationArray() {
		System.err.println("implement CameraAdapter::getInverseRotationArray");
		return null;
	}

	public float[] getTransformArray() {
		System.err.println("implement CameraAdapter::getTransformArray");
		return null;
	}
	public Matrix4f getTransformMatrix() {
		System.err.println("implement CameraAdapter::getTransformMatrix");
		return null;
	}

	public float[] getInverseTransformArray() {
		System.err.println("implement CameraAdapter::getInverseTransformArray");
		return null;
	}

	public Matrix4f getInverseTransformMatrix() {
		System.err.println("implement CameraAdapter::getInverseTransformMatrix");
		return null;
	}
	
	public void render(GL gl) {}
	public void resize(Dimension d) {}
	public void mouseDown(Mouse m) {}
	public void mouseUp(Mouse m) {}
}
