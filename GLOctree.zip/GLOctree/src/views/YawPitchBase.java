/*
 * Created on Feb 3, 2005
 *
 */
package views;

import input.Mouse;

import java.awt.Dimension;

import javax.media.opengl.GL;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3i;
import javax.vecmath.Vector3f;

import math.VectorAlgebra;

/**
 * @author wdevore
 *
 */
public abstract class YawPitchBase extends CameraBase {
	protected Matrix3f orientation = new Matrix3f();
	protected Matrix3f orientationInverse = new Matrix3f();

	private Point3i pCanvasSize = new Point3i();

	protected boolean bMouseFlip = false;

	/* 
	 * The last direction the mouse was heading
	 */
	public Point3i ptLastMouseDirection;
	
	/*
	 * This is used for mouse acceleration. The bigger the delta the more
	 * the mouse acceleration.
	 * The acceleration is generated from a exponetial for loop.
	 */
	private Point3i ptMouseDelta = new Point3i();

	/*
	 * This array holds values that change using and exponential function.
	 * It is meant to provide values based on how much the mouse has moved.
	 * Small mouse moves create small mouse reactions. Medium moves cause
	 * large reactions and large moves cause extremely large reactions. This
	 * allows fine control when the mouse is move a little and macro control
	 * when the mouse is moved alot.
	 */
	private float[] dsSteps = new float[15];
	
	/*
	 * Pitch and Yaw are used for the look at function and represent
	 * the current yaw and pitch of the camera.
	 */
	private double dPitch = 0.0;
	private double dYaw = 0.0;

	private Matrix3f pitchRotation = new Matrix3f();
	private Matrix3f yawRotation = new Matrix3f();

	protected AxisAngle4f aa = new AxisAngle4f();
	
	public YawPitchBase(String name) {
		super(name);
		
		ptLastMouseDirection = new Point3i();
		
		for (int i = 0; i < 15; i++) {
			dsSteps[i] = (float) ((Math.pow(1.1, (double) i) - 1.0) * Math.pow(
					1.1, (double) i));
		}
		dsSteps[0] = 0.0f;
		
		clearMouse();
	}

	public void resize(Dimension rec) {
		pCanvasSize.x = rec.width;
		pCanvasSize.y = rec.height;
	}

	/*
	 * This method is used for the lookAt function. Something that must be
	 * recognized is that the orientation matrix represents a rotation that
	 * is designed to be applied to the world NOT the camera. Remember the
	 * camera is always fixed at the origin looking down the -z axis.
	 * 
	 * Hence, to get the camera's position in the world and NOT sitting at the
	 * origin looking down the -z axis we need to apply the inverse
	 * (aka transpose) of the orientation matrix and this is why I keep a
	 * second matrix called orientationTranspose. This matrix represents the
	 * camera in world-space and NOT view-space.
	 * 
	 * You can think of view-space as everything that has been transformed in
	 * such a manner that it is now potentially visible by the camera. Of course
	 * the transform may have placed things that are not visible but it is still
	 * considered in view-space, perhaps visible though.
	 * 
	 * world-space is used for doing things like clipping, culling etc... And
	 * the camera needs to be in that space for things to work correctly. For
	 * example, if I want to translate the camera along the camera's plane I
	 * need to do that with the camera in world-space not view-space. If I
	 * performed the translation in view-space then the camera would always
	 * appear to translate in the world xy plane.
	 * 
	 * Another way to distinguish the two spaces is to realize that
	 * view-space is necessary for projection purposes and world-space in
	 * necessary for everything else.
	 */
	private void calcOrientation() {
		orientation.setIdentity();
	
		/*
		 * There are two ways the matrix can be formed and it depends on if you
		 * want to call negate/transpose or not.
		 */
		// Approach #1
		yawRotation.rotY((float)-dYaw);
		pitchRotation.rotX((float)-dPitch);
		orientation.mul(pitchRotation, yawRotation);

		// Approach #2. Remember to call negate/transpose on the matrix
//		yawRotation.rotY((float)dYaw);
//		pitchRotation.rotX((float)dPitch);
//		orientation.mul(yawRotation, pitchRotation);
//		orientation.negate();

		orientationInverse.set(orientation);
		orientationInverse.transpose();
		
	}

	private void calcYawPitch() {
		/*
		 * Calculate Yaw
		 */
		v1.sub(center, getPosition()); 
		v1.normalize();	// [dir]

		v2.set(v1);
		v2.y = 0.0f;	// [dir] projected onto xz plane
		v2.normalize();	// P

		v3.set(0.0f, 0.0f, -1.0f); // -z axis
		float dot = v2.dot(v3);

		/*
		 * This is the angle between P and -z axis
		 */
		dYaw = Math.acos(dot);

		/*
		 * Determine CW or CCW rotation on +y axis.
		 * does P point to the negative half space of the yz plane
		 * or positive half. If P.x < 0 then it is pointing towards
		 * the negative half space. Hence a positive rotation is required to
		 * rotate the -z axis vector into alignment with P vector. That means
		 * a positive rotation will make the -z axis co-align with the
		 * P vector. 
		 */
		if (v2.x > 0)
			dYaw = -dYaw; // CW rotation needed

		/*
		 * Now determine Pitch about the +x axis. This is determined by getting
		 * the angle between the +y axis and [dir] and subtracting 90 degrees.
		 * This is the same as finding the angle between the [dir] vector and
		 * the xz plane. We could have use code that finds the angle between
		 * a vector and a plane.
		 */
		v3.set(0.0f, 1.0f, 0.0f); // +y axis
		dot = v1.dot(v3);
		dPitch = Math.acos(dot);
		dPitch = (Math.toRadians(90.0) - dPitch);
		
		calcOrientation();
	}

	/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 * Mouse methods
	 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 */
	/*
	 * This method calcs a new orientation based on the updated yaw and pitch
	 * vars. Note: this is an Orbit implementation. 
	 */
	private void calcMouseOrientation() {
		float fStep = 0.0f;

		if (ptLastMouseDirection.y != 0) {
			int iDirection = (ptLastMouseDirection.y > 0) ? -1 : 1;
			if (ptMouseDelta.y > 14)
				fStep = dsSteps[14];
			else
				fStep = dsSteps[ptMouseDelta.y];
			dPitch += Math.toRadians(fStep) * (float)iDirection;
		}
		
		if (ptLastMouseDirection.x != 0) {
			int iDirection = (ptLastMouseDirection.x > 0) ? -1 : 1;
			if (ptMouseDelta.x > 14)
				fStep = dsSteps[14];
			else
				fStep = dsSteps[ptMouseDelta.x];
			dYaw += Math.toRadians(fStep) * (float)iDirection;
		}
		ptMouseDelta.set(0, 0, 0);
		ptLastMouseDirection.set(0, 0, 0);

		calcOrientation();

		isDirty = true;
	}

	public float getDistance() {
		return distance;
	}
	
	public float calcDistance() {
		v1.sub(getPosition(), center);
		distance = v1.length();
		return distance;
	}
	public float calcDistance(Vector3f v) {
		distance = v.length();
		return distance;
	}


	public void clearMouse() {
		ptLastMouseDirection.set(0, 0, 0);
		ptMouseDelta.set(0, 0, 0);
	}

	public void updateMouse(Mouse m) {
		int deltaX = m.deltaX();
		int deltaY = m.deltaY();
		
		// The Y axis is flipped. Hence we scale by -1.0f
		ptLastMouseDirection.set(deltaX, -deltaY, 0);

		if (ptLastMouseDirection.x > 0)
			ptLastMouseDirection.x = 1;
		else if (ptLastMouseDirection.x < 0)
			ptLastMouseDirection.x = -1;
		else
			ptLastMouseDirection.x = 0;

		if (ptLastMouseDirection.y > 0)
			ptLastMouseDirection.y = -1;
		else if (ptLastMouseDirection.y < 0)
			ptLastMouseDirection.y = 1;
		else
			ptLastMouseDirection.y = 0;

		if (bMouseFlip == true)
			ptLastMouseDirection.y *= -1;

		ptMouseDelta.set(Math.abs(deltaX), Math.abs(deltaY), 0);
		isDirty = true;
	}
	
	/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 * Vector Basis methods
	 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 */
	public Vector3f getLOS() {
		/*
		 * Get LOS based on the new orientation of camera.
		 */
		v1.set(0.0f, 0.0f, -1.0f);
		
		/*
		 * Rotate LOS to new orientation.
		 */
		orientationInverse.transform(v1, v2);
		
		v2.normalize();
		
		return v2;
	}

	public Vector3f getUp() {
		/*
		 * Get Up vector based on the new orientation of camera.
		 */
		v1.set(0.0f, 1.0f, 0.0f);
		
		/*
		 * Rotate Up to new orientation.
		 */
		orientationInverse.transform(v1, v2);

		v2.normalize();
		
		return v2;
	}

	public Vector3f getSide() {
		/*
		 * Get Side vector based on the new orientation of camera.
		 */
		v1.set(1.0f, 0.0f, 0.0f);
		
		/*
		 * Rotate Side to new orientation.
		 */
		orientationInverse.transform(v1, v2);

		v2.normalize();
		
		return v2;
	}

	public Vector3f getTarget() {
		return center;
	}

	protected Matrix3f getNewOrientation() {
		calcMouseOrientation();
		return orientation;
	}

	public void slideUpDown(float increment) {
		v1.set(getUp());
		v1.scale(increment);
		isDirty = true;
	}
	public void slideLeftRight(float increment) {
		v1.set(getSide());
		v1.scale(increment);
		isDirty = true;
	}

	public void lookAt(Vector3f Eye, Vector3f Center, Vector3f Up) {
		center.set(Center);
		setPosition(Eye);
		calcDistance();
		// this.up.set(Up); ignored for now. it is always +y axis
		calcYawPitch();
		isDirty = true;
	}
	public void lookAt(Vector3f Eye, Vector3f Center) {
		center.set(Center);
		setPosition(Eye);
		calcDistance();
		calcYawPitch();
		isDirty = true;
	}
	public void lookAt(Vector3f Center) {
		center.set(Center);
		calcDistance();
		calcYawPitch();
		isDirty = true;
	}

	/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 * Abstract methods
	 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 */
	/*
	 * Dolly is different for Orbit and Pan style.
	 * 
	 * Orbit's distance from a subject is based on a position along the
	 * z-axis. But to understand this we must understand what the
	 * orientation represents. Please see docs for the orientation
	 * variable for further explanation.
	 */
	public abstract void dolly(float increment);
	public abstract void placeCameraUsingGL(GL gl);
	public abstract Matrix4f getTransformMatrix();

	public float[] getInverseTransformArray() {
		if (inverseTransform == null) {
			inverseTransform = new Matrix4f();
		}
		if (inverseTransformArray == null) {
			inverseTransformArray = new float[16];
		}

		inverseTransform.setIdentity();
		inverseTransform.set(getTransformMatrix());
		inverseTransform.invert();
		VectorAlgebra.matrixToArray(inverseTransform, inverseTransformArray);
		
		return inverseTransformArray;
	}

	public float[] getTransformArray() {
		if (!isDirty) {
			return transformArray;
		}

		getTransformMatrix();
		
		/*
		 * A much faster transfer.
		 */
		VectorAlgebra.matrixToArray(transform, transformArray);
		
		return transformArray;
	}

	/*
	 * YawPitch doesn't have a 2D representation.
	 */
	public void render2D(GL gl) {}

}
