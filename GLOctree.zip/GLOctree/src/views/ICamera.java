/*
 * Created on Feb 1, 2005
 *
 */
package views;

import geometry.objects.FrustumObject;
import input.Mouse;

import java.awt.Dimension;

import javax.media.opengl.GL;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;

import math.Frustum;

/**
 * @author wdevore
 *
 */
public interface ICamera {
	
	public void lookAt(Vector3f Eye, Vector3f Center, Vector3f Up);
	public void lookAt(Vector3f Eye, Vector3f Center);
	public void lookAt(Vector3f Center);

	public void slideUpDown(float increment);
	public void slideLeftRight(float increment);
	public void dolly(float increment);

	public Vector3f getTarget();

	public float getDistance();
	public float calcDistance();

	public FrustumObject getFrustumObject();
	public Frustum getFrustum();
	public void setFrustum(float fov, int width, int height, float near, float far);
	
	public float[] getRotationArray();	
	public float[] getInverseRotationArray();	

	public Vector3f getPosition();
	
	public float[] getTransformArray();
	public Matrix4f getTransformMatrix();
	public float[] getInverseTransformArray();
	public Matrix4f getInverseTransformMatrix();
	
	public void placeCameraUsingGL(GL gl);
	
	public void updateMouse(Mouse m);
	public void mouseDown(Mouse m);
	public void mouseUp(Mouse m);
	public void clearMouse();
	public void resize(Dimension d);
	
	public void render(GL gl);
	public void render2D(GL gl);
	
}
