/*
 * Created on Feb 3, 2005
 *
 */
package views;

import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3f;

/**
 * @author wdevore
 *
 */
public class ArcballOrbit extends ArcballBase {
	private final static int LG_NSEGS = 4;
	private final static int NSEGS = 1<<LG_NSEGS;
	
	private Vector3f pts[] = new Vector3f[NSEGS + 1];

	/*
	 * Establish reasonable initial values for controller.
	 */
	public ArcballOrbit(String name) {
		super(name);

		for (int i = 0; i < NSEGS + 1; i++) {
			// Fill array with vectors.
			pts[i] = new Vector3f();
		}

	}

	public void dolly(float increment) {
		distance -= increment;
		isDirty = true;
	}

	public void slideUpDown(float increment) {
		super.slideUpDown(increment);
		center.add(v1);
	}
	public void slideLeftRight(float increment) {
		super.slideLeftRight(increment);
		center.add(v1);
	}

	public Matrix4f getTransformMatrix() {
		if (!isDirty) {
			return transform;
		}

		if (translation == null) {
			translation = new Matrix4f();
		}
		if (rotation == null) {
			rotation = new Matrix3f();
		}
		if (transform == null) {
			transform = new Matrix4f();
		}
		if (transformArray == null) {
			transformArray = new float[16];
		}

		translation.setIdentity();
		rotation.setIdentity();
		transform.setIdentity();
		
		/*
		 * This translation, done BEFORE the camera, is the distance we orbit
		 * from the point of interest.
		 */
		v1.set(0.0f, 0.0f, -getDistance());

		// translate
		//translation.setTranslation(v1);
		// Or
		transform.setTranslation(v1);
		
		// rotate
		rotation.set(getNewOrientation());
		
		/*
		 * If I wanted to control the order of the multiplications then I would
		 * use the mul() method with two matrices. Of course both matrices
		 * would need to be of the same rank. For example 3x3 or 4x4.
		 */
		//transform.mul(translation, rotation);	// better control
		// Or
		transform.setRotation(rotation);

		/*
		 * The Target is the point of interest.
		 * Adjust the camera position based on selected object
		 * here. This translation is where the camera will orbit about.
		 * We always want the camera to orbit the point of interest.
		 */
		// translate
		v1.set(getTarget());
		v1.negate();
		translation.setTranslation(v1);

		transform.mul(translation);

		isDirty = false;

		return transform;
		
	}

}
