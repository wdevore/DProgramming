/*
 * Created on Feb 3, 2005
 *
 */
package views;

import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;

/**
 * @author wdevore
 *
 */
/*
 * Pan style requires a translate and then a rotate.
 * For OpenGL this means you perform a glRotatef first followed
 * by a glTranslatef because of the stack nature of OpenGL.
 * 
 * Example:
 * gl.glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
 * gl.glTranslatef(-200.0f, -200.0f, -200.0f);
 * 
 */
public class ArcballPan extends ArcballBase {
	
	/**
	 * @param name
	 */
	public ArcballPan(String name) {
		super(name);
	}
	
	public void dolly(float increment) {
		v1.set(getLOS());

		if (increment < 0.0f) {
			v1.negate();
		}
		
		/*
		 * Now we scale it and add it to the Eye
		 */
		v1.scale(Math.abs(increment));
		
		v2.set(getPosition());
		v2.add(v1);
		setPosition(v2);
		isDirty = true;
	}

	public void slideUpDown(float increment) {
		super.slideUpDown(increment);
		v2.set(getPosition());
		v2.add(v1);
		setPosition(v2);
	}
	public void slideLeftRight(float increment) {
		super.slideLeftRight(increment);
		v2.set(getPosition());
		v2.add(v1);
		setPosition(v2);
	}

	public Matrix4f getTransformMatrix() {
		if (!isDirty) {
			return transform;
		}
		if (translation == null) {
			translation = new Matrix4f();
		}
		if (rotation == null) {
			rotation = new Matrix3f();
		}
		if (transform == null) {
			transform = new Matrix4f();
		}
		if (transformArray == null) {
			transformArray = new float[16];
		}

		translation.setIdentity();
		rotation.setIdentity();
		transform.setIdentity();
		
		// rotate
		rotation.set(getNewOrientation());
		
		/*
		 * If I wanted to control the order of the multiplications then I would
		 * use the mul() method with two matrices. Of course both matrices
		 * would need to be of the same rank. For example 3x3 or 4x4.
		 */
		//transform.mul(translation, rotation);	// better control
		// Or
		transform.setRotation(rotation);

		/*
		 * The Target is the point of interest.
		 * Adjust the camera position based on selected object
		 * here. This translation is where the camera will orbit about.
		 * We always want the camera to orbit the point of interest.
		 */
		// translate
		v1.set(getPosition());
		v1.negate();
		translation.setTranslation(v1);
		
		transform.mul(translation);
		
		isDirty = false;

		return transform;
	}

}
