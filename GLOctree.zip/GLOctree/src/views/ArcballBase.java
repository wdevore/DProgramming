/*
 * Created on Feb 3, 2005
 *
 */
package views;

import geometry.objects.MultiColorLinesObject;
import input.Mouse;

import java.awt.Dimension;

import javax.media.opengl.GL;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3i;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3f;

import math.VectorAlgebra;

/**
 * @author wdevore
 *
 */
public abstract class ArcballBase extends CameraBase {
	//private final float EPSILON = .0001f;

	private Point3i pCanvasSize = new Point3i();
	private Vector3f vCanvasCenter = new Vector3f();
	private float fRadius;
	private Vector3f vNow = new Vector3f();
	private Vector3f vBallMouse = new Vector3f();
	private boolean bDragging;
	
	private Vector3f vDown = new Vector3f();
	private Vector3f vFrom = new Vector3f();
	private Vector3f vTo = new Vector3f();
	//private Vector3f vrFrom = new Vector3f();
	//private Vector3f vrTo = new Vector3f();
	
	private Vector3f vLos = new Vector3f();

	private Quat4f qNow = new Quat4f();
	private Quat4f qDown = new Quat4f();
	private Quat4f qDrag = new Quat4f();
	private Quat4f qConj = new Quat4f();


	private Quat4f orientation = new Quat4f();
	protected Quat4f orientationInverse = new Quat4f();


	//private boolean twistCorrection = false;

	private Matrix3f rot1 = new Matrix3f();
	//private Matrix3f rot2 = new Matrix3f();
	//private Matrix3f rot3 = new Matrix3f();
	//private Quat4f q1 = new Quat4f();
	//private Quat4f q2 = new Quat4f();
	//private Quat4f q3 = new Quat4f();
	
	private MultiColorLinesObject circle;

	//private boolean renderable = true;
	
	public ArcballBase(String name) {
		super(name);

		fRadius = 0.0f;
		vCanvasCenter.set(0.0f, 0.0f, 0.0f);
		vDown.set(0.0f, 0.0f, 0.0f);
		vNow.set(0.0f, 0.0f, 0.0f);
		qDown.set(0.0f, 0.0f, 0.0f, 1.0f);
		qNow.set(0.0f, 0.0f, 0.0f, 1.0f);

		buildMesh();
	}
	
	/**
	 * Using vDown, vNow, dragging, and compute rotation etc.
	 *
	 */
	public void update() {
		
		vTo.set(mouseOnSphere(vNow));
		
		if (bDragging) {
			qDrag = mapFromBallPoints(vFrom, vTo);
			qNow.mul(qDrag, qDown);
		}
		//mapToBallPoints(qDown, vrFrom, vrTo);
		
		orientation.set(qNow);
		
	}
	

	public void placeCameraUsingGL(GL gl) {
		// TODO Auto-generated method stub

	}
	
	@SuppressWarnings("unused")
	private void computeLOS() {
		qConj.set(qNow);
		qConj.conjugate();
		orientation.set(0.0f, 0.0f, -1.0f, 0.0f);	// -Z
		orientation.mul(qConj, orientation);
		orientation.mul(qNow);
		vLos.set(orientation.x, orientation.y, orientation.z);	// the camera's los
		vLos.normalize();
	}

	public float calcDistance() {
		v1.sub(getPosition(), center);
		distance = v1.length();
		return distance;
	}
	
	public void clearMouse() {
		// TODO Auto-generated method stub

	}

	public float getDistance() {
		return distance;
	}
	
	public Vector3f getTarget() {
		return center;
	}

	public void updateMouse(Mouse m) {
		mouse(m);
		update();
		isDirty = true;
	}

	public void resize(Dimension rec) {
		pCanvasSize.x = rec.width;
		pCanvasSize.y = rec.height;
		vCanvasCenter.x = pCanvasSize.x / 2.0f;
		vCanvasCenter.y = pCanvasSize.y / 2.0f;
		// 2.5f gives a decent size ball. 2.0f would give little room on the sides.
		fRadius = Math.min(pCanvasSize.x, pCanvasSize.y)/2.5f;
	}
	
	/**
	 * Ken's arcball must be based on 2D screen coords where the +y is upwards respectively.
	 * However, SWT 2D screen coords are such that +y is downward.
	 * In order to sync with Ken's arcball I flip the screen coords to match Ken's
	 * y = (Height - y).
	 * Also, a conjugate is needed as well as a (-y).
	 */
	protected void remapScreenCoords(int x, int y) {
		vNow.set(x, pCanvasSize.y - y, 0.0f);
	}
	
	/** 
	 * Set the center and size of the controller.
	 * @param v
	 * @param r
	 */
	public void place(Vector3f v, float r) {
		vCanvasCenter.set(v);
		fRadius = r;
	}

	/**
	 * Incorporate new mouse position.
	 * @param v
	 */
	public void mouse(Mouse m) {
		remapScreenCoords(m.currentPoint.x, m.currentPoint.y);
	}

	public void mouseDown(Mouse m) {
		beginDrag(m.currentPoint.x, m.currentPoint.y);
	}

	public void mouseUp(Mouse m) {
		endDrag(m.currentPoint.x, m.currentPoint.y);
	}
	
	/**
	 * Convert window coordinates to sphere coordinates.
	 * @param vMouse
	 * @return
	 */
	protected Vector3f mouseOnSphere(Vector3f vMouse) {
		vBallMouse.x = (vMouse.x - vCanvasCenter.x) / fRadius;
		vBallMouse.y = (vMouse.y - vCanvasCenter.y) / fRadius;
		vBallMouse.z = 0.0f;
		float mag = vBallMouse.lengthSquared();
		if (mag > 1.0) {
			float scale = 1.0f / (float)Math.sqrt(mag);
			vBallMouse.scale(scale);
		} else {
			vBallMouse.z = (float)Math.sqrt(1.0f - mag);
		}
		return vBallMouse;
	}
	
	/**
	 * Convert a unit quaternion to two points on unit sphere.
	 * @param q
	 * @param vArcFrom
	 * @param vArcTo
	 */
	protected void mapToBallPoints(Quat4f q, Vector3f vArcFrom, Vector3f vArcTo) {
		float s = (float)Math.sqrt(q.x * q.x + q.y * q.y);
		if (s == 0.0f) {
			vArcFrom.set(0.0f, 1.0f, 0.0f);
		} else {
			vArcFrom.set(-q.y / s, q.x / s, 0.0f);
		}
		vArcTo.x = q.w * vArcFrom.x - q.z * vArcFrom.y;
		vArcTo.y = q.w * vArcFrom.y + q.z * vArcFrom.x;
		vArcTo.z = q.x * vArcFrom.y - q.y * vArcFrom.x;
		if (q.w < 0.0)
			vArcFrom.set(-vArcFrom.x, -vArcFrom.y, 0.0f);
	}
	
	/**
	 * Begin drag sequence
	 *
	 */
	public void beginDrag(int sx, int sy) {
		bDragging = true;
		remapScreenCoords(sx, sy);
		vDown.set(vNow);
		vFrom.set(mouseOnSphere(vDown));
	}
	
	/**
	 * Stop drag sequence.
	 *
	 */
	public void endDrag(int sx, int sy) {
		bDragging = false;
		remapScreenCoords(sx, sy);
		qDown.set(qNow);
	}
	
	/**
	 * Construct a unit quaternion from two points on unit sphere.
	 * @param vFrom
	 * @param vTo
	 * @return
	 */
	private Quat4f mapFromBallPoints(Vector3f vFrom, Vector3f vTo) {
		v1.cross(vFrom, vTo);
		orientation.set(v1.x, v1.y, v1.z, vFrom.dot(vTo));
		return (orientation);
	}
	
	public void lookInDirection(Vector3f vDir) {
		rot1.set(VectorAlgebra.yawPitchLookAt(vDir));
		qNow.set(rot1);
		qNow.normalize();
		orientation.set(qNow);
		qDown.set(qNow);
	}

	public void lookAt(Vector3f Eye, Vector3f Center, Vector3f Up) {
		center.set(Center);
		setPosition(Eye);
		calcDistance();
		v1.sub(Center, Eye);
		lookInDirection(v1);
		// this.up.set(Up); ignored for now. it is always +y axis
		isDirty = true;
	}
	public void lookAt(Vector3f Eye, Vector3f Center) {
		center.set(Center);
		setPosition(Eye);
		calcDistance();
		v1.sub(Center, Eye);
		lookInDirection(v1);
		isDirty = true;
	}
	public void lookAt(Vector3f Center) {
		center.set(Center);
		calcDistance();
		v1.sub(Center, getPosition());
		lookInDirection(v1);
		isDirty = true;
	}

	public abstract Matrix4f getTransformMatrix();

	public float[] getTransformArray() {
		if (!isDirty) {
			return transformArray;
		}

		getTransformMatrix();
		
		/*
		 * A much faster transfer.
		 */
		VectorAlgebra.matrixToArray(transform, transformArray);
		
		return transformArray;
	}

	public float[] getInverseTransformArray() {
		if (inverseTransform == null) {
			inverseTransform = new Matrix4f();
		}
		if (inverseTransformArray == null) {
			inverseTransformArray = new float[16];
		}

		inverseTransform.setIdentity();
		inverseTransform.set(getTransformMatrix());
		inverseTransform.invert();
		VectorAlgebra.matrixToArray(inverseTransform, inverseTransformArray);
		
		return inverseTransformArray;
	}

	public Matrix4f getInverseTransformMatrix() {
		if (inverseTransform == null) {
			inverseTransform = new Matrix4f();
		}

		inverseTransform.setIdentity();
		inverseTransform.set(getTransformMatrix());
		inverseTransform.invert();
		
		return inverseTransform;
	}

	protected Matrix3f getNewOrientation() {
		rotation.set(orientation);
		
		orientationInverse.set(rotation);
		orientationInverse.conjugate();

		return rotation;
	}

	public Vector3f getUp() {
		/*
		 * Get Up vector based on the new orientation of camera.
		 */
		v1.set(0.0f, 1.0f, 0.0f);
		
		/*
		 * Rotate Up to new orientation.
		 */
		rot1.set(orientationInverse);
		rot1.transform(v1, v2);

		v2.normalize();
		
		return v2;
	}

	public Vector3f getSide() {
		/*
		 * Get Side vector based on the new orientation of camera.
		 */
		v1.set(1.0f, 0.0f, 0.0f);
		
		/*
		 * Rotate Side to new orientation.
		 */
		rot1.set(orientationInverse);
		rot1.transform(v1, v2);

		v2.normalize();
		
		return v2;
	}

	public void slideUpDown(float increment) {
		v1.set(getUp());
		v1.scale(increment);
		isDirty = true;
	}
	public void slideLeftRight(float increment) {
		v1.set(getSide());
		v1.scale(increment);
		isDirty = true;
	}

	/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 * Vector Basis methods
	 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	 */
	public Vector3f getLOS() {
		/*
		 * Get LOS based on the new orientation of camera.
		 */
		v1.set(0.0f, 0.0f, -1.0f);
		
		/*
		 * Rotate LOS to new orientation.
		 */
		rot1.set(orientationInverse);
		rot1.transform(v1, v2);
		
		v2.normalize();
		
		return v2;
	}

	public void render2D(GL gl) {
		gl.glPushMatrix();
		gl.glTranslatef(vCanvasCenter.x, vCanvasCenter.y, 0.0f);
		gl.glScalef(fRadius, fRadius, 0.0f);
		circle.render(gl, true, 0, 0, 0);
		gl.glPopMatrix();
	}

	/*
	 * This method renders the camera's icon for viewing in a 3rd person type
	 * viewport. Which will always be the case because the camera is not
	 * visible in a 1st person type viewport.
	 * 
	 * This is why the inverse is used to represent the transformation of the
	 * camera. The difference between a 1st and 3rd person camera is the
	 * inverse-transpose of the matrices.
	 */
	public void render(GL gl) {
		/*
		 * Store the current modelview matrix. For this demo it represents the
		 * current viewport's matrix.
		 */
		gl.glPushMatrix();
		
		
		gl.glMultMatrixf(getInverseTransformArray(), 0);

		/*
		 * Show camera's frustum icon.
		 */
		frustum.render(gl, true, 0, 0, 0);
		
		gl.glPopMatrix();

	}

	/*
	 * Build a unit circle
	 */
	public void buildMesh() {
		circle = new MultiColorLinesObject();
		//renderable = true;
		Vector3f c1 = new Vector3f();
		Vector3f v1 = new Vector3f();
		Vector3f v2 = new Vector3f();

		float f1, f2, i = 0.0f;
		f1 = (float) Math.sin(i);
		f2 = (float) Math.cos(i);
		v1.set(f1, f2, 0.0f);
		i += Math.toRadians(5.0);
		c1.set(0.9f, 0.9f, 0.9f);
		for (;i < Math.toRadians(360.0f); i += Math.toRadians(5.0)) {
			f1 = (float) Math.sin(i);
			f2 = (float) Math.cos(i);
			v2.set(f1, f2, 0.0f);
			circle.addLine(v1, v2, c1, c1);
			v1.set(v2);
		}
		circle.pack();

	}
}
