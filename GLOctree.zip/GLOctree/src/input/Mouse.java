/*
 * Created on Jan 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package input;

import javax.vecmath.Point3i;

/**
 * @author wdevore
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Mouse {
	// True if a click-drag is in progress.
	private boolean dragInProgress = false;
	
	public Point3i previousPoint = new Point3i();
	public Point3i currentPoint = new Point3i();

	public boolean isDragInProgress() {
		return dragInProgress;
	}
	public void dragInProgress() {
		dragInProgress = true;
	}
	public void dragNotInProgress() {
		dragInProgress = false;
	}
	
	public void setCurrentPoint(int x, int y) {
		currentPoint.set(x, y, 0);
	}
	public void setPreviousPoint() {
		previousPoint.set(currentPoint);
	}
	public void setPreviousPoint(int x, int y) {
		previousPoint.set(x, y, 0);
	}
	
	public int deltaX() {
		return currentPoint.x - previousPoint.x;
	}
	public int deltaX2(int xsize) {
		return (xsize - currentPoint.x) - (xsize - previousPoint.x);
	}
	public int deltaY() {
		return currentPoint.y - previousPoint.y;
	}
	public int deltaY2(int ysize) {
		return (ysize - currentPoint.y) - (ysize - previousPoint.y);
	}
	
	public String toString() {
		return "(" + String.valueOf(currentPoint.x) + "," + String.valueOf(currentPoint.y) + ")"; 
	}
}
