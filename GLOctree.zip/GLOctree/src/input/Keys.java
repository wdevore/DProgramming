/*
 * Created on Oct 8, 2004
 *
 */
package input;

/**
 * @author wdevore
 *
 */
public class Keys {
	public boolean spacebar;
	public boolean leftArrow;
	public boolean rightArrow;
	public boolean shift;
	
	public int key;
	public char ckey;
	
	public String toString() {
		return "Key: " + Integer.toString(key) + " char: " + ckey;
	}
}
