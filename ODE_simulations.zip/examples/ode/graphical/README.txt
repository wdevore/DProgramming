--------------------------------------------------------------------------------
---- Warning!!!
--------------------------------------------------------------------------------
You must compile DerelictODE using the correct floating point precision. This
means specifying the correct version in the build response files.

Your version of ODE on your machine may have been compiled for "doubles" or
"floats". It is important that you use the same thing in D when communicating
with ODE.

If you have the source code to ODE then it is possible that you know how ODE
was compiled. I for example compiled ODE using the following under Linux:

> ./configure --enable-double-precision --enable-soname

Otherwise ODE defaults to SINGLES!

If you don't know then you will have to guess and compile DerelictODE each way
until it works. The build response files have the version parameter marked so
just look in those files for help.

--------------------------------------------------------------------------------
---- Notes and Usage
--------------------------------------------------------------------------------
I have converted 5 graphical simulations from the C version of ODE.

To run a simulation type:

>simulation -sim <some name>

For example to run the Buggy simulation type:

>simulation -sim Buggy


The available simulations I have converted or added are:

Buggy
CylBoxSlide
CylVsSphere
BlockParty
Plane2d

Note:
My simulations use the default OpenGL orientation. That means UP in my world
is +Y where in ODE, UP is +Z. You will notice that the "Plane2d" simulation
appears tilted on its side. That is because that simulation was designed for
a world where UP is +Z. I would need to add functionality to ODE in order
for it to work in any orientation.

What is Helix?
I chose to use the Helix vector library to handle any matrix and vector stuff.
You are under no obligation to use it. However, I ported very little of ODE's
vector/matrix library so you don't like Helix you may need to find another
library.

--------------------------------------------------------------------------------
Compiling the examples:
--------------------------------------------------------------------------------
To compile for windows use the "windows_build.brf" build/bud response file.
Be sure to modify the file to have the correct paths to your Derelict
installation. AND don't forget to set the -version parameter to match your
ODE.

Same goes for Linux, use the unix_build.brf file and adjust the paths
accordingly. Also, the same goes for precision as well.


